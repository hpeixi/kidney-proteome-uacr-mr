# 复现与溯源说明（PROVENANCE）

生成日期：2026-11-01
稿件：Albuminuria-directed cis-pQTL Mendelian randomization: feasibility and a negative control for proteome-wide screens

## 1. 数据来源与版本

| 角色 | 数据集 | 来源 | 规模 |
|---|---|---|---|
| 暴露 | Sun 2018 SomaScan（prot-a） | OpenGWAS | 3,282 适配体，n = 3,301 |
| 主要结局 | CKDGen UACR，欧洲裔（Teumer 2019） | CKDGen / GWAS Catalog | 564,257 |
| 对照结局 | CKDGen eGFR，欧洲裔（Wuttke 2019） | CKDGen | 1,046,070 |
| 复制（血清） | GCST90059992（Png 2021） | GWAS Catalog | 2,917 |
| 复制（CSF） | GCST90427174 / GCST90421386 / GCST90426688（Western 2024） | GWAS Catalog | 3,506 |
| 复制（血浆 Olink） | GCST90468416（UKB-PPP，Sun 2023） | GWAS Catalog | 47,745 |
| 复制（SERPINA10） | ebi-a-GCST90019385 | GWAS Catalog | 10,708 |

坐标系统一为 GRCh37，顺式窗口为编码基因 TSS ±500 kb；共定位窗口 100 kb。
效应量为 expm1(β)×100，即对数尺度 UACR 的百分比变化；eGFR 保留对数单位。

## 2. 软件环境

- Python 3.12.13（Windows-11-10.0.26200-SP0）
- numpy 2.5.4，pandas 3.0.6，scipy 1.18.1
- matplotlib 3.11.2（图件 300 dpi）
- python-docx 1.2.0（稿件排版）

## 3. 复现步骤

1. `python scripts/inventory_pqtl.py`：盘点暴露面板并筛选全基因组显著 pQTL。
2. `python scripts/round5.py`：顺式限定、Wald/IVW 估计、BH 校正，输出 `results/cis_mr_results.csv`。
3. `python scripts/round6.py`：近似贝叶斯因子共定位，输出 `results/coloc_final.csv`。
4. `python scripts/steiger2.py`：方向性检验，输出 Steiger 结果表。
5. `python scripts/m1_exclude_missense.py`：错义变异注释与排除后复算。
6. `python scripts/fig2_dual_criteria.py`：Figure 2 三面板（共定位、效应量、双判据矩阵）。

全流程为确定性计算，不设随机种子；输入文件校验值见 `SHA256SUMS.txt`。

## 4. 已知限制（与正文一致）

- 共定位假定单一因果变异，窗口 100 kb，未使用 LD 矩阵，PP 为近似值。
- 74% 可评估蛋白仅有一个工具变量，无法使用 MR-Egger/加权中位数/MR-PRESSO。
- 复制面板以 SomaScan 为主，三套为 CSF，人群与体液与主分析不同。
- 重叠检验效能极低：至少需 3 个重叠蛋白方达 P < 0.05（P(X≥3) = 0.020）。
