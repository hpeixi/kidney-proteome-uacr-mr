# -*- coding: utf-8 -*-
"""修正 DOI.txt 中"稿件引用"行，重打 03 包，并做最终全量核验。"""
import re
import zipfile
from pathlib import Path

from docx import Document

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
NEW, CONCEPT, OLDER = "10.5281/zenodo.23853798", "10.5281/zenodo.23851408", "10.5281/zenodo.23852899"

# 1) 修正 DOI.txt
p = TR / "metadata" / "DOI.txt"
t = p.read_text(encoding="utf-8")
lines = []
for ln in t.splitlines():
    if ln.startswith("DOI cited in the manuscript:"):
        ln = f"DOI cited in the manuscript: {NEW} (version v1.0.4)"
    lines.append(ln)
p.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("DOI.txt 稿件引用行:", [l for l in p.read_text(encoding='utf-8').splitlines() if l.startswith('DOI cited')][0])

# 2) 重打 03
z = OUT / "03_可溯源资料包.zip"
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in TR.rglob("*"):
        if f.is_file():
            zf.write(f, Path("03_可溯源资料包") / f.relative_to(TR))

# 3) 全量核验
print("\n== 稿件 docx")
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(x.text for x in d.paragraphs)
refs = [x.text for x in d.paragraphs if re.match(r"^\d{1,2}\. ", x.text.strip())]
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("  段落:", len(d.paragraphs), "| 表:", len(d.tables), d.tables[0]._tbl.xpath('count(.//w:tr)') and "13x7")
print("  文献:", len(refs), "| 首条含题名:", len(refs[0]) > 60)
print("  摘要词数(含小标题):", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("  DOI 23853798:", NEW in txt, "| 旧 DOI 23851408 残留:", CONCEPT in txt)
print("  ORCID:", "0009-0004-5436-7788" in txt, "/", "0009-0006-5762-8650" in txt)
print("  行号:", "lnNumType" in d.element.xml, "| 页脚页码:", "PAGE" in d.sections[0].footer.paragraphs[0]._p.xml)
print("  行距(样式):", d.styles["Normal"].paragraph_format.line_spacing)

print("\n== 其他文件 DOI")
targets = [EN/"cover_letter.md", EN/"cover_letter.docx", EN/"README.md", ZH/"manuscript_zh.md",
           ZH/"manuscript_zh.docx", ZH/"manuscript_bilingual.md", ZH/"manuscript_bilingual.docx",
           ZH/"README.md", TR/"metadata/CITATION.cff", Path("repo/metadata/CITATION.cff")]
for f in targets:
    x = "\n".join(p.text for p in Document(f).paragraphs) if f.suffix == ".docx" else f.read_text(encoding="utf-8")
    print(f"  {'OK ' if (NEW in x and CONCEPT not in x) else 'BAD'} {f.as_posix()}")

print("\n== 压缩包")
for name in ["01_英文资料包", "02_中文资料包", "03_可溯源资料包"]:
    zz = OUT / f"{name}.zip"
    with zipfile.ZipFile(zz) as zf:
        hit = sum(1 for m in zf.namelist() if m.endswith((".md", ".cff", ".txt")) and NEW.encode() in zf.read(m))
        print(f"  {name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}, 含新DOI文件 {hit}")

print("\n== DOI.txt")
for ln in p.read_text(encoding="utf-8").splitlines()[:8]:
    print("  ", ln)
