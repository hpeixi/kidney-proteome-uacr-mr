# -*- coding: utf-8 -*-
"""核对概念 DOI 是否指向最新版本，并列出该概念下所有版本 DOI。

用法：
    python repo/tools/verify_doi.py                # 默认概念记录 23851408
    python repo/tools/verify_doi.py 23851408

只读 Zenodo 公开 API，不需要 token。
"""
import json
import ssl
import sys
import urllib.request

CONCEPT = sys.argv[1] if len(sys.argv) > 1 else "23851408"
API = f"https://zenodo.org/api/records/{CONCEPT}"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE


def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "doi-check/1.0"})
    with urllib.request.urlopen(req, timeout=60, context=ctx) as r:
        return json.loads(r.read())


try:
    rec = get(API)
except Exception as e:
    print(f"无法读取记录 {CONCEPT}：{e}")
    print("若返回 403/超时，多半是网络策略拦截，请在本机浏览器打开记录页核对。")
    sys.exit(1)

meta = rec.get("metadata", {})
print("概念记录:", rec.get("conceptrecid", CONCEPT))
print("最新版本:", rec.get("metadata", {}).get("version", "未标注"))
print("版本 DOI:", rec.get("doi"))
print("标题:", meta.get("title", "")[:90])
print("发布时间:", meta.get("publication_date"))
print("文件数:", len(rec.get("files", [])))
for f in rec.get("files", [])[:8]:
    key = f.get("key") or f.get("filename")
    print("  -", key)

links = rec.get("links", {})
print("记录页:", links.get("self_html") or links.get("html"))
print("概念 DOI 链接:", links.get("concept_doi") or f"https://doi.org/10.5281/zenodo.{CONCEPT}")
