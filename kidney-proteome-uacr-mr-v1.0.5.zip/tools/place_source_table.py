# -*- coding: utf-8 -*-
"""把归档源表按校验值对齐到工作区根目录，并验证一致性与结构完整性。"""
import hashlib
import shutil
from pathlib import Path

import pandas as pd

WS = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace")
canon = WS / "kidney_bioinfo_topics/交付包/03_可溯源资料包/results/cis_mr_results.csv"
expect = "ddee1d587ddc2d8fc34c95ff17da1effef02db6413b5e7f99369d9d57922fb99"

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

h = sha(canon)
print("归档源表 SHA256:", h)
print("与清单登记一致:", h == expect)
assert h == expect, "校验值不符，停止复制"

dst = WS / "cis_mr_results.csv"
shutil.copy2(canon, dst)
print("已写入:", dst, "| 校验:", sha(dst) == expect, "| 字节:", dst.stat().st_size)

d = pd.read_csv(dst)
print("结构:", d.shape, "| 列:", list(d.columns)[:6], "...")
print("UACR FDR<0.05 行数:", int((d.UACR_fdr < 0.05).sum()), "| 基因示例:", d[d.UACR_fdr < 0.05].gene.tolist()[:4])
