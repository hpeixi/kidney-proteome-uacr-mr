# -*- coding: utf-8 -*-
"""生成 cover letter、STROBE-MR 英文清单、300 dpi TIFF 图。"""
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from PIL import Image
import os

# ---------------- Cover letter ----------------
CL_MD = """# Cover letter

Editor-in-Chief
*International Urology and Nephrology*

Dear Editor,

We submit for consideration as an original research article the manuscript entitled
"Circulating plasma proteins and albuminuria: a cis-pQTL Mendelian randomization and
colocalization study" by Peixi Huang, Dingzhuo Hong, Zhiyuan Gao and Xikui Zhang.

Albuminuria is a stronger predictor of kidney failure than eGFR, yet the proteome-wide
Mendelian randomization literature has been built almost entirely on eGFR or on CKD
diagnostic labels. Because eGFR reflects filtration capacity while albuminuria reflects the
integrity of the filtration barrier, the two phenotypes are not interchangeable. To our
knowledge this is the first study to take albuminuria as the primary outcome across the
plasma proteome, with eGFR analysed in parallel as a comparator within the same instrument
set.

Using cis pQTLs for 3,282 plasma proteins (3,301 European-ancestry participants), we found
582 evaluable proteins, 12 associated with the urinary albumin-to-creatinine ratio at FDR <
0.05, and 8 with strong colocalization support (PP.H4 ≥ 0.8). Only ITIH1 was associated with
both traits, and with discordant directions, which argues that the two readouts should be
treated as distinct outcomes rather than as surrogates.

We wish to draw attention to two features that we consider essential to the paper's value.
First, we did not stop at a candidate list: independent pQTL panels were searched for all
eight proteins, and two were testable. SERPINA10 replicated with a consistent direction,
whereas BAG3 was contradicted in a much larger panel (UKB-PPP), and a reverse-direction
analysis indicated that albuminuria lowers circulating BAG3 rather than the reverse. Second,
we report this contradiction as a primary result rather than relegating it to a supplement,
because it illustrates how fragile unvalidated proteome-wide MR candidates can be. The
remaining six proteins had no independent data and are presented as hypotheses.

We believe this fits the clinical and methodological readership of International Urology and
Nephrology. The study uses only publicly available summary statistics, so no ethical approval
or patient consent was required. Derived tables are provided as supplementary material and
deposited at https://github.com/hpeixi/kidney-proteome-uacr-mr (DOI: 10.5281/zenodo.23851813).
The manuscript is not under consideration elsewhere, all authors have approved the submitted
version, and we declare no competing interests. No specific funding was received.

We would be glad to respond to any queries.

Yours sincerely,

Peixi Huang, MD
Department of Nephrology, The Second Affiliated Hospital of Guizhou Medical University,
Kaili 556000, Guizhou, China
E-mail: hpeixi@foxmail.com; ORCID 0009-0004-5436-7788
On behalf of all authors

Corresponding author: Xikui Zhang, Department of Nephrology, The Second Affiliated Hospital
of Guizhou Medical University, Kaili 556000, Guizhou, China.
E-mail: 623067910@qq.com; ORCID 0009-0006-5762-8650
"""
open("cover_letter.md", "w", encoding="utf-8").write(CL_MD)

doc = Document()
sec = doc.sections[0]
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]; st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.paragraph_format.line_spacing = 1.5; st.paragraph_format.space_after = Pt(6)
for ln in CL_MD.split("\n"):
    if ln.startswith("# "):
        p = doc.add_paragraph(); r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
        p.paragraph_format.space_after = Pt(12)
    elif ln.strip() == "":
        continue
    else:
        p = doc.add_paragraph(); p.add_run(ln.strip())
doc.save("cover_letter.docx")
print("cover letter:", len(CL_MD), "字符")

# ---------------- STROBE-MR 英文清单 ----------------
rows = [
    ("1", "Title and abstract: state that Mendelian randomization (MR) was used", "Title; Abstract (Methods)"),
    ("2", "Background: scientific rationale for the study", "Introduction, paragraphs 1-2"),
    ("3", "Objectives: specific hypotheses and prespecified analyses", "Introduction, final paragraph; Methods, 'Design and data sources'"),
    ("4", "Study design: two-sample summary-data MR; describe design and data sources", "Methods, 'Design and data sources'"),
    ("5", "Assumptions: relevance, independence, exclusion restriction; sample overlap", "Methods, 'Instruments and protein-to-gene mapping'; Limitations (single-instrument proteins, European ancestry only)"),
    ("6", "Instrument selection: source, selection thresholds, clumping, F statistic", "Methods, 'Instruments and protein-to-gene mapping'; Results, 'Instruments' (median minimum F 68.0, all > 10)"),
    ("7", "Power: sample size and power calculation", "Methods, 'Estimation and inference' (conditional power: median detectable change 3.6% at 80% power)"),
    ("8", "Statistical methods: principal analysis, effect estimation, units, multiple testing", "Methods, 'Estimation and inference' (Wald ratio, IVW, Benjamini-Hochberg FDR)"),
    ("9", "Pleiotropy: assessment of horizontal pleiotropy", "Limitations (pleiotropy-robust estimators not applicable: 73.7% single-instrument proteins); Methods, 'Replication, sensitivity and reverse direction'"),
    ("10", "Sensitivity analyses: pre-specified sensitivity and subgroups", "Methods and Results, 'Replication, sensitivity and reverse direction' (multi-instrument analysis in 145 proteins)"),
    ("11", "Software: software and packages used", "Methods, 'Replication, sensitivity and reverse direction' (Python 3.12)"),
    ("12", "Participants: numbers of individuals and variants at each stage", "Results, 'Instruments' (3,282 proteins; 3,854 records; 769 variant-protein pairs)"),
    ("13", "Descriptive data: characteristics of the instruments and exposures", "Results, 'Instruments'; Table 1; Supplementary Tables S1-S2"),
    ("14", "Main results: effect estimates with confidence intervals and P values", "Results, 'Proteins associated with UACR and eGFR'; Table 1; Figure 2"),
    ("15", "Other analyses: colocalization, replication, reverse direction", "Results, 'Colocalization' and 'Replication, sensitivity and reverse direction'; Figures 3-4"),
    ("16", "Subgroup and interaction analyses", "Not performed; stated in Limitations"),
    ("17", "Key results: summary of main findings", "Discussion, paragraph 1; Conclusions"),
    ("18", "Limitations: discussion of limitations", "Limitations section"),
    ("19", "Interpretation: biological and clinical interpretation, generalisability", "Discussion, paragraphs 2-3; Conclusions"),
    ("20", "Other information: funding and data availability", "Declarations (Funding; Availability of data and materials)"),
]
md = ["# STROBE-MR checklist", "",
      "Manuscript: Circulating plasma proteins and albuminuria: a cis-pQTL Mendelian randomization and colocalization study",
      "", "| Item | Requirement | Where addressed |", "|---|---|---|"]
md += [f"| {a} | {b} | {c} |" for a, b, c in rows]
md += ["", "Note: item 16 (subgroup analyses) and full pleiotropy-robust estimation (item 9) were not",
       "applicable because 73.7% of evaluable proteins had a single cis instrument. This is stated in the",
       "Methods and Limitations sections rather than omitted."]
open("STROBE-MR_checklist_EN.md", "w", encoding="utf-8").write("\n".join(md) + "\n")

doc = Document()
st = doc.styles["Normal"]; st.font.name = "Times New Roman"; st.font.size = Pt(10)
p = doc.add_paragraph(); r = p.add_run("STROBE-MR checklist"); r.bold = True; r.font.size = Pt(14)
p = doc.add_paragraph()
p.add_run("Circulating plasma proteins and albuminuria: a cis-pQTL Mendelian randomization and colocalization study")
t = doc.add_table(rows=len(rows) + 1, cols=3); t.style = "Table Grid"
for ci, h in enumerate(["Item", "Requirement", "Where addressed"]):
    c = t.cell(0, ci).paragraphs[0]; rr = c.add_run(h); rr.bold = True
for ri, row in enumerate(rows, 1):
    for ci, val in enumerate(row):
        c = t.cell(ri, ci).paragraphs[0]; c.add_run(val)
doc.save("STROBE-MR_checklist_EN.docx")
print("STROBE-MR 条目:", len(rows))

# ---------------- TIFF ----------------
os.makedirs("figures", exist_ok=True)
for f in ["Fig1_study_design", "Fig2_forest_UACR", "Fig3_concordance", "Fig4_coloc"]:
    im = Image.open(f"figures/{f}.png")
    if im.mode not in ("RGB", "L"):
        im = im.convert("RGB")
    im.save(f"figures/{f}.tif", format="TIFF", dpi=(300, 300), compression="tiff_lzw")
    print(f"  {f}.tif {im.size} dpi300")
