# -*- coding: utf-8 -*-
"""按第三份意见修 M2/M3/M4/M6/M7/M8 与两处 MINOR；加 S13/S14；重建 docx 与包。"""
import re
import zipfile
from pathlib import Path

import openpyxl
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
RES = TR / "results"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

R = [
 # M2 面板平台/体液
 ("Further pQTL panels were retrieved from the GWAS Catalog for ISLR2 (n = 2,917) and for PCOLCE, ITIH1 and OAF (n = 3,506 each).",
  "Further panels were taken from the GWAS Catalog: ISLR2 (serum, SomaScan, 2,917 European-ancestry participants) and PCOLCE, ITIH1 and OAF (cerebrospinal fluid, SomaScan, 3,506 each). Comparison with UKB-PPP [5] therefore contrasts platforms, and for three proteins also biofluids.", "M2-methods"),
 ("Four of the twelve candidates rest on a single missense variant, so their estimates cannot be separated from an epitope effect on aptamer binding.",
  "Four of the twelve candidates rest on a single missense variant, so their estimates cannot be separated from an epitope effect on aptamer binding. The replication panels for ISLR2, ITIH1, PCOLCE and OAF are SomaScan-based, and those for ITIH1, PCOLCE and OAF are cerebrospinal fluid rather than plasma; agreement between them and the primary panel therefore cannot exclude aptamer or biofluid effects, and only BAG3 was tested on a different platform (Olink).", "M2-limit"),
 # M3 ITIH1 证据等级
 ("in the ITIH1–ITIH3–ITIH4 cluster (Figure 3).",
  "in the ITIH1–ITIH3–ITIH4 cluster (Figure 3). ITIH1 carries the weakest evidence in the list: a single missense instrument, colocalization below the prespecified threshold (PP.H4 0.614), and a locus with several independent signals.", "M3"),
 # M4 SERPINA10 表内判定
 ("| SERPINA10 | 1 | −1.2 | −1.9 to −0.6 | 1.7×10⁻² | 0.882 | Replicated |",
  "| SERPINA10 | 1 | −1.2 | −1.9 to −0.6 | 1.7×10⁻² | 0.882 | Inconsistently replicated |", "M4-table"),
 # M6 重叠检验改写讨论
 ("The near-absence of overlap between the two protein lists is biologically informative. However similar the traits appear clinically, they do not share their protein architecture, and eGFR will miss proteins that act on the barrier.",
  "The two lists overlapped in a single protein (ITIH1). With 12 UACR and 30 eGFR hits among 582 evaluable proteins, the expected overlap is 0.62 and observing one is entirely compatible with chance (P = 0.47, Supplementary Table S14). These data therefore do not show that the two traits have distinct protein architectures; what they show is that a UACR-specific set was not recovered from eGFR.", "M6"),
 # M7 LD 表述
 ("colocalization without an ancestry-matched linkage disequilibrium (LD) reference can only approximate the posterior probability of a shared variant.",
  "colocalization under a single-causal-variant assumption can only approximate the posterior probability of a shared variant.", "M7-intro"),
 ("This implementation uses no LD matrix and a 100 kb window; posterior probabilities are therefore approximations (see Limitations).",
  "This implementation assumes a single causal variant and uses a 100 kb window; the posterior probabilities are therefore approximations (see Limitations).", "M7-methods"),
 ("It assumed a single causal variant, used a 100 kb window and no ancestry-matched LD matrix, so the posterior probabilities are not directly comparable with those from coloc with a reference panel",
  "It assumed a single causal variant and used a 100 kb window; coloc.abf does not use an LD matrix, so the limitation lies in the single-variant assumption and the window rather than in the absence of LD", "M7-limit"),
 # M8 功效句改为非循环表述
 ("All twelve exceeded their own 80% power threshold at FDR alpha; the narrowest margin was FCGR2A (+0.54% against 0.46%).",
  "Power is derived from the same standard error that determines significance, so this comparison is close to tautological; the proteins whose effects sit nearest their detectable limit (FCGR2A +0.5%, SERPINA10 −1.2%, ITIH1 −1.5%) are the least secure.", "M8"),
 # MINOR 空格与 F 表述
 ("(CKDGen).Instruments", "(CKDGen). Instruments", "MINOR-space"),
 ("with F-statistics exceeding 10 (minimum F 29.8)", "with F-statistics exceeding 10 (weakest instrument F = 29.8)", "MINOR-F"),
 # 摘要与结论中的“四复制”改为“三复制+一不一致”
 ("SERPINA10, ISLR2, ITIH1 and PCOLCE replicated in the same direction in independent panels; BAG3 reversed and OAF was null.",
  "ISLR2, ITIH1 and PCOLCE gave direction-consistent estimates in independent SomaScan panels, SERPINA10 did so only inconsistently, BAG3 reversed and OAF was null.", "ABS-results"),
 ("four replicated, one reversed, one was null and one was not evaluable",
  "three replicated, one replicated inconsistently, one reversed, one was null and one was not evaluable", "ABS-concl"),
 ("four kept their direction (SERPINA10, ISLR2, ITIH1, PCOLCE), BAG3 reversed, OAF was null, and ANGPTL1 could not be evaluated.",
  "ISLR2, ITIH1 and PCOLCE kept their direction, SERPINA10 only inconsistently, BAG3 reversed, OAF was null, and ANGPTL1 could not be evaluated.", "DISC"),
 ("four replicated in direction, one reversed, one was null and one could not be evaluated",
  "three replicated in direction, one replicated inconsistently, one reversed, one was null and one could not be evaluated", "CONCL"),
]

fails = []
for old, new, label in R:
    if old in md:
        md = md.replace(old, new, 1)
    else:
        fails.append(label)
print("未匹配:", fails if fails else "无")
if fails:
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

# 摘要词数检查
start = md.index("**Purpose.**"); end = md.index("**Keywords:**")
ab = re.sub(r"\*\*(Purpose|Methods|Results|Conclusion)\.\*\*", "", md[start:end])
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要词数(不含小标题):", len(re.findall(pat, ab)), "| 含小标题:", len(re.findall(pat, md[start:end])))

# 工作簿加 S13/S14
s13 = pd.read_csv(RES / "S13_replication_panels.csv")
s14 = pd.read_csv(RES / "S14_overlap_test.csv")
def rebuild_book(src, dst):
    wb = openpyxl.load_workbook(src)
    for name, df in [("S13_Replication_panels", s13), ("S14_Overlap_test", s14)]:
        if name in wb.sheetnames:
            del wb[name]
        ws = wb.create_sheet(name)
        ws.append(list(df.columns))
        for _, row in df.iterrows():
            ws.append([None if pd.isna(v) else v for v in row.values])
    wb.save(dst); wb.close()

en_old = EN / "supplementary" / "Table_S1_S12.xlsx"
en_new = EN / "supplementary" / "Table_S1_S14.xlsx"
zh_old = ZH / "supplementary" / "投稿材料_补充表_S1_S12.xlsx"
zh_new = ZH / "supplementary" / "投稿材料_补充表_S1_S14.xlsx"
rebuild_book(en_old, en_new); rebuild_book(zh_old, zh_new)
en_old.unlink(); zh_old.unlink()

# 补充材料清单与 README
md2 = md_path.read_text(encoding="utf-8")
md2 = md2.replace("S12 estimates after excluding missense instruments.",
                  "S12 estimates after excluding missense instruments; S13 platform, ancestry and sample size of each replication panel; S14 hypergeometric test of overlap between the UACR and eGFR hit lists.")
md_path.write_text(md2, encoding="utf-8")
for p in [EN / "README.md", ZH / "README.md"]:
    t = p.read_text(encoding="utf-8")
    t = t.replace("Table_S1_S12.xlsx", "Table_S1_S14.xlsx").replace("投稿材料_补充表_S1_S12.xlsx", "投稿材料_补充表_S1_S14.xlsx")
    t = t.replace("S1–S12", "S1–S14").replace("S1-S12", "S1-S14")
    p.write_text(t, encoding="utf-8")
print("工作簿:", openpyxl.load_workbook(en_new, read_only=True).sheetnames)
