# -*- coding: utf-8 -*-
"""第六轮收尾：摘要压回 250、重建 docx、核验 M1-M6 落点与数字一致性。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"

trims = [
 ("2,162 carried a genome-wide significant pQTL", "2,162 carried a significant pQTL"),
 ("ANGPTL1 was not evaluable, BAG3 reversed and OAF was null", "ANGPTL1 not evaluable, BAG3 reversed, OAF null"),
 ("in this dataset, eGFR-anchored screening was not a substitute for this approach; the five of the eight that survived missense exclusion are candidates for validation.",
  "in this dataset, eGFR-anchored screening was no substitute; five of the eight surviving missense exclusion are candidates for validation."),
]
for a, b in trims:
    if a in md:
        md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])))

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
sec.top_margin = sec.bottom_margin = Cm(2.0)
sec.left_margin = sec.right_margin = Cm(2.54)
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val); r.font.size = Pt(6.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
cells = [c.text for t in d.tables for r in t.rows for c in r.cells]
print("docx 摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")

checks = {
 "摘要范围 −6.6→+5.1": "−6.6% to +5.1%" in txt,
 "正文 ISLR2 CI": "−6.6% (95% CI −9.3 to −3.9)" in txt,
 "正文 BAG3 CI": "+5.1% (+2.1 to +8.2)" in txt,
 "表内 -6.6": any(c.strip() == "-6.6" for c in cells),
 "表内 5.1": any(c.strip() in ("5.1", "+5.1") for c in cells),
 "Steiger 新表述": "only six reached strong or moderate support" in txt,
 "效能边界": "P(X ≥ 3) = 0.020" in txt,
 "M4 样本量双口径": "2,893 participants in the original report" in txt,
 "M5 OAF+[1]": "Drosophila nephrocytes [1]" in txt,
 "M6 [19]": "[19" in txt,
 "表注方向限制": "reflects direction only" in txt,
}
for k, v in checks.items():
    print(f"  {k}: {v}")

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
