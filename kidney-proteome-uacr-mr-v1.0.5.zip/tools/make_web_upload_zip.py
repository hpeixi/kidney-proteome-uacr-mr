# -*- coding: utf-8 -*-
"""生成网页上传用的单文件包（含 repo 全树），并核验内容。"""
import zipfile
from pathlib import Path

REPO = Path("repo")
OUTDIR = Path("GitHub上传")
OUTDIR.mkdir(exist_ok=True)
out = OUTDIR / "kidney-proteome-uacr-mr-v1.0.5.zip"

SKIP = {".git", "__pycache__", ".ipynb_checkpoints"}
files = sorted(p for p in REPO.rglob("*") if p.is_file() and not any(x in p.parts for x in SKIP))

with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for p in files:
        zf.write(p, p.relative_to(REPO).as_posix())

z = zipfile.ZipFile(out)
names = z.namelist()
print("文件数:", len(names), "| 完整:", z.testzip() is None, "| 大小: %.2f MB" % (out.stat().st_size / 1e6))
must = ["manuscripts/manuscript_en.docx", "manuscripts/manuscript_zh.docx",
        "figures/Fig2_dual_criteria.png", "PROVENANCE.md", ".zenodo.json", "LICENSE"]
for m in must:
    print(("  有 " if m in names else "  缺 ") + m)
big = [(n, z.getinfo(n).file_size) for n in names if z.getinfo(n).file_size > 20 * 1024 * 1024]
print("超过 20MB 的文件:", big or "无")
old = [n for n in names if "Fig2_forest" in n]
print("包内是否残留旧图:", old or "无")
print("输出:", out.as_posix(), out.stat().st_size, "字节")
