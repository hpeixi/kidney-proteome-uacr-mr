# -*- coding: utf-8 -*-
"""在 DOI.txt 中登记 v1.0.4，重打可溯源包，并逐项核验 DOI 替换结果。"""
import re
import zipfile
from pathlib import Path

from docx import Document

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
NEW, PREV, OLDEST = "10.5281/zenodo.23851408", "10.5281/zenodo.23852899", "10.5281/zenodo.23851813"

# ---------- 1) DOI.txt 登记 v1.0.4 ----------
p = TR / "metadata" / "DOI.txt"
t = p.read_text(encoding="utf-8")
if "v1.0.4" not in t:
    block = (
        "v1.0.4   DOI: 10.5281/zenodo.23851408\n"
        "         Metadata only: affiliations stored as structured entries, so the first\n"
        "         author is linked to both institutions and the numbering on the record\n"
        "         page matches the manuscript. This is the identifier cited in the\n"
        "         manuscript and the cover letter.\n\n"
    )
    t = t.replace("v1.0.3   DOI:", block + "v1.0.3   DOI:", 1)
    t = t.replace("Repository: https://github.com/hpeixi/kidney-proteome-uacr-mr\n",
                  "Repository: https://github.com/hpeixi/kidney-proteome-uacr-mr\n"
                  "DOI cited in the manuscript: 10.5281/zenodo.23851408\n", 1)
    p.write_text(t, encoding="utf-8")
print("DOI.txt 已登记 v1.0.4:", "232" and ("v1.0.4" in p.read_text(encoding="utf-8")))

# ---------- 2) 重打 03 包 ----------
z = OUT / "03_可溯源资料包.zip"
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in TR.rglob("*"):
        if f.is_file():
            zf.write(f, Path("03_可溯源资料包") / f.relative_to(TR))

# ---------- 3) 核验 ----------
print("\n== 文件级 DOI 核验")
targets = [EN / "manuscript_en.md", EN / "manuscript_en.docx", EN / "cover_letter.md",
           EN / "cover_letter.docx", EN / "README.md",
           ZH / "manuscript_zh.md", ZH / "manuscript_zh.docx",
           ZH / "manuscript_bilingual.md", ZH / "manuscript_bilingual.docx", ZH / "README.md",
           TR / "metadata" / "CITATION.cff", Path("repo/metadata/CITATION.cff")]
ok = True
for f in targets:
    txt = ("\n".join(x.text for x in Document(f).paragraphs) if f.suffix == ".docx"
           else f.read_text(encoding="utf-8"))
    good = NEW in txt and PREV not in txt and OLDEST not in txt
    ok &= good
    print(f"  {'OK ' if good else 'BAD'} {f.as_posix()}")

print("\n== 稿件要素复查")
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(x.text for x in d.paragraphs)
refs = [x.text for x in d.paragraphs if re.match(r"^\d{1,2}\. ", x.text.strip())]
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("  文献条数:", len(refs), "| 摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("  一作/通讯 ORCID:", "0009-0004-5436-7788" in txt, "/", "0009-0006-5762-8650" in txt)
print("  行号:", "lnNumType" in d.element.xml, "| 页脚页码域:", "PAGE" in d.sections[0].footer.paragraphs[0]._p.xml)

print("\n== 压缩包核验")
for name in ["01_英文资料包", "02_中文资料包", "03_可溯源资料包"]:
    zp = OUT / f"{name}.zip"
    with zipfile.ZipFile(zp) as zf:
        bad = zf.testzip()
        n = len(zf.namelist())
        hit = False
        for member in zf.namelist():
            if member.endswith((".md", ".cff", ".txt")):
                if NEW.encode() in zf.read(member):
                    hit = True
                    break
    print(f"  {name}.zip: {n} 条目, 完整={bad is None}, 包内可见新DOI={hit}")

print("\n== DOI.txt")
for ln in p.read_text(encoding="utf-8").splitlines()[:6]:
    print("  ", ln)
print("\n总判定:", "全部通过" if ok else "存在不一致")
