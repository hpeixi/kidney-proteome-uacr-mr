# -*- coding: utf-8 -*-
"""润色前后文风对比：重复片段、套话、句长；并确认关键数字仍在 docx 中。"""
import re
from collections import Counter
from pathlib import Path

from docx import Document

def body(md_text):
    s = md_text.index("## Introduction")
    e = md_text.index("## References")
    return md_text[s:e]

def metrics(name, text):
    words = re.findall(r"[A-Za-z][A-Za-z'\-]*", text)
    sents = [x for x in re.split(r"(?<=[.!?])\s+", re.sub(r"[#*]", "", text)) if len(x.split()) > 3]
    toks = re.findall(r"[A-Za-z0-9']+", text.lower())
    n = 6
    grams = Counter(tuple(toks[i:i+n]) for i in range(len(toks)-n+1))
    dup = sum(c-1 for c in grams.values() if c > 1)
    ai = len(re.findall(r"\b(Moreover|Furthermore|In addition|Additionally|Notably|Importantly|Overall|"
                        r"crucial|pivotal|underscore|shed light|not only|plays a)\b", text, re.I))
    lens = [len(s.split()) for s in sents]
    print(f"{name}: 词数 {len(words)}, 句数 {len(sents)}, 平均句长 {sum(lens)/max(len(lens),1):.1f}, "
          f"6词重复片段 {dup}, 套话命中 {ai}")

old = Path("repo/tools/manuscript_en_before_polish.md").read_text(encoding="utf-8")
new = Path("交付包/01_英文资料包/manuscript_en.md").read_text(encoding="utf-8")
metrics("润色前", body(old))
metrics("润色后", body(new))

d = Document("交付包/01_英文资料包/manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
keys = ["3,282", "2,162", "3,854", "2,271", "769", "582", "429", "73.7", "68.0", "29.8", "2,758",
        "−6.4", "+5.3", "31", "1.46", "5.7×10⁻⁶", "0.996", "0.817", "0.998", "−0.0098", "4.0×10⁻⁴",
        "0.032", "7.2×10⁻³⁶", "+0.051", "145", "0.016", "0.28", "57", "0.26", "1.3×10⁻⁶", "74%", "100 kb", "500 kb"]
missing = [k for k in keys if k not in txt]
print("\ndocx 关键数字缺失:", missing if missing else "无")
print("docx 中含 DOI:", "10.5281/zenodo.23853798" in txt)
