# -*- coding: utf-8 -*-
"""修正 publish_zenodo.py 的 --files 路径解析（相对路径按当前目录解析）。"""
from pathlib import Path

p = Path("repo/tools/publish_zenodo.py")
s = p.read_text(encoding="utf-8")

subs = [
    ("    files = [Path(f) for f in args.files] if args.files else collect()",
     "    files = [Path(f).expanduser().resolve() for f in args.files] if args.files else collect()"),
    ('            print("  ", f.relative_to(ROOT).as_posix())',
     '            try:\n'
     '                shown = f.relative_to(ROOT).as_posix()\n'
     '            except ValueError:\n'
     '                shown = str(f)\n'
     '            print("  ", shown)'),
    ("        rel = f.relative_to(ROOT).as_posix()",
     "        try:\n"
     "            rel = f.relative_to(ROOT).as_posix()\n"
     "        except ValueError:\n"
     "            rel = f.name"),
]

for old, new in subs:
    if old in s:
        s = s.replace(old, new, 1)
        print("已替换:", old.strip()[:48])
    else:
        print("未匹配:", old.strip()[:48])

p.write_text(s, encoding="utf-8")
print("resolve 已生效:", "expanduser().resolve()" in s)
