# -*- coding: utf-8 -*-
"""摘要压至 250 内并重建 docx；输出核验。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"

trims = [
 ("Albuminuria indicates injury to the glomerular filtration barrier and precedes kidney function loss",
  "Albuminuria indicates injury to the filtration barrier and precedes kidney function loss"),
 ("Proteome-wide Mendelian randomization (MR) has so far used estimated glomerular filtration rate (eGFR) or diagnostic labels as outcomes.",
  "Proteome-wide Mendelian randomization (MR) has used estimated glomerular filtration rate (eGFR) or diagnostic labels as outcomes."),
 ("Effects were estimated by the Wald ratio or inverse-variance weighting, and colocalization by an approximate Bayes factor.",
  "Effects used the Wald ratio or inverse-variance weighting; colocalization used an approximate Bayes factor."),
 ("with changes from −6.4% to +5.3% per SD of predicted protein, and eight colocalized (PP.H4 ≥ 0.8), five of which survived exclusion of missense instruments.",
  "with changes from −6.4% to +5.3% per SD, and eight colocalized (PP.H4 ≥ 0.8), five of which survived missense exclusion."),
 ("the UACR and eGFR hit lists overlapped no more than expected by chance (P = 0.47).",
  "overlap with the eGFR list was no greater than chance (P = 0.47)."),
]
for a, b in trims:
    if a in md:
        md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])))

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(3)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(8.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("docx 摘要:", len(re.findall(pat, ab)),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)))

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
