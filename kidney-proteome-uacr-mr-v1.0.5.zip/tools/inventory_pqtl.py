# -*- coding: utf-8 -*-
"""为 12 个候选蛋白检索所有公开 pQTL 数据集，并核对 EBI 上文件是否存在及大小。"""
import json
import re
import ssl
import urllib.parse
import urllib.request
from pathlib import Path

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
BASE = "https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/"
HDR = {"User-Agent": "Mozilla/5.0", "Accept": "application/json"}


def api(path):
    r = urllib.request.urlopen(urllib.request.Request(path, headers=HDR), timeout=60, context=ctx)
    return json.loads(r.read().decode())


def dir_listing(gcst):
    n = int(gcst[4:])
    lo = ((n - 1) // 1000) * 1000 + 1
    hi = lo + 999
    rg = f"GCST{lo:06d}-GCST{hi:06d}"
    url = f"{BASE}{rg}/{gcst}/"
    r = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=60, context=ctx)
    html = r.read().decode("utf-8", "ignore")
    files = re.findall(r'href="([^"]+\.(?:tsv\.gz|h\.tsv\.gz|txt\.gz))"[^<]*</a>\s*([\d\.]+[KMG]?)', html)
    if not files:
        files = [(f, "?") for f in re.findall(r'href="([^"]+\.(?:tsv\.gz|h\.tsv\.gz|txt\.gz))"', html)]
    return rg, files


TRAITS = {
    "APOA5": "Apolipoprotein A-V levels",
    "MCL1": "Induced myeloid leukemia cell differentiation protein Mcl-1 levels",
    "ISLR2": "Immunoglobulin superfamily containing leucine-rich repeat protein 2 levels",
    "SERPINA10": "Protein Z-dependent protease inhibitor levels",
    "ANGPTL1": "Angiopoietin-related protein 1 levels",
    "PCOLCE": "Procollagen C-endopeptidase enhancer 1 levels",
    "RSPO3": "R-spondin-3 levels",
    "ITIH1": "Inter-alpha-trypsin inhibitor heavy chain H1 levels",
    "OAF": "Out at first protein homolog levels",
    "SERPINF2": "Alpha-2-antiplasmin levels",
    "FCGR2A": "Low affinity immunoglobulin gamma Fc region receptor II-a levels",
    "BAG3": "BAG3 protein levels",
}

rows = []
for gene, trait in TRAITS.items():
    q = urllib.parse.quote(trait)
    try:
        d = api(f"https://www.ebi.ac.uk/gwas/rest/api/v2/studies?diseaseTrait={q}&size=20")
        studies = d.get("_embedded", {}).get("studies", [])
    except Exception as e:
        print(f"{gene}: 检索失败 {type(e).__name__}")
        continue
    for st in studies:
        acc = st.get("accession_id", "")
        if not acc.startswith("GCST") or not st.get("full_summary_stats_available"):
            continue
        if trait.lower().split()[0].lower() not in str(st.get("disease_trait", "")).lower():
            continue
        n = st.get("initial_sample_size", "")
        snp = st.get("snp_count")
        try:
            rg, files = dir_listing(acc)
        except Exception:
            files = []
        rows.append({"gene": gene, "trait": st.get("disease_trait"), "gcst": acc,
                     "n": n, "snp": snp, "pubmed": st.get("pubmed_id"),
                     "range": rg if files else "", "files": ";".join(f"{a}({b})" for a, b in files)})
        print(f"{gene}: {acc} | n={n} | SNP={snp} | 文件 {files}")

Path("repo/tools/pqtl_inventory.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
print("\n可下载条目:", len(rows))
