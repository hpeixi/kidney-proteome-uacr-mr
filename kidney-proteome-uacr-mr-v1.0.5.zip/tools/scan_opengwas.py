# -*- coding: utf-8 -*-
"""拉取 OpenGWAS 数据集清单，筛出可用的 pQTL 面板与目标蛋白。"""
import json
import re
import ssl
import urllib.request
from pathlib import Path

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
TOKEN = Path(".opengwas_token").read_text(encoding="utf-8").strip()
HDR = {"Authorization": f"Bearer {TOKEN}", "User-Agent": "Mozilla/5.0"}

url = "https://api.opengwas.io/api/gwasinfo"
req = urllib.request.Request(url, headers=HDR)
raw = urllib.request.urlopen(req, timeout=180, context=ctx).read()
data = json.loads(raw)
print("OpenGWAS 数据集总数:", len(data))

# 面板前缀统计
from collections import Counter
pref = Counter(k.split("-")[0] if "-" in k else k for k in data)
print("id 前缀前 10:", pref.most_common(10))

# 目标蛋白名（小写关键词）
targets = {
    "APOA5": ["apolipoprotein a-v", "apoa5", "apolipoprotein a-v levels"],
    "MCL1": ["mcl-1", "mcl1", "induced myeloid leukemia"],
    "ISLR2": ["islr2", "immunoglobulin superfamily containing leucine"],
    "SERPINA10": ["protein z-dependent protease inhibitor", "serpina10"],
    "ANGPTL1": ["angiopoietin-related protein 1", "angptl1", "angiopoietin-like 1"],
    "PCOLCE": ["pcolce", "procollagen c-endopeptidase enhancer"],
    "RSPO3": ["rspo3", "r-spondin-3"],
    "ITIH1": ["itih1", "inter-alpha-trypsin inhibitor heavy chain h1"],
    "OAF": ["oaf", "out at first"],
    "SERPINF2": ["serpinf2", "alpha-2-antiplasmin"],
    "FCGR2A": ["fcgr2a", "low affinity immunoglobulin gamma fc region receptor ii-a"],
    "BAG3": ["bag3", "bag family molecular chaperone regulator 3"],
}
hits = {}
for g, kws in targets.items():
    found = []
    for sid, meta in data.items():
        trait = str(meta.get("trait", "")).lower()
        if any(k in trait for k in kws):
            found.append((sid, meta.get("trait"), meta.get("sample_size"), meta.get("nsnp"),
                          meta.get("population"), meta.get("author")))
    hits[g] = found
    print(f"\n{g}: {len(found)} 个候选")
    for f in found[:6]:
        print("   ", f)

Path("repo/tools/opengwas_gwasinfo_n.json").write_text(str(len(data)), encoding="utf-8")
json.dump(hits, open("repo/tools/opengwas_hits.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
