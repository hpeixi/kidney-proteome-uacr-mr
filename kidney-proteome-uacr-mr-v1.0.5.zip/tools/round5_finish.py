# -*- coding: utf-8 -*-
"""收尾：摘要压回 250、刷新 S17 分档、重建 docx 与三个包，并核验。"""
import re
import zipfile
from pathlib import Path

import openpyxl
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
RES = TR / "results"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"

trims = [
 ("Of the 3,282 proteins, 2,162 carried at least one genome-wide significant pQTL; cis restriction left 582 evaluable proteins, 429 with a single instrument.",
  "Of 3,282 proteins, 2,162 carried a genome-wide significant pQTL; cis restriction left 582 evaluable, 429 with one instrument."),
 ("with changes from −6.4% to +5.3% per SD, and eight colocalized",
  "(changes −6.4% to +5.3% per SD), and eight colocalized"),
 ("(one serum, two cerebrospinal fluid)", "(one serum, two CSF)"),
 ("on the weakest evidence in Table 1.", "on the weakest evidence in the table."),
]
for a, b in trims:
    if a in md:
        md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])))

# 刷新 S17 分档
s17 = pd.read_csv(RES / "S17_steiger.csv")
for label, p in [("EN", EN / "supplementary/Table_S1_S17.xlsx"), ("ZH", ZH / "supplementary/投稿材料_补充表_S1_S17.xlsx")]:
    wb = openpyxl.load_workbook(p)
    if "S17_Steiger" in wb.sheetnames:
        del wb["S17_Steiger"]
    ws = wb.create_sheet("S17_Steiger")
    ws.append(list(s17.columns))
    for _, r in s17.iterrows():
        ws.append([None if pd.isna(v) else v for v in r.values])
    wb.save(p); wb.close()
    print(label, "S17 行:", openpyxl.load_workbook(p, read_only=True)["S17_Steiger"].max_row)

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val); r.font.size = Pt(6.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
cells = [c.text for t in d.tables for r in t.rows for c in r.cells]
print("docx 摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
for k in ["SERPINA10 gave β = −0.0098", "four-instrument dataset", "Cochran", "Z = 0.58",
          "inconclusive", "neurological", "184 neuro-related proteins", "no candidate was replicated in plasma from a general population",
          "ISLR2, ITIH1 and PCOLCE"]:
    print(f"  {k}: {k in txt or k in ''.join(cells)}")
print("表内 Tier 分布:", pd.Series([c for c in cells if c in ('strong', 'moderate', 'inconclusive')]).value_counts().to_dict())

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
