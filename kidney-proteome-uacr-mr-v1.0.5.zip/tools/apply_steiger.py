# -*- coding: utf-8 -*-
"""写入 Steiger：Methods 假设、Results 结果、Table 1 新列、S17 表；重建 docx 与包。"""
import re
import zipfile
from pathlib import Path

import openpyxl
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
RES = TR / "results"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

steig = pd.read_csv(RES / "S17_steiger.csv")
print("S17 行数:", len(steig), "| 方向 protein→UACR:", int((steig.Direction == "protein→UACR").sum()))

R = [
 # Methods：把“未做正式检验”改为写明假设的正式近似检验
 ("Direction was examined by comparing variance explained in exposure and outcome, the Steiger principle [16]; formal tests were not run.",
  "Direction was examined with an approximate Steiger test. Variance explained was computed as r² = 2f(1−f)β² for each trait, with allele frequency f taken from the CKDGen file because the exposure resource does not report it, and with log-UACR assumed to have unit standard deviation; Z was formed as (r²e − r²o)/√[(1−r²e)²/Ne + (1−r²o)²/No], with Ne = 3,301 and No from CKDGen. One instrument lacked a sample size and was excluded from its protein's test (Supplementary Table S17)."),
 # Results：补 Steiger 结果句
 ("With 57 pruned UACR instruments, reverse-direction MR associated higher UACR with lower BAG3 (β = −0.26, SE 0.054, P = 1.3×10⁻⁶).",
  "With 57 pruned UACR instruments, reverse-direction MR associated higher UACR with lower BAG3 (β = −0.26, SE 0.054, P = 1.3×10⁻⁶). Steiger direction was consistent with protein→UACR for all twelve proteins (Z 0.58–36.11; Supplementary Table S17): the instruments explain more variance in protein than in UACR, as expected when the protein is the proximal trait."),
 # Limitations：补假设的边界
 ("Direction was tested for BAG3 only; the other candidates were not examined for reverse causation, and the order of analyses makes the BAG3 result an illustration rather than a prespecified test.",
  "Direction was tested formally only by the approximate Steiger analysis, which assumes unit standard deviation for log-UACR and uses CKDGen allele frequencies for an exposure panel that does not report them; it can support direction but cannot exclude reverse causation for an individual protein. Reverse MR was run for BAG3 alone, and the order of analyses makes that result an illustration rather than a prespecified test."),
 # 补充材料清单
 ("S1–S16 (instruments through evidence tiers) are provided in one workbook",
  "S1–S17 (instruments through Steiger direction tests) are provided in one workbook"),
 # Table 1：加 Steiger 列并压缩状态词
 ("| Gene | Instruments | Change per SD (%) | 95% CI | FDR | PP.H4 | Replication |",
  "| Gene | Instruments | Change per SD (%) | 95% CI | FDR | PP.H4 | Replication | Steiger |"),
 ("|---|---|---|---|---|---|---|", "|---|---|---|---|---|---|---|---|"),
 ("| ISLR2 | 1 | −6.4 | −8.9 to −3.8 | 8.8×10⁻⁴ | 0.887 | Direction-consistent (serum, SomaScan) [17] |",
  "| ISLR2 | 1 | −6.4 | −8.9 to −3.8 | 8.8×10⁻⁴ | 0.887 | Consistent (serum) [17] | ok |"),
 ("| ITIH1 | 1 | −1.5 | −2.1 to −0.8 | 1.6×10⁻³ | 0.614 | Direction-consistent, lowest confidence (CSF) [18] |",
  "| ITIH1 | 1 | −1.5 | −2.1 to −0.8 | 1.6×10⁻³ | 0.614 | Consistent, lowest confidence (CSF) [18] | ok |"),
 ("| OAF | 2 | −1.6 | −2.3 to −0.8 | 1.3×10⁻² | 0.002 | Null (CSF, SomaScan) [18] |",
  "| OAF | 2 | −1.6 | −2.3 to −0.8 | 1.3×10⁻² | 0.002 | Null (CSF) [18] | ok |"),
 ("| APOA5 | 1 | −5.0 | −7.4 to −2.5 | 1.4×10⁻² | 0.996 | Not available |",
  "| APOA5 | 1 | −5.0 | −7.4 to −2.5 | 1.4×10⁻² | 0.996 | Not available | ok |"),
 ("| SERPINA10 | 1 | −1.2 | −1.9 to −0.6 | 1.7×10⁻² | 0.882 | Direction conflict (CSF) [18] |",
  "| SERPINA10 | 1 | −1.2 | −1.9 to −0.6 | 1.7×10⁻² | 0.882 | Conflict (CSF) [18] | ok |"),
 ("| SERPINF2 | 1 | −4.5 | −6.9 to −2.0 | 4.0×10⁻² | 0.048 | Not available |",
  "| SERPINF2 | 1 | −4.5 | −6.9 to −2.0 | 4.0×10⁻² | 0.048 | Not available | ok |"),
 ("| BAG3 | 1 | +5.3 | +2.1 to +8.5 | 4.6×10⁻² | 0.966 | Not replicated (opposite) |",
  "| BAG3 | 1 | +5.3 | +2.1 to +8.5 | 4.6×10⁻² | 0.966 | Opposite (plasma, Olink) [5] | ok |"),
 ("| MCL1 | 1 | −6.0 | −9.3 to −2.6 | 4.6×10⁻² | 0.984 | Not available |",
  "| MCL1 | 1 | −6.0 | −9.3 to −2.6 | 4.6×10⁻² | 0.984 | Not available | ok |"),
 ("| PCOLCE | 1 | +3.7 | +1.6 to +5.9 | 4.6×10⁻² | 0.852 | Direction-consistent (CSF, SomaScan) [18] |",
  "| PCOLCE | 1 | +3.7 | +1.6 to +5.9 | 4.6×10⁻² | 0.852 | Consistent (CSF) [18] | ok |"),
 ("| FCGR2A | 2 | +0.5 | +0.2 to +0.9 | 4.6×10⁻² | 0.678 | Not available |",
  "| FCGR2A | 2 | +0.5 | +0.2 to +0.9 | 4.6×10⁻² | 0.678 | Not available | ok |"),
 ("| ANGPTL1 | 2 | −1.6 | −2.6 to −0.7 | 4.6×10⁻² | 0.873 | Not evaluable |",
  "| ANGPTL1 | 2 | −1.6 | −2.6 to −0.7 | 4.6×10⁻² | 0.873 | Not evaluable | ok |"),
 ("| RSPO3 | 1 | −2.5 | −4.0 to −1.0 | 4.7×10⁻² | 0.817 | Not available |",
  "| RSPO3 | 1 | −2.5 | −4.0 to −1.0 | 4.7×10⁻² | 0.817 | Not available | ok |"),
]
fails = []
for a, b in R:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        fails.append(a[:60])
print("未匹配:", fails if fails else "无")
if fails:
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

# 工作簿加 S17
def rebuild(src, dst):
    wb = openpyxl.load_workbook(src)
    name = "S17_Steiger"
    if name in wb.sheetnames:
        del wb[name]
    ws = wb.create_sheet(name)
    ws.append(list(steig.columns))
    for _, r in steig.iterrows():
        ws.append([None if pd.isna(v) else v for v in r.values])
    wb.save(dst); wb.close()

en_old = EN / "supplementary" / "Table_S1_S16.xlsx"
en_new = EN / "supplementary" / "Table_S1_S17.xlsx"
zh_old = ZH / "supplementary" / "投稿材料_补充表_S1_S16.xlsx"
zh_new = ZH / "supplementary" / "投稿材料_补充表_S1_S17.xlsx"
rebuild(en_old, en_new); rebuild(zh_old, zh_new)
en_old.unlink(); zh_old.unlink()
for p in [EN / "README.md", ZH / "README.md"]:
    t = p.read_text(encoding="utf-8")
    t = t.replace("Table_S1_S16.xlsx", "Table_S1_S17.xlsx").replace("投稿材料_补充表_S1_S16.xlsx", "投稿材料_补充表_S1_S17.xlsx")
    t = t.replace("S1–S16", "S1–S17").replace("S1-S16", "S1-S17")
    p.write_text(t, encoding="utf-8")
print("工作簿:", len(openpyxl.load_workbook(en_new, read_only=True).sheetnames), "表")
