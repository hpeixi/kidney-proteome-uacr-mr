# -*- coding: utf-8 -*-
"""在应答表中登记 C3、C4 的处理结果，并更新剩余事项清单。"""
from pathlib import Path

p = Path("审稿意见应答表.md")
t = p.read_text(encoding="utf-8")

rows = """| C3 条件功效与结果矛盾 | 查明 2.1% 是 572 个蛋白的中位可检测效应，不是统一阈值；正文改为逐蛋白比较，并写明 12 个蛋白的效应全部超过各自阈值（12/12），最接近的是 FCGR2A（+0.54% 对 0.46%） | 已改 |
| C4 31 个 eGFR 蛋白无表 | 新增补充表 S10（31 行 × 8 列：基因、蛋白、工具数、最小 F、beta、SE、P、FDR），写入英文与中文工作簿，Results 引用 Supplementary Table S10 | 已改 |
"""

anchor = "| DOI | 稿件、说明信、README、CITATION、DOI.txt 统一改为 Concept DOI 10.5281/zenodo.23851408，旧号 23853798 无残留 | 已改 |\n"
if anchor in t and "C3 条件功效与结果矛盾" not in t:
    t = t.replace(anchor, anchor + rows, 1)

old_tail = "仍需处理（本轮未动）：C2 换主面板、C3 功效与效应量矛盾、C4 31 个 eGFR 蛋白未列表，M1 错义变异敏感性、M2 官方映射、M3 多信号共定位、M4 全部蛋白反向 MR、M7 引言 “unknown” 措辞、M8 与既往 eGFR MR 比对、M9 边界 FDR 稳健性。"
new_tail = ("仍需处理：C2 换主面板（需 UKB-PPP/deCODE 数据），M1 错义变异敏感性、M2 官方映射表、"
            "M3 多信号共定位（需 LD 面板）、M4 全部蛋白反向 MR、M7 引言 “unknown” 措辞、"
            "M8 与既往 eGFR MR 的命中比对、M9 边界 FDR 的 clumping 稳健性。")
if old_tail in t:
    t = t.replace(old_tail, new_tail, 1)

p.write_text(t, encoding="utf-8")
tail = t.splitlines()
print("行数:", len(tail))
print("含 C3 行:", "C3 条件功效与结果矛盾" in t)
print("含 C4 行:", "C4 31 个 eGFR 蛋白无表" in t)
print("C3/C4 仍在剩余清单:", ("C3" in new_tail) or ("C4" in new_tail))
