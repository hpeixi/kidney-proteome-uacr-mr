# -*- coding: utf-8 -*-
"""通过 GitHub Git Data API 推送仓库（无需本地 git），支持删除远端多余文件。

用法：
    $env:GITHUB_TOKEN="ghp_..."
    python repo/tools/publish_github.py --dry-run --prune
    python repo/tools/publish_github.py --prune -m "manuscript v1.0.5"

--prune：把“远端有、本地没有”的路径从仓库删除（Git Data API 默认是合并式更新，
不加 --prune 会残留已删除的文件）。dry-run 不需要 token（公开仓库可匿名读取）。
"""
import argparse
import base64
import json
import os
import ssl
import sys
import urllib.error
import urllib.request
from pathlib import Path

OWNER_REPO = "hpeixi/kidney-proteome-uacr-mr"
BRANCH = "main"
API = "https://api.github.com"
ROOT = Path(__file__).resolve().parents[1]
SKIP = {".git", "__pycache__", ".ipynb_checkpoints"}

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE


def token(required=True):
    t = os.environ.get("GITHUB_TOKEN", "").strip()
    if not t and required:
        print("错误：未设置环境变量 GITHUB_TOKEN，无法推送。", file=sys.stderr)
        print('设置方式（PowerShell）：$env:GITHUB_TOKEN="ghp_xxx"', file=sys.stderr)
        print("获取地址：https://github.com/settings/tokens", file=sys.stderr)
        sys.exit(2)
    return t


def call(url, method="GET", data=None, auth=True):
    headers = {"Accept": "application/vnd.github+json",
               "User-Agent": "kidney-proteome-release/1.0"}
    t = token(required=auth)
    if t:
        headers["Authorization"] = f"Bearer {t}"
    body = json.dumps(data).encode() if data is not None else None
    if body:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=180, context=CTX) as r:
            return json.loads(r.read() or b"{}")
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code} {method} {url}", file=sys.stderr)
        print(e.read()[:400].decode(errors="replace"), file=sys.stderr)
        raise


def local_files():
    out = {}
    for p in ROOT.rglob("*"):
        if p.is_file() and not any(x in p.parts for x in SKIP):
            out[p.relative_to(ROOT).as_posix()] = p
    return out


def remote_state():
    ref = call(f"{API}/repos/{OWNER_REPO}/git/ref/heads/{BRANCH}", auth=False)
    head = ref["object"]["sha"]
    commit = call(f"{API}/repos/{OWNER_REPO}/git/commits/{head}", auth=False)
    tree = call(f"{API}/repos/{OWNER_REPO}/git/trees/{commit['tree']['sha']}?recursive=1", auth=False)
    paths = {t["path"] for t in tree["tree"] if t["type"] == "blob"}
    return head, commit["tree"]["sha"], paths


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-m", "--message", default="manuscript v1.0.5")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--prune", action="store_true", help="删除远端有、本地没有的文件")
    args = ap.parse_args()

    files = local_files()
    head, base_tree, remote = remote_state()
    deletions = sorted(remote - set(files)) if args.prune else []
    additions = sorted(set(files) - remote)
    updates = sorted(set(files) & remote)

    print(f"远端 main: {head[:12]} | 远端文件 {len(remote)}")
    print(f"本地文件 {len(files)}：新增 {len(additions)}，更新 {len(updates)}，"
          f"删除 {len(deletions)}（{'已启用 --prune' if args.prune else '未启用 --prune，将保留'}）")
    for p in deletions[:10]:
        print("  删除", p)

    if args.dry_run:
        print("dry-run 结束：未写入任何内容，也不需要 token")
        return 0

    token()
    tree = []
    for rel, abs_path in sorted(files.items()):
        blob = call(f"{API}/repos/{OWNER_REPO}/git/blobs", "POST",
                    {"content": base64.b64encode(abs_path.read_bytes()).decode(),
                     "encoding": "base64"})
        tree.append({"path": rel, "mode": "100644", "type": "blob", "sha": blob["sha"]})
    for rel in deletions:
        tree.append({"path": rel, "mode": "100644", "type": "blob", "sha": None})
    print("blob 完成:", len(tree) - len(deletions), "个文件，删除项", len(deletions))

    new_tree = call(f"{API}/repos/{OWNER_REPO}/git/trees", "POST",
                    {"base_tree": base_tree, "tree": tree})
    new_commit = call(f"{API}/repos/{OWNER_REPO}/git/commits", "POST",
                      {"message": args.message, "tree": new_tree["sha"], "parents": [head]})
    call(f"{API}/repos/{OWNER_REPO}/git/refs/heads/{BRANCH}", "PATCH",
         {"sha": new_commit["sha"], "force": False})
    print("已推送:", new_commit["sha"])
    print("提交页: https://github.com/%s/commit/%s" % (OWNER_REPO, new_commit["sha"]))
    print("下一步：git tag v1.0.5（或网页 Releases 创建），再发布 Zenodo")


if __name__ == "__main__":
    main()
