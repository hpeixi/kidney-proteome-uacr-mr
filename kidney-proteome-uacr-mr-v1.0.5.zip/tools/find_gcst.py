# -*- coding: utf-8 -*-
"""从 EBI harmonised_list 中定位候选蛋白的 UKB-PPP 单蛋白汇总统计（GCST 号）。"""
import gzip
import re
import ssl
import urllib.request
from pathlib import Path

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
URL = "https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/harmonised_list.txt.gz"
LOCAL = Path("data/harmonised_list.txt.gz")

if not LOCAL.exists():
    print("下载索引 ...")
    req = urllib.request.Request(URL, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=300, context=ctx) as r, open(LOCAL, "wb") as f:
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk)
print("索引大小:", round(LOCAL.stat().st_size / 1024 / 1024, 1), "MB")

keys = {
    "APOA5": ["apolipoprotein a-v"],
    "MCL1": ["mcl-1", "myeloid cell differentiation protein"],
    "ISLR2": ["leucine-rich repeat protein 2"],
    "SERPINA10": ["protein z-dependent protease inhibitor"],
    "ANGPTL1": ["angiopoietin-related protein 1"],
    "PCOLCE": ["procollagen c-endopeptidase enhancer"],
    "RSPO3": ["r-spondin-3", "r-spondin 3"],
    "ITIH1": ["inter-alpha-trypsin inhibitor heavy chain h1"],
    "OAF": ["out at first"],
    "SERPINF2": ["alpha-2-antiplasmin"],
    "FCGR2A": ["immunoglobulin gamma fc region receptor ii-a", "fc-gamma receptor iia"],
    "BAG3": ["bag family molecular chaperone regulator 3", "bag3"],
}

found = {}
with gzip.open(LOCAL, "rt", encoding="utf-8", errors="ignore") as fh:
    header = fh.readline()
    cols = header.rstrip("\n").split("\t")
    print("列:", cols[:8])
    i_acc = 0
    i_trait = cols.index("trait") if "trait" in cols else 2
    for line in fh:
        low = line.lower()
        if "protein" not in low and "levels" not in low:
            continue
        for g, kws in keys.items():
            if any(k in low for k in kws):
                parts = line.rstrip("\n").split("\t")
                found.setdefault(g, []).append(parts[:4])

for g, rows in found.items():
    print(f"\n{g}: {len(rows)} 条")
    for r in rows[:5]:
        print("   ", r)

import json
json.dump(found, open("repo/tools/harmonised_hits.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("\n命中基因数:", len(found))
