﻿param(
    [ValidateSet("All", "GitHub", "Zenodo")]
    [string]$Only = "All",
    [switch]$DryRun,
    [string]$Mode = "Repo",
    [string]$Message = "manuscript v1.0.5: final manuscripts, dual-criteria Figure 2, provenance"
)

$ErrorActionPreference = "Stop"
$here = $PSScriptRoot
$root = Split-Path $here -Parent

Write-Host "== 发布前检查 ==" -ForegroundColor Cyan
Write-Host ("目标: " + $Only + " | 模式: " + $Mode + " | DryRun: " + $DryRun)

$need = @()
if ($Only -eq "All" -or $Only -eq "Zenodo") { $need += "ZENODO_TOKEN" }
if ($Only -eq "All" -or $Only -eq "GitHub") { $need += "GITHUB_TOKEN" }

$missing = @()
foreach ($n in $need) {
    if (-not [Environment]::GetEnvironmentVariable($n)) { $missing += $n }
}
if ($missing.Count -gt 0) {
    Write-Host ""
    Write-Host ("缺少凭据: " + ($missing -join ", ")) -ForegroundColor Yellow
    Write-Host "设置方式（PowerShell，仅当前会话）："
    Write-Host '  $env:GITHUB_TOKEN = "ghp_你的 GitHub token"'
    Write-Host '  $env:ZENODO_TOKEN = "你的 Zenodo token"'
    Write-Host ""
    Write-Host "GitHub: https://github.com/settings/tokens  (classic 选 repo；fine-grained 选 Contents 读写)"
    Write-Host "Zenodo: https://zenodo.org/account/settings/applications/tokens/new/  (deposit:write 与 deposit:actions)"
    exit 2
}

$dry = @()
if ($DryRun) { $dry += "--dry-run" }

if ($Only -eq "All" -or $Only -eq "GitHub") {
    Write-Host ""
    Write-Host "== GitHub：提交并更新 main（含删除远端多余文件）==" -ForegroundColor Cyan
    python (Join-Path $here "publish_github.py") @dry --prune -m $Message
    if ($LASTEXITCODE -ne 0) { Write-Host ("GitHub 步骤失败，退出码 " + $LASTEXITCODE) -ForegroundColor Red; exit $LASTEXITCODE }
}

if ($Only -eq "All" -or $Only -eq "Zenodo") {
    Write-Host ""
    Write-Host "== Zenodo：建新版本并上传 ==" -ForegroundColor Cyan
    if ($Mode -eq "Kit") {
        $zips = Get-ChildItem -Path $root -Filter *.zip | ForEach-Object { $_.FullName }
        python (Join-Path $here "publish_zenodo.py") @dry --files @zips
    } else {
        python (Join-Path $here "publish_zenodo.py") @dry
    }
    if ($LASTEXITCODE -ne 0) { Write-Host ("Zenodo 步骤失败，退出码 " + $LASTEXITCODE) -ForegroundColor Red; exit $LASTEXITCODE }
}

Write-Host ""
Write-Host "== 收尾 ==" -ForegroundColor Green
Write-Host "1. GitHub 页确认 main 最新提交与 figures/Fig2_dual_criteria.png"
Write-Host "2. 远端 figures/Fig2_forest_UACR.* 应已被删除"
Write-Host "3. 需要标签时：git tag v1.0.5，或网页 Releases 创建"
