# -*- coding: utf-8 -*-
"""更新英文稿 md（摘要精简 + 文献题名），生成投稿格式 docx。"""
import json, re
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

MD = "manuscript_en.md"
refs = json.load(open("refs_pubmed.json", encoding="utf-8"))
md = open(MD, encoding="utf-8").read()

# ---------- 1) 摘要精简 ----------
old_abs = md[md.index("**Purpose.**"):md.index("**Keywords:**")].rstrip() + "\n"
new_abs = """**Purpose.** Albuminuria reflects injury to the glomerular filtration barrier and predicts chronic kidney disease progression, but which circulating proteins causally influence it remains uncertain. Most proteome-wide Mendelian randomization (MR) studies have used estimated glomerular filtration rate (eGFR) or a diagnostic label as the outcome.

**Methods.** Two-sample MR used cis protein quantitative trait loci for 3,282 plasma proteins measured in 3,301 European-ancestry individuals, tested against European-ancestry summary statistics for the urinary albumin-to-creatinine ratio (UACR; CKDGen) and eGFR (CKDGen). Instruments were restricted to variants within 500 kb of the encoding gene with F > 10. Effects were estimated by the Wald ratio or inverse-variance weighting, and colocalization was assessed with an approximate Bayes factor.

**Results.** Of 3,282 proteins, 2,162 had at least one genome-wide significant pQTL; after cis restriction, 582 proteins remained evaluable (769 variant–protein pairs; 429 with a single instrument; median minimum F 68.0). Twelve proteins were associated with UACR at false discovery rate < 0.05, with changes from −6.4% to +5.3% per 1-SD higher genetically predicted protein; eight colocalized (PP.H4 ≥ 0.8). Thirty-one proteins were associated with eGFR, and only ITIH1 was significant for both traits with discordant directions. SERPINA10 replicated in an independent panel, whereas BAG3 showed an opposite direction in a larger panel; a reverse-direction analysis supported BAG3 as a consequence rather than a cause.

**Conclusion.** Eight circulating proteins met prespecified genetic and colocalization criteria for an effect on albuminuria. Of the two testable in independent panels, one replicated and one was contradicted; the remaining candidates require replication.
"""
md = md.replace(old_abs, new_abs)

# ---------- 2) 文献加题名 ----------
start = md.index("## References") + len("## References")
end = md.index("## Table")
new_refs = "## References\n\n" + "\n".join(
    f"{i}. {r['ref']}" for i, r in enumerate(refs, 1)) + "\n\n"
md = md[:start] + "\n" + new_refs[len("## References\n\n"):] + md[end:]
open(MD, "w", encoding="utf-8").write(md)

# 校验摘要词数
ab = new_abs
words = len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", re.sub(r"\*\*(Purpose|Methods|Results|Conclusion)\.\*\*", "", ab)))
print("摘要词数:", words)
assert words <= 250, "摘要仍超 250 词"

# ---------- 3) 生成 docx ----------
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))

st = doc.styles["Normal"]
st.font.name = "Times New Roman"
st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
pf = st.paragraph_format
pf.line_spacing = 2.0
pf.space_before = Pt(0)
pf.space_after = Pt(0)

def add_runs(p, text, bold_all=False, size=None):
    """处理 **粗体** 与 ^上标^ 标记。"""
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", text):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            r = p.add_run(seg)
        if bold_all:
            r.bold = True
        if size:
            r.font.size = Pt(size)

body = md.split("\n")
i = 0
while i < len(body):
    ln = body[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True; r.font.size = Pt(12)
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(body) and body[i].startswith("|"):
            cells = [c.strip() for c in body[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cell = t.cell(ri, ci)
                cp = cell.paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        p = doc.add_paragraph()
        if re.match(r"^\*\*Table 1\.\*\*|^\*\*Figure \d\.\*\*", ln):
            add_runs(p, ln)
        else:
            add_runs(p, ln)
    i += 1

# 行号（连续）与页脚页码
sectPr = sec._sectPr
ln = OxmlElement("w:lnNumType"); ln.set(qn("w:countBy"), "1"); ln.set(qn("w:restart"), "continuous")
sectPr.append(ln)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
for tag, attr in [("w:fldChar", "begin"), ("w:instrText", None), ("w:fldChar", "end")]:
    el = OxmlElement(tag)
    if tag == "w:fldChar":
        el.set(qn("w:fldCharType"), attr)
    else:
        el.set(qn("xml:space"), "preserve"); el.text = "PAGE"
    run._r.append(el)

doc.save("manuscript_en.docx")
print("docx 已生成")
