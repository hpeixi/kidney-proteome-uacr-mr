# -*- coding: utf-8 -*-
"""用润色后的 md 重建投稿版 docx，统一 DOI 为 23853798，重打三个包。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
NEW, OLD = "10.5281/zenodo.23853798", "10.5281/zenodo.23851408"

# ---------- 1) 由 md 重建 docx ----------
md = (EN / "manuscript_en.md").read_text(encoding="utf-8")
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, text):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", text):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")
print("docx 已重建")

# ---------- 2) 其余文件换 DOI ----------
def swap_text(p):
    if not p.exists():
        return 0
    t = p.read_text(encoding="utf-8")
    n = t.count(OLD)
    if n:
        p.write_text(t.replace(OLD, NEW), encoding="utf-8")
    return n


def swap_docx(p):
    if not p.exists():
        return 0
    d = Document(p); n = 0
    for para in d.paragraphs:
        if OLD in para.text:
            n += para.text.count(OLD)
            done = False
            for r in para.runs:
                if OLD in r.text:
                    r.text = r.text.replace(OLD, NEW); done = True
            if not done:
                full = para.text.replace(OLD, NEW)
                para.runs[0].text = full
                for r in para.runs[1:]:
                    r.text = ""
    if n:
        d.save(p)
    return n


total = 0
for p in [EN/"cover_letter.md", EN/"README.md", ZH/"manuscript_zh.md", ZH/"manuscript_bilingual.md",
          ZH/"README.md", TR/"metadata/CITATION.cff", Path("repo/metadata/CITATION.cff")]:
    k = swap_text(p); total += k
    print(f"  {p.as_posix()}: {k}")
for p in [EN/"cover_letter.docx", ZH/"manuscript_zh.docx", ZH/"manuscript_bilingual.docx"]:
    k = swap_docx(p); total += k
    print(f"  {p.as_posix()}: {k}")
print("其余文件替换合计:", total)

# ---------- 3) DOI.txt 记录两个号 ----------
p = TR / "metadata" / "DOI.txt"
t = p.read_text(encoding="utf-8")
t = t.replace("DOI cited in the manuscript: 10.5281/zenodo.23851408 (Concept DOI)",
              "DOI cited in the manuscript: 10.5281/zenodo.23853798 (version v1.0.4)")
t = t.replace("v1.0.4   DOI: 10.5281/zenodo.23851408\n",
              "v1.0.4   Version DOI: 10.5281/zenodo.23853798  (this exact snapshot, cited in the manuscript)\n"
              "         Concept DOI: 10.5281/zenodo.23851408  (all versions)\n")
p.write_text(t, encoding="utf-8")
print("\nDOI.txt 片段:")
for ln in t.splitlines()[:7]:
    print("  ", ln)

# ---------- 4) 重打包 ----------
for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
