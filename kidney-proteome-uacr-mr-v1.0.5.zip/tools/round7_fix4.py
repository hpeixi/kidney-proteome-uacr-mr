# -*- coding: utf-8 -*-
"""收尾：英文图注压缩回 12 页；中文包按 P=0.47 与双判据口径修正并重建。"""
import re
import shutil
import zipfile
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

ROOT = Path(".")
EN = ROOT / "交付包/01_英文资料包"
ZH = ROOT / "交付包/02_中文资料包"
RES = ROOT / "交付包/03_可溯源资料包/results"

# ---------- 英文图注 ----------
p_en = EN / "manuscript_en.md"
en = p_en.read_text(encoding="utf-8")
old_cap = en[en.index("**Figure 2.**"):en.index("**Figure 3.**")]
new_cap = ("**Figure 2.** Colocalization and replication displayed together for the 12 UACR-associated proteins, "
           "ordered by PP.H4. (A) PP.H4; dashed line at 0.8. (B) Change in UACR per 1-SD higher protein (95% CI); "
           "inner symbol is the Steiger tier (square strong, triangle moderate, circle inconclusive). "
           "(C) Whether each criterion was met. Colour encodes replication status.\n\n")
en = en.replace(old_cap, new_cap, 1)
p_en.write_text(en, encoding="utf-8")
print("英文图注词数:", len(new_cap.split()), "(原", len(old_cap.split()), ")")

# ---------- 中文修订 ----------
zh_subs = [
 ("SERPINA10 在独立面板中方向一致地复现，而 BAG3 在更大面板中方向相反；反向分析支持 BAG3 为结果而非原因。",
  "ISLR2、ITIH1 与 PCOLCE 在独立面板中方向一致，SERPINA10 结果不一致，OAF 为阴性，ANGPTL1 不可评估，BAG3 方向相反；与 eGFR 列表的重叠不超过随机预期（P = 0.47）。"),
 ("**结论**　8 种循环蛋白符合预设的遗传与共定位标准。两个可独立检验的蛋白中，一个复现、一个被否定；其余候选仍需复现。",
  "**结论**　8 种蛋白符合预设的遗传与共定位标准，但无一在一般人群血浆中获得独立平台复现。在本数据集中，以 eGFR 为锚点的筛选不能替代以白蛋白尿为结局的筛选，且该替代性检验效能有限；该流程可作为蛋白组筛选的可行性示范与阴性对照。"),
 ("观察性关联难以解释，因为循环蛋白浓度本身会随肾功能下降而改变，从而产生反向因果与疾病严重程度混杂。",
  "观察性关联难以解释，因为循环蛋白浓度本身会随肾功能下降而改变，从而产生反向因果与疾病严重程度混杂；血浆蛋白组的观察性研究已报道若干与白蛋白尿相关的蛋白[19]，但尚无研究以白蛋白尿为主要结局开展 cis-pQTL 筛选。"),
 ("SERPINA10 方向一致地复现（3 个顺式变异；β = −0.0098，SE 0.0028，P = 4.0×10⁻⁴）；BAG3 在 UKB-PPP 面板中被否定",
  "SERPINA10 在一个数据集方向一致（3 个顺式变异；β = −0.0098，SE 0.0028，P = 4.0×10⁻⁴），但含 4 个工具变量的数据集方向相反（β = 0.005，P = 0.28；Cochran's Q = 14.2，P = 0.007），判为不一致；BAG3 在 UKB-PPP 面板中被否定"),
 ("UACR 与 eGFR 的结果几乎不重叠，提示两种表型不可互换，支持在蛋白组因果推断中将白蛋白尿视为独立结局。",
  "以 eGFR 为锚点的列表不应默认替代以白蛋白尿为结局的列表，但本研究的重叠检验很弱：582 种蛋白中 12 与 30 个命中的组合下，至少需 3 个重叠蛋白才达 P < 0.05（P(X≥3) = 0.020，期望重叠 0.62），因此本研究只能检出实质重叠，不能证明无重叠，也不足以说明以 eGFR 为导向的筛选普遍无效。"),
 ("未进行实验验证，这些蛋白应视为候选。",
  "未进行实验验证，这些蛋白应视为候选。重叠检验为探索性分析，效能极低，无法区分无重叠与中等重叠。"),
 ("本 cis-pQTL MR 与共定位分析识别出 8 种白蛋白尿候选蛋白，其中 1 种在独立面板中复现、1 种被否定。结果支持白蛋白尿作为区别于 eGFR 的表型，并提供了可供功能研究优先验证的清单。",
  "本 cis-pQTL MR 与共定位分析识别出 8 种白蛋白尿候选蛋白，但无一在一般人群血浆中获得独立平台复现。结果支持将该流程作为蛋白组筛选的可行性示范与阴性对照，并为功能研究提供优先清单。"),
 ("**图 2.** 与 UACR 相关的 12 种蛋白的 cis-pQTL MR 估计；BAG3 以红色标出，表示未复现。",
  "**图 2.** 12 种 UACR 相关蛋白的共定位与独立复现双判据并列呈现，按 PP.H4 排序。（A）共享因果变异后验概率，虚线为 PP.H4 = 0.8；（B）遗传预测蛋白每升高 1 个标准差对 UACR 的影响（95% CI），内层符号表示 Steiger 分档；（C）两项判据是否各自成立。颜色编码复现状态。"),
]
rep_status = {"ITIH1": "方向一致（CSF）", "OAF": "阴性（CSF）", "PCOLCE": "方向一致（CSF）",
              "SERPINA10": "不一致（CSF）", "BAG3": "方向相反（血浆 Olink）"}

# Steiger Z
steiger = None
for f in RES.glob("*steiger*"):
    d = pd.read_csv(f)
    zc = [c for c in d.columns if c.lower() in ("z", "steiger_z", "z_steiger")]
    if zc and "gene" in d.columns:
        steiger = {r.gene: float(getattr(r, zc[0])) for r in d.itertuples()}
        print("Steiger 表:", f.name, list(d.columns))
        break

def fix_zh(path):
    s = path.read_text(encoding="utf-8")
    for a, b in zh_subs:
        if a in s:
            s = s.replace(a, b, 1)
        else:
            print("  未匹配:", path.name, a[:32])
    out = []
    for ln in s.split("\n"):
        if ln.startswith("| ") and ln.count("|") >= 7:
            c = [x.strip() for x in ln.strip().strip("|").split("|")]
            if c[0] in rep_status:
                if len(c) == 7:
                    c[6] = rep_status[c[0]]
                ln = "| " + " | ".join(c) + " |"
        out.append(ln)
    s = "\n".join(out)
    # 参考文献 16-19 与英文对齐
    en_refs = re.findall(r"^(\d{1,2})\. (.+)$", p_en.read_text(encoding="utf-8"), re.M)
    tail = {int(n): t for n, t in en_refs if int(n) >= 16}
    if tail and "## 参考文献" in s:
        have = {int(n) for n, _ in re.findall(r"^(\d{1,2})\. (.+)$", s, re.M) if s}
        for n in sorted(tail):
            if n not in have:
                s = s.rstrip() + f"\n{n}. {tail[n]}"
        print("  参考文献补至:", sorted(tail))
    path.write_text(s, encoding="utf-8")
    return s

for f in ("manuscript_zh.md", "manuscript_bilingual.md"):
    p = ZH / f
    if p.exists():
        t = fix_zh(p)
        print(f, "| 含 P = 0.47:", "P = 0.47" in t, "| 含不可互换:", "不可互换" in t,
              "| 含 [19]:", "[19]" in t)

# ---------- 图件同步 ----------
for ext in ("png", "pdf", "tif"):
    src = EN / "figures" / f"Fig2_dual_criteria.{ext}"
    if src.exists():
        shutil.copy2(src, ZH / "figures" / f"Fig2_dual_criteria.{ext}")
for old in ("Fig2_forest_UACR.png", "Fig2_forest_UACR.pdf"):
    o = ZH / "figures" / old
    if o.exists():
        o.unlink()
print("02/figures:", sorted(x.name for x in (ZH / "figures").glob("Fig2*")))

# ---------- 通用 docx 构建 ----------
def build(md_text, out_path, size=12, table_pt=6.5, line_numbers=True):
    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
        setattr(sec, m, Cm(2.2))
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"; st.font.size = Pt(size)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")
    st.paragraph_format.line_spacing = 2.0
    st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)

    def runs(p, s):
        for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
            if not seg:
                continue
            if seg.startswith("**") and seg.endswith("**"):
                r = p.add_run(seg[2:-2]); r.bold = True
            elif seg.startswith("^") and seg.endswith("^"):
                r = p.add_run(seg[1:-1]); r.font.superscript = True
            else:
                p.add_run(seg)

    lines = md_text.split("\n"); i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln or ln == "---":
            i += 1; continue
        if ln.startswith("### "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
            r = p.add_run(ln[4:]); r.bold = True; r.italic = True
        elif ln.startswith("## "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
            r = p.add_run(ln[3:]); r.bold = True
        elif ln.startswith("# "):
            p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
            r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            t = doc.add_table(rows=len(rows), cols=len(rows[0]))
            t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
            for ri, row in enumerate(rows):
                for ci, val in enumerate(row):
                    cp = t.cell(ri, ci).paragraphs[0]
                    cp.paragraph_format.line_spacing = 1.0
                    cp.paragraph_format.space_after = Pt(0)
                    r = cp.add_run(val); r.font.size = Pt(table_pt)
                    if ri == 0:
                        r.bold = True
            continue
        else:
            runs(doc.add_paragraph(), ln)
        i += 1

    if line_numbers:
        el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
        sec._sectPr.append(el)
    fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run()
    c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
    c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
    for x in (c1, it, c2):
        run._r.append(x)
    doc.save(out_path)

build(p_en.read_text(encoding="utf-8"), EN / "manuscript_en.docx")
for name in ("manuscript_zh", "manuscript_bilingual"):
    mp = ZH / f"{name}.md"
    if mp.exists():
        build(mp.read_text(encoding="utf-8"), ZH / f"{name}.docx")
        print("重建", name, ".docx")

# ---------- 校验与打包 ----------
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("英文摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")

for pkg, folder, label in ((EN, EN, "01_英文资料包"), (ZH, ZH, "02_中文资料包")):
    z = pkg.with_suffix(".zip") if pkg == EN else Path("交付包/02_中文资料包.zip")
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(label) / f.relative_to(folder))
    print(z.name, len(zipfile.ZipFile(z).namelist()), "条目")
