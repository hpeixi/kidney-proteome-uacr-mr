# -*- coding: utf-8 -*-
"""第五轮修订（修正重复行）：Table 1 九列 + M1/M2/M3/M4/M5 + MINOR 2/3/5。"""
import re
from pathlib import Path

import pandas as pd

EN = Path("交付包/01_英文资料包")
TR = Path("交付包/03_可溯源资料包")
RES = TR / "results"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

res = pd.read_csv(RES / "cis_mr_results.csv")
coloc = pd.read_csv(RES / "coloc_final.csv").set_index("gene")
st = pd.read_csv(RES / "S17_steiger.csv").set_index("Gene")

GENES = ["ISLR2", "ITIH1", "OAF", "APOA5", "SERPINA10", "SERPINF2", "BAG3",
         "MCL1", "PCOLCE", "FCGR2A", "ANGPTL1", "RSPO3"]
REP = {
    "ISLR2": "Direction-consistent (serum; neurological cohort) [17]",
    "ITIH1": "Direction-consistent (CSF; lowest confidence) [18]",
    "PCOLCE": "Direction-consistent (CSF; neurological cohort) [18]",
    "OAF": "Null (CSF; neurological cohort) [18]",
    "SERPINA10": "Conflict (CSF; neurological cohort) [18]†",
    "BAG3": "Opposite (plasma; Olink) [5]",
    "ANGPTL1": "Not evaluable",
}
SUP = str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")

def sci(x):
    s = f"{x:.1e}"
    m, e = s.split("e")
    return f"{m}×10{str(int(e)).translate(SUP)}"

def tier(z):
    return "strong" if z >= 5 else ("moderate" if z >= 2 else "inconclusive")

st["Tier"] = [tier(z) for z in st["Steiger Z"]]
st.reset_index().to_csv(RES / "S17_steiger.csv", index=False, encoding="utf-8-sig")

rows = ["| Gene | Instruments | Change per SD (%) | 95% CI | P | FDR | PP.H4 | Replication | Steiger |",
        "|---|---|---|---|---|---|---|---|---|"]
for g in GENES:
    sub = res[res.gene == g].sort_values("n_snp")   # 主表用单工具数据集
    r = sub.iloc[0]
    pct = f"{r.UACR_beta*100:+.1f}"
    lo = (r.UACR_beta - 1.96 * r.UACR_se) * 100
    hi = (r.UACR_beta + 1.96 * r.UACR_se) * 100
    ci = f"{lo:.1f} to {hi:.1f}"
    h4 = f"{coloc.loc[g, 'H4']:.3f}"
    rows.append(f"| {g} | {int(r.n_snp)} | {pct} | {ci} | {sci(r.UACR_p)} | {sci(r.UACR_fdr)} | {h4} | {REP.get(g, 'No data')} | {tier(st.loc[g, 'Steiger Z'])} |")

table = "\n".join(rows) + """

†SERPINA10 has two aptamer datasets in the exposure resource: the single-instrument estimate shown here, and a four-instrument dataset (β = 0.005, P = 0.28; Cochran's Q = 14.2, P = 0.007) that does not agree with it in direction. Steiger tiers: strong (Z ≥ 5), moderate (2 ≤ Z < 5), inconclusive (Z < 2); the lowest is MCL1 (Z = 0.58)."""

start = md.index("| Gene | Instruments")
end = md.index("## Supplementary material")
md = md[:start] + table + "\n\n" + md[end:]

R = [
 ("SERPINA10 replicated in the same direction (three cis variants; β = −0.0098, SE 0.0028, P = 4.0×10⁻⁴).",
  "An additional dataset for SERPINA10 gave β = −0.0098 (SE 0.0028, P = 4.0×10⁻⁴) in the direction of the primary estimate, but its four-instrument dataset gave β = 0.005 (P = 0.28) with one instrument pointing the other way and significant heterogeneity (Cochran's Q = 14.2, P = 0.007); the two datasets therefore conflict."),
 ("SERPINA10 is represented by two aptamer datasets; the estimate in Table 1 uses the single-instrument dataset, whereas the multi-instrument dataset gave β = 0.005 (P = 0.28) with one instrument pointing the other way (per-instrument Wald ratios −0.015 to +0.013; IVW over four instruments β = −0.007, Cochran's Q = 14.2, P = 0.007), so the two datasets do not agree in direction.",
  "Both SERPINA10 datasets are listed in Supplementary Table S7."),
 ("only ITIH1 reached significance for both, in opposite directions.",
  "only ITIH1 reached significance for both, in opposite directions, on the weakest evidence in Table 1."),
 ("ISLR2 and PCOLCE were direction-consistent in independent SomaScan panels, SERPINA10 inconsistently, ANGPTL1 was not evaluable, BAG3 reversed and OAF was null",
  "ISLR2, ITIH1 and PCOLCE were direction-consistent in independent panels (one serum, two cerebrospinal fluid), SERPINA10 inconsistently, ANGPTL1 was not evaluable, BAG3 reversed and OAF was null"),
 ("a serum SomaScan panel assembled in a study of neurological disease [17] (2,917 European-ancestry participants) for ISLR2, and a cerebrospinal fluid SomaScan panel from a neurological cohort [18] (3,506 participants) for PCOLCE, ITIH1 and OAF",
  "a serum SomaScan panel from two isolated populations that assayed 184 neuro-related proteins [17] (2,917 participants in the GWAS Catalog entry) for ISLR2, and a cerebrospinal fluid SomaScan panel from a neurological cohort of clinically normal and neurodegenerative disease cases [18] (3,506 participants) for PCOLCE, ITIH1 and OAF"),
 ("The replication panels are SomaScan-based, and three of the four are cerebrospinal fluid rather than plasma, so agreement cannot exclude aptamer or biofluid effects; only BAG3 was tested on another platform (Olink).",
  "The replication panels are SomaScan-based, come from neurological cohorts rather than general populations, and three of the four are cerebrospinal fluid rather than plasma, so agreement cannot exclude aptamer, biofluid or population effects; only BAG3 was tested in plasma on another platform (Olink), and no candidate was replicated in plasma from a general population."),
 ("The two are not interchangeable: eGFR measures filtration capacity, albuminuria barrier integrity.",
  "The two are not interchangeable: eGFR measures filtration capacity, and albuminuria measures barrier integrity."),
 ("Which circulating proteins influence it is largely unresolved [10].",
  "Which circulating proteins influence it is largely unresolved [6]."),
]
fails = []
for a, b in R:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        fails.append(a[:50])
print("未匹配:", fails if fails else "无")
if fails:
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])))
print("表格行数:", table.count("\n| ") + 1 - 3)
