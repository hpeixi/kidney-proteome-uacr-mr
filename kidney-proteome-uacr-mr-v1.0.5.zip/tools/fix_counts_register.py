# -*- coding: utf-8 -*-
"""修正 31 行 vs 30 基因的口径，重建 docx，并把第三轮意见登记进应答表。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

a = "Thirty-one proteins were associated with eGFR; estimates for all 31 are given in Supplementary Table S10."
b = ("Thirty-one aptamer datasets, representing 30 proteins (CST6 was measured twice), were associated with eGFR; "
     "estimates for all 31 are given in Supplementary Table S10.")
assert a in md
md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

z = OUT / "01_英文资料包.zip"
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
with zipfile.ZipFile(z) as zf:
    print("01 zip:", len(zf.namelist()), "条目, 完整=", zf.testzip() is None)

# 应答表登记
p = Path("审稿意见应答表.md")
t = p.read_text(encoding="utf-8")
add = """
## 八、第三轮意见处理（Major Revision）

| 条目 | 处理 | 状态 |
|---|---|---|
| M2 复制面板平台/体液未说明 | 查 GWAS Catalog：ISLR2 为血清 SomaScan（2,917 人），PCOLCE/ITIH1/OAF 为脑脊液 SomaScan（3,506 人），仅 BAG3 为 Olink 血浆；Methods 写明并引 S13，Limitations 增写“同平台、且三个为脑脊液，不能排除适配子或体液效应” | 已改 |
| M3 ITIH1 证据最弱却权重最高 | Results 增写：单错义工具、PP.H4 0.614 低于预设阈值、位点位于多信号基因簇，明确标注证据最弱 | 已改 |
| M4 SERPINA10 判定过宽 | Table 1 改为 Inconsistently replicated；摘要、讨论、结论同步改为“三个方向一致 + 一个不一致” | 已改 |
| M6 不重叠缺统计检验 | 超几何检验：582 个可评估蛋白、12 UACR、30 eGFR（31 行为 CST6 两个 aptamer），期望重叠 0.62，观测 1，P = 0.47；讨论改为“不能证明两者蛋白架构不同”，并引 S14 | 已改 |
| M7 “缺 LD”表述不准确 | 三处改为单因果变异假设与 100 kb 窗口是误差来源，并说明 coloc.abf 本身不使用 LD | 已改 |
| M8 功效论证近乎循环 | 删去“全部达标”句，改为说明该比较接近同义反复，并点出 FCGR2A、SERPINA10、ITIH1 最不稳；FCGR2A 数值统一为 +0.5% | 已改 |
| MINOR 排版与 F 表述 | 补 “(CKDGen). Instruments” 空格；改为 “weakest instrument F = 29.8”；新增 S13/S14；31 行 vs 30 基因口径已注明 | 已改 |

仍未解决：M1 换主面板（需 UKB-PPP/deCODE 数据）、M5 全部蛋白反向 MR 与正式 Steiger（需全基因组蛋白效应）、M2 的换平台复验（需 Olink 面板）、clumping 阈值稳健性（需 LD）、与既往 eGFR MR 的逐项比对（需其命中表）、图 2/图 4 改绘与 STROBE-MR 清单纯英文版并入补充材料。
"""
if "## 八、第三轮意见处理" not in t:
    t = t.rstrip() + "\n" + add
p.write_text(t, encoding="utf-8")
print("应答表行数:", len(t.splitlines()), "| 含第八节:", "## 八、第三轮意见处理" in t)
