# -*- coding: utf-8 -*-
"""测试各 pQTL 数据源在本机的可访问性：EBI FTP 目录、OpenGWAS token。"""
import json
import re
import ssl
import urllib.request

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE


def fetch(url, timeout=40):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    r = urllib.request.urlopen(req, timeout=timeout, context=ctx)
    return r.status, r.read().decode("utf-8", "ignore")


ranges = [
    "GCST90468001-GCST90469000",  # UKB-PPP (Sun 2023)
    "GCST90246001-GCST90247000",  # UKB-PPP 另一段
    "GCST90248001-GCST90249000",
    "GCST90249001-GCST90250000",
    "GCST90860001-GCST90861000",
]
base = "https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/"
for rg in ranges:
    try:
        s, body = fetch(base + rg + "/")
        dirs = re.findall(r'href="(GCST\d+)/"', body)
        print(f"{rg}: HTTP {s}, 子目录 {len(dirs)}, 例: {dirs[:5]}")
    except Exception as e:
        print(f"{rg}: 失败 {type(e).__name__} {str(e)[:70]}")

# 逐个检查候选 GCST 是否存在
cands = {
    "APOA5": "GCST90246544", "MCL1": "GCST90248433", "SERPINA10": "GCST90249198",
    "ANGPTL1": "GCST90246507", "PCOLCE": "GCST90860486", "RSPO3": "GCST90860078",
    "BAG3": "GCST90468416",
}
print("\n== 候选文件探测")
for g, gcst in cands.items():
    prefix = gcst[:6] + "001" if False else None
    for rg in ranges:
        lo = int(re.search(r"GCST(\d+)-", rg).group(1))
        hi = int(re.search(r"-GCST(\d+)", rg).group(1))
        if lo <= int(gcst[4:]) <= hi:
            url = f"{base}{rg}/{gcst}/"
            try:
                s, body = fetch(url)
                files = re.findall(r'href="([^"]+\.(?:tsv\.gz|h\.tsv\.gz|txt\.gz))"', body)
                print(f"  {g} {gcst}: HTTP {s}, 文件 {files}")
            except Exception as e:
                print(f"  {g} {gcst}: 失败 {type(e).__name__} {str(e)[:60]}")
            break

# OpenGWAS token
tok = open(".opengwas_token", encoding="utf-8").read().strip()
try:
    s, body = fetch("https://api.opengwas.io/api/user", timeout=30)
except Exception:
    req = urllib.request.Request("https://api.opengwas.io/api/user",
                                 headers={"Authorization": f"Bearer {tok}", "User-Agent": "Mozilla/5.0"})
    try:
        r = urllib.request.urlopen(req, timeout=30, context=ctx)
        print("\nOpenGWAS token:", r.status, r.read().decode()[:120])
    except Exception as e:
        print("\nOpenGWAS token 测试失败:", type(e).__name__, str(e)[:80])
