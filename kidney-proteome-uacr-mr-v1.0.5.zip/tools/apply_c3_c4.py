# -*- coding: utf-8 -*-
"""落实 C3（功效口径）与 C4（31 个 eGFR 蛋白表）：改稿、加工人表 S10、重建 docx、重打包。"""
import re
import zipfile
from pathlib import Path

import openpyxl
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
RES = TR / "results"

# ---------- 1) S10 数据 ----------
s10 = pd.read_csv(RES / "S10_eGFR_hits.csv")
assert len(s10) == 31, len(s10)
print("S10 行数:", len(s10), "| 列:", list(s10.columns))

# ---------- 2) 写入两个工作簿 ----------
def add_sheet(src, dst, sheet="S10_eGFR_hits"):
    wb = openpyxl.load_workbook(src)
    if sheet in wb.sheetnames:
        del wb[sheet]
    ws = wb.create_sheet(sheet)
    ws.append(list(s10.columns))
    for _, row in s10.iterrows():
        ws.append(list(row.values))
    wb.save(dst)
    wb.close()

en_old = EN / "supplementary" / "Table_S1_S9.xlsx"
en_new = EN / "supplementary" / "Table_S1_S10.xlsx"
add_sheet(en_old, en_new)
zh_old = ZH / "supplementary" / "投稿材料_补充表_S1_S9.xlsx"
zh_new = ZH / "supplementary" / "投稿材料_补充表_S1_S10.xlsx"
add_sheet(zh_old, zh_new)
for f in (en_old, zh_old):
    f.unlink()
wb = openpyxl.load_workbook(en_new, read_only=True)
print("英文工作簿工作表:", wb.sheetnames)
wb.close()

# ---------- 3) 改稿 ----------
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
subs = [
 ("Conditional power, derived from each standard error, gave a median detectable change of 3.6% in UACR at 80% power with Bonferroni alpha, and 2.1% at FDR 0.05.",
  "Power was computed for each protein from its own standard error; the median detectable change was 3.6% in UACR at 80% power with Bonferroni alpha and 2.1% at FDR 0.05. These are medians across proteins, not a common threshold: each protein has its own detectable effect, tabulated in Supplementary Table S5, and observed effects are compared against those per-protein values."),
 ("Only three of the twelve (ISLR2, ITIH1, OAF) also passed the Bonferroni threshold of 8.6×10⁻⁵; the remaining nine lay between that threshold and FDR 0.05.",
  "Only three of the twelve (ISLR2, ITIH1, OAF) also passed the Bonferroni threshold of 8.6×10⁻⁵; the remaining nine lay between that threshold and FDR 0.05. All twelve exceeded their own 80% power threshold at FDR alpha; the narrowest margin was FCGR2A (+0.54% against 0.46%)."),
 ("Thirty-one proteins were associated with eGFR.",
  "Thirty-one proteins were associated with eGFR; estimates for all 31 are given in Supplementary Table S10."),
 ("S9 data sources and sample sizes. All tables are provided in a single workbook.",
  "S9 data sources and sample sizes; S10 all 31 proteins associated with eGFR. All tables are provided in a single workbook."),
]
fails = []
for a, b in subs:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        fails.append(a[:50])
if fails:
    print("未匹配:", fails)
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

# ---------- 4) 重建 docx ----------
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

# ---------- 5) 核验 + 重打包 ----------
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("\n摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)), "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
for k in ["Supplementary Table S10", "0.54%", "0.46%", "per-protein values", "S10 all 31"]:
    print(f"  {k}: {k in txt}")

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
