# -*- coding: utf-8 -*-
"""收尾两处 MINOR：删去跨尺度“效应更大”比较、把 STROBE-MR 清单并入补充材料；重建 docx 与包。"""
import re
import shutil
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

a1 = "kept the direction of the primary estimate, although their effect sizes were larger, whereas OAF did not replicate"
b1 = "kept the direction of the primary estimate, whereas OAF did not replicate"
assert a1 in md
md = md.replace(a1, b1, 1)

a2 = "S16 evidence tiers for the 12 UACR-associated proteins. All tables are provided in a single workbook."
b2 = ("S16 evidence tiers for the 12 UACR-associated proteins. All tables are provided in a single workbook; "
      "the completed STROBE-MR checklist is supplied as a separate file.")
if a2 in md:
    md = md.replace(a2, b2, 1)
else:
    print("补充材料清单句未匹配，改为追加")
    md = md.replace("All tables are provided in a single workbook.",
                    "All tables are provided in a single workbook; the completed STROBE-MR checklist is supplied as a separate file.", 1)
md_path.write_text(md, encoding="utf-8")

# STROBE 文件移入 supplementary/
sup = EN / "supplementary"
for f in ["STROBE-MR_checklist_EN.docx", "STROBE-MR_checklist_EN.md"]:
    src = EN / f
    if src.exists():
        shutil.move(str(src), str(sup / f))
print("supplementary 目录:", sorted(p.name for p in sup.glob("*")))

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(3)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(8.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("摘要:", len(re.findall(pat, ab)), "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
print("含 larger 比较:", "effect sizes were larger" in txt, "| 含 STROBE 说明:", "STROBE-MR checklist is supplied" in txt)

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
with zipfile.ZipFile(z) as zf:
    print("01 zip:", len(zf.namelist()), "条目, 完整=", zf.testzip() is None)
