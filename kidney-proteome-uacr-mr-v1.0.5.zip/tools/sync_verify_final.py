# -*- coding: utf-8 -*-
"""同步分析脚本进溯源包、重算校验值、交付前总核验。"""
import hashlib
import re
import shutil
import zipfile
from pathlib import Path

from docx import Document

ROOT = Path(".")
EN = ROOT / "交付包/01_英文资料包"
ZH = ROOT / "交付包/02_中文资料包"
TR = ROOT / "交付包/03_可溯源资料包"
REPO = ROOT / "repo"

# 1) 同步脚本
dst = TR / "scripts"
dst.mkdir(exist_ok=True)
keep = ("round5.py", "round5b.py", "round6.py", "round7_data.py", "steiger2.py",
        "m1_exclude_missense.py", "replication_extended.py", "evidence_tiers.py",
        "fig2_dual_criteria.py", "docx_build.py", "finalize_provenance.py")
n = 0
for name in keep:
    for src in (REPO / "tools" / name, REPO / name):
        if src.exists():
            shutil.copy2(src, dst / name)
            n += 1
            break
print("同步脚本:", n, "| 溯源包脚本总数:", len(list(dst.glob('*.py'))))

# 2) 重算 SHA256
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

targets = []
for sub in ("results", "scripts", "metadata", "references", "docs"):
    d = TR / sub
    if d.exists():
        targets += sorted(p for p in d.rglob("*") if p.is_file())
targets += sorted((EN / "figures").glob("*"))
targets += sorted((ZH / "figures").glob("*"))
lines = [f"{sha(p)}  {p.relative_to(ROOT).as_posix()}" for p in targets if p.is_file()]
(TR / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("SHA256 条目:", len(lines))

# 3) 总核验
def txt_of(p):
    d = Document(p)
    return "\n".join(x.text for x in d.paragraphs), d

et, ed = txt_of(EN / "manuscript_en.docx")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*"
print("英文摘要:", len(re.findall(pat, et[et.index("Purpose."):et.index("Keywords:")])),
      "| 文献:", len([p for p in ed.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(ed.tables[0].rows)}x{len(ed.tables[0].columns)}")
print("  润色落点:", "The list matters less than what the screen shows" in et,
      "| 重复句已删:", "with 12 and 30 hits among 582 proteins" not in et,
      "| 结论句首:", "In this dataset, eGFR-anchored screening was no substitute" in et)

zt, zd = txt_of(ZH / "manuscript_zh.docx")
zrows = [[c.text.strip() for c in r.cells] for r in zd.tables[0].rows]
print("中文表:", f"{len(zrows)}x{len(zrows[0])}", "| 中文符号:", "至" in zrows[1][3],
      "| 仅 2 种残留:", "仅 2 种" in zt, "| 7 种有独立数据:", "其中 7 种有独立数据" in zt)

z = zipfile.ZipFile("交付包/03_可溯源资料包.zip")
print("03 包:", len(z.namelist()), "| 完好:", z.testzip() is None,
      "| 含 PROVENANCE:", any("PROVENANCE" in n for n in z.namelist()),
      "| 含 SHA256SUMS:", any("SHA256SUMS" in n for n in z.namelist()))
for zp in ("交付包/01_英文资料包.zip", "交付包/02_中文资料包.zip"):
    zz = zipfile.ZipFile(zp)
    print(zp, len(zz.namelist()), "| 完好:", zz.testzip() is None)
