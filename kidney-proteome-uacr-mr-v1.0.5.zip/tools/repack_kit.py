# -*- coding: utf-8 -*-
"""重打 04 工具包：纳入修正后的上传脚本，重算校验值并核验。"""
import hashlib
import zipfile
from pathlib import Path

PKG = Path("交付包")
KIT = PKG / "04_发布工具包"

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

lines = [f"{sha(p)}  {p.relative_to(KIT).as_posix()}" for p in sorted(KIT.rglob("*")) if p.is_file()]
(KIT / "SHA256SUMS_KIT.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

out = PKG / "04_发布工具包.zip"
if out.exists():
    out.unlink()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in KIT.rglob("*"):
        if f.is_file():
            zf.write(f, Path("04_发布工具包") / f.relative_to(KIT))

z = zipfile.ZipFile(out)
print("条目:", len(z.namelist()), "| 完好:", z.testzip() is None, "| %.2f MB" % (out.stat().st_size / 1e6))
for n in z.namelist():
    print("  ", n)
inner = z.read("04_发布工具包/tools/publish_zenodo.py").decode("utf-8")
print("含路径修正:", "expanduser().resolve()" in inner)
print("含清空逻辑:", "清除草稿内已有文件" in inner)
sums = z.read("04_发布工具包/SHA256SUMS_KIT.txt").decode("utf-8").strip().split("\n")
print("清单条数:", len(sums))
bad = 0
for line in sums:
    h, rel = line.split("  ", 1)
    got = hashlib.sha256((KIT / rel).read_bytes()).hexdigest()
    bad += int(got != h)
print("校验不符:", bad)
