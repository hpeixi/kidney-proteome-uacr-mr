# -*- coding: utf-8 -*-
"""强化 negative control 表述 + 重绘 Fig2（共定位 × 复制双判据）。"""
import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.lines import Line2D

EN = Path("交付包/01_英文资料包")
TR = Path("交付包/03_可溯源资料包")
RES = TR / "results"

md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"

# ---------- 1) 文字：普适性表述 ----------
R = [
 ("That negative control is the main result. With 12 UACR and 30 eGFR hits among 582 evaluable proteins, expected overlap is 0.62 and one is compatible with chance (P = 0.47, Supplementary Table S14). We therefore do not claim that the two traits have different protein architectures; we show that a screen built on eGFR does not recover an albuminuria-directed list, which is the practical question a proteome-wide screen faces.",
  "That negative control is the main result, and it generalizes beyond this screen. With 12 UACR and 30 eGFR hits among 582 evaluable proteins, expected overlap is 0.62 and one is compatible with chance (P = 0.47, Supplementary Table S14). Any proteome-wide MR anchored on eGFR inherits the same constraint: the proteins it prioritizes are not a substitute for those prioritized on the barrier phenotype, and an eGFR-derived list should not be read as a proxy for albuminuria biology. We therefore do not claim different protein architectures; we show that a screen built on eGFR does not recover an albuminuria-directed list, which is the practical question a proteome-wide screen faces."),
 ("eGFR is not a substitute; the five proteins surviving missense exclusion are candidates for validation.",
  "eGFR-anchored screens cannot substitute for this approach; the five proteins surviving missense exclusion are candidates for validation."),
 ("but no protein replicated in plasma on an independent platform",
  "but no protein replicated in plasma independently"),
 # 图 2 图注
 ("**Figure 2.** Cis-pQTL MR estimates for the 12 proteins associated with UACR; BAG3 is shown in red as not replicated.",
  "**Figure 2.** Cis-pQTL MR estimates for the 12 UACR-associated proteins, coded by two criteria: marker fill shows whether the region passed the colocalization threshold (filled, PP.H4 ≥ 0.8; open, below), and colour shows the independent replication status."),
]
fails = []
for a, b in R:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        fails.append(a[:50])
print("未匹配:", fails if fails else "无")
if fails:
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])))

# ---------- 2) 重绘 Fig2 ----------
res = pd.read_csv(RES / "cis_mr_results.csv")
coloc = pd.read_csv(RES / "coloc_final.csv").set_index("gene")
REP = {
    "ISLR2": "Direction-consistent", "ITIH1": "Direction-consistent", "PCOLCE": "Direction-consistent",
    "SERPINA10": "Conflict", "BAG3": "Opposite", "OAF": "Null", "ANGPTL1": "Not evaluable",
}
GENES = ["ISLR2", "ITIH1", "OAF", "APOA5", "SERPINA10", "SERPINF2", "BAG3",
         "MCL1", "PCOLCE", "FCGR2A", "ANGPTL1", "RSPO3"]
rows = []
for g in GENES:
    r = res[res.gene == g].sort_values("n_snp").iloc[0]
    rows.append({"gene": g, "beta": r.UACR_beta * 100,
                 "lo": (r.UACR_beta - 1.96 * r.UACR_se) * 100,
                 "hi": (r.UACR_beta + 1.96 * r.UACR_se) * 100,
                 "h4": float(coloc.loc[g, "H4"]),
                 "rep": REP.get(g, "No data")})
d = pd.DataFrame(rows).sort_values("beta")
COL = {"Direction-consistent": "#2b6cb0", "Conflict": "#b7791f", "Opposite": "#c53030",
       "Null": "#718096", "Not evaluable": "#a0aec0", "No data": "#cbd5e0"}

fig, ax = plt.subplots(figsize=(7.2, 5.0))
y = np.arange(len(d))
for i, (_, r) in enumerate(d.iterrows()):
    filled = r.h4 >= 0.8
    ax.plot([r.lo, r.hi], [i, i], color="#4a5568", lw=1, zorder=1)
    ax.scatter(r.beta, i, s=48, zorder=3,
               facecolor=COL[r.rep] if filled else "white",
               edgecolor=COL[r.rep], linewidth=1.4)
ax.axvline(0, color="black", lw=0.8)
ax.set_yticks(y); ax.set_yticklabels(d.gene, fontsize=8)
ax.set_xlabel("Change in UACR per SD higher protein (%)", fontsize=9)
ax.tick_params(axis="x", labelsize=8)
for sp in ("top", "right"):
    ax.spines[sp].set_visible(False)

handles = [Line2D([0], [0], marker="o", linestyle="", markersize=6,
                  markerfacecolor=c, markeredgecolor=c, label=k) for k, c in COL.items()]
h1 = ax.legend(handles=handles, title="Independent replication", fontsize=6.5, title_fontsize=7,
               loc="lower right", frameon=False)
ax.add_artist(h1)
fill_handles = [Line2D([0], [0], marker="o", linestyle="", markersize=6, markerfacecolor="#2b6cb0",
                       markeredgecolor="#2b6cb0", label="PP.H4 ≥ 0.8"),
                Line2D([0], [0], marker="o", linestyle="", markersize=6, markerfacecolor="white",
                       markeredgecolor="#2b6cb0", label="PP.H4 < 0.8")]
ax.legend(handles=fill_handles, title="Colocalization", fontsize=6.5, title_fontsize=7,
          loc="upper left", frameon=False)
ax.set_title("UACR-associated proteins by colocalization and replication", fontsize=9)
fig.tight_layout()
for ext in ["png", "pdf", "tif"]:
    fig.savefig(EN / "figures" / f"Fig2_forest_UACR.{ext}", dpi=300, bbox_inches="tight")
plt.close(fig)
print("Fig2 已重绘:", {f.suffix: round(f.stat().st_size/1024) for f in sorted((EN / "figures").glob("Fig2_forest_UACR.*"))})
print("图内分类计数:", d.rep.value_counts().to_dict(), "| H4>=0.8 个数:", int((d.h4 >= 0.8).sum()))
