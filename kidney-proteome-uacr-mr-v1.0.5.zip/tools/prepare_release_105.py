# -*- coding: utf-8 -*-
"""按真实 Zenodo 状态收尾：版本升 1.0.5、补清空草稿文件、更新说明与工具包。"""
import hashlib
import json
import shutil
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(".")
REPO = ROOT / "repo"
PKG = ROOT / "交付包"
KIT = PKG / "04_发布工具包"
TITLE = ("Albuminuria-directed cis-pQTL Mendelian randomization: feasibility and a negative control "
         "for proteome-wide screens")
VERSION = "1.0.5"

# ---------- 1. publish_zenodo.py：清空草稿继承文件 ----------
pz = REPO / "tools/publish_zenodo.py"
s = pz.read_text(encoding="utf-8")
old = """    dep = call(f"{API}/deposit/depositions/{draft_id}")
    bucket = dep["links"]["bucket"]"""
new = """    dep = call(f"{API}/deposit/depositions/{draft_id}")
    for old_file in dep.get("files", []):
        call(f"{API}/deposit/depositions/{draft_id}/files/{old_file['id']}", method="DELETE")
        print("  清除草稿内已有文件:", old_file.get("filename") or old_file.get("key"))
    dep = call(f"{API}/deposit/depositions/{draft_id}")
    bucket = dep["links"]["bucket"]"""
if old in s and "清除草稿内已有文件" not in s:
    s = s.replace(old, new, 1)
    pz.write_text(s, encoding="utf-8")
print("publish_zenodo 清空逻辑:", "清除草稿内已有文件" in pz.read_text(encoding="utf-8"))

# ---------- 2. 元数据：版本与标题 ----------
zj = REPO / ".zenodo.json"
d = json.loads(zj.read_text(encoding="utf-8"))
d["title"] = TITLE + " (analysis code and derived tables)"
d["version"] = VERSION
d["publication_date"] = date.today().isoformat()
d["notes"] = ("Version history: v1.0.4 (10.5281/zenodo.23853798) contained a single archive; "
              "this version adds the final manuscripts, the dual-criteria Figure 2 and the provenance files.")
zj.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")

cit = REPO / "metadata/CITATION.cff"
cs = cit.read_text(encoding="utf-8")
cs = cs.replace('version: 1.0.4', f'version: {VERSION}')
cs = cs.replace('date-released: 2026-11-01', f'date-released: {date.today().isoformat()}')
cit.write_text(cs, encoding="utf-8")
print("版本:", json.loads(zj.read_text(encoding='utf-8'))["version"])

(REPO / "metadata/DOI.txt").write_text("""DOIS
概念 DOI（引用本文时使用，始终指向最新版本）：10.5281/zenodo.23851408
已发布版本 DOI（历史记录，经 Zenodo API 核对）：
  v1.0.0  10.5281/zenodo.23851409
  v1.0.1  10.5281/zenodo.23851583
  v1.0.2  10.5281/zenodo.23851813
  v1.0.3  10.5281/zenodo.23852899
  v1.0.4  10.5281/zenodo.23853798   （仅含 1 个文件：hpeixi/kidney-proteome-uacr-mr-v1.0.3.zip）
  v1.0.5  待发布，发布后由脚本写入 DOI_LAST_PUBLISHED.txt，请补记于此行
说明：Zenodo 已发布版本不可覆盖，内容更新须发布新版本。
""", encoding="utf-8")
print("DOI.txt 已按实测更新")

# ---------- 3. UPLOAD.md ----------
(REPO / "UPLOAD.md").write_text(f"""# 上传说明（GitHub / Zenodo）

## 0. 先看当前真实状态（经 Zenodo API 核对）

| 项目 | 值 |
|---|---|
| 概念 DOI | 10.5281/zenodo.23851408 |
| 最新版本 | v1.0.4，版本 DOI 10.5281/zenodo.23853798 |
| 该版本文件 | 仅 1 个：`hpeixi/kidney-proteome-uacr-mr-v1.0.3.zip` |
| 标题 | 仍为旧标题 |

因此本次发布的是 **{VERSION}**：补入最终中英文稿件、双判据 Figure 2、溯源文件与全部脚本。Zenodo 的已发布版本不可覆盖，只能新建版本。

## 1. 准备 token

| 用途 | 权限 | 地址 |
|---|---|---|
| Zenodo | `deposit:write`、`deposit:actions` | https://zenodo.org/account/settings/applications/tokens/new/ |
| GitHub | classic: `repo`；fine-grained: Contents 读写 | https://github.com/settings/tokens |

```powershell
$env:ZENODO_TOKEN = "你的 Zenodo token"
$env:GITHUB_TOKEN = "ghp_你的 GitHub token"
```

## 2. 一条命令发布两处

在仓库根目录（`repo` 的上一级）执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File repo\\tools\\release_all.ps1 -DryRun
powershell -NoProfile -ExecutionPolicy Bypass -File repo\\tools\\release_all.ps1
```

参数：

- `-DryRun`：只清点文件、校验凭据，不写任何内容；
- `-Mode Kit`：上传 `交付包\\04_发布工具包` 内的三个 zip，而不是整仓（默认 `Repo`）。

## 3. 分步执行（等价）

```powershell
python repo\\tools\\publish_zenodo.py --dry-run
python repo\\tools\\publish_zenodo.py
python repo\\tools\\publish_github.py -m "manuscript {VERSION}"
```

Zenodo 脚本内部依次执行：读概念记录 → `actions/newversion` 建草稿 → 清空草稿继承文件 → 写元数据 → 上传 → `actions/publish`，并把新版本 DOI 写入 `repo\\metadata\\DOI_LAST_PUBLISHED.txt`。

## 4. 上传后核对

```powershell
python repo\\tools\\verify_doi.py
python repo\\check_zenodo_record.py 23851408
```

判据：

1. `verify_doi.py` 显示的版本号应为 {VERSION}，文件数应为整仓文件数（而非 1）；
2. `check_zenodo_record.py` 的 LICENSE 与 `.zenodo.json` 两项应为 PASS；
3. 概念 DOI 仍为 10.5281/zenodo.23851408，指向最新版本；
4. GitHub `main` 最新提交包含 `manuscripts/`、`figures/Fig2_dual_criteria.png`、`PROVENANCE.md`。

## 5. 常见错误

| 现象 | 原因 | 处理 |
|---|---|---|
| `HTTP 401` | token 未设置或已过期 | 重设环境变量，`gh auth`/`curl` 验证 token |
| `HTTP 403` | token 缺 `deposit:*` 权限，或接口被网络策略拦截 | 补权限；改用浏览器手工上传 |
| `HTTP 422` | 元数据字段不合法（如 license/creators） | 检查 `.zenodo.json` 与 Zenodo 元数据规范 |
| 上传后文件数为 1 | 只传了单个归档，未清空草稿 | 本脚本已内置清空逻辑；如仍异常，在网页端删除旧文件后重传 |
| PowerShell 中文乱码 | 5.1 默认按 ANSI 读脚本 | 本脚本已保存为 UTF-8 BOM |
""", encoding="utf-8")
print("UPLOAD.md 已重写")

# ---------- 4. 重建工具包 ----------
if KIT.exists():
    shutil.rmtree(KIT)
(KIT / "tools").mkdir(parents=True)
for name in ("01_英文资料包.zip", "02_中文资料包.zip", "03_可溯源资料包.zip"):
    shutil.copy2(PKG / name, KIT / name)
for name in ("publish_zenodo.py", "publish_github.py", "release_all.ps1", "verify_doi.py"):
    shutil.copy2(REPO / "tools" / name, KIT / "tools" / name)
shutil.copy2(REPO / "check_zenodo_record.py", KIT / "tools/check_zenodo_record.py")
shutil.copy2(REPO / ".zenodo.json", KIT / ".zenodo.json")
shutil.copy2(REPO / "LICENSE", KIT / "LICENSE")
shutil.copy2(REPO / "UPLOAD.md", KIT / "UPLOAD.md")

(KIT / "README.md").write_text(f"""# 发布工具包（{VERSION}）

自包含，无需本机 git。

- `01_英文资料包.zip`、`02_中文资料包.zip`、`03_可溯源资料包.zip`
- `tools/release_all.ps1`：一键发布（Zenodo + GitHub）
- `tools/publish_zenodo.py`、`tools/publish_github.py`：分开执行
- `tools/verify_doi.py`、`tools/check_zenodo_record.py`：上传后核对
- `.zenodo.json`、`LICENSE`：元数据与许可（Zenodo 必传）

```powershell
$env:ZENODO_TOKEN = "你的 token"
$env:GITHUB_TOKEN = "ghp_你的 token"
powershell -NoProfile -ExecutionPolicy Bypass -File tools\\release_all.ps1 -Mode Kit -DryRun
powershell -NoProfile -ExecutionPolicy Bypass -File tools\\release_all.ps1 -Mode Kit
```

当前 Zenodo 状态：概念 DOI 10.5281/zenodo.23851408，最新 v1.0.4（10.5281/zenodo.23853798，仅 1 个文件）；本次发布 {VERSION}。
""", encoding="utf-8")

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

lines = [f"{sha(p)}  {p.relative_to(KIT).as_posix()}" for p in sorted(KIT.rglob("*")) if p.is_file()]
(KIT / "SHA256SUMS_KIT.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

out = PKG / "04_发布工具包.zip"
if out.exists():
    out.unlink()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in KIT.rglob("*"):
        if f.is_file():
            zf.write(f, Path("04_发布工具包") / f.relative_to(KIT))
z = zipfile.ZipFile(out)
print("工具包:", len(z.namelist()), "条目 | 完好:", z.testzip() is None,
      "| 大小 %.2f MB" % (out.stat().st_size / 1e6))
print("条目:", [n.split("/")[-1] for n in z.namelist()])
