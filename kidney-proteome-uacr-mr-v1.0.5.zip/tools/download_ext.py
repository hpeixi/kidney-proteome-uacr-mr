# -*- coding: utf-8 -*-
"""后台下载 4 个公开 pQTL 面板文件（EBI FTP，无需注册），带断点与大小校验。"""
import os
import ssl
import time
import urllib.request
from pathlib import Path

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
BASE = "https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/"
OUT = Path("data/pqtl_ext"); OUT.mkdir(parents=True, exist_ok=True)

FILES = [
    ("PCOLCE", "GCST90421386", "GCST90421386.tsv.gz", 193.6),
    ("ITIH1", "GCST90427174", "GCST90427174.tsv.gz", 192.2),
    ("OAF", "GCST90426688", "GCST90426688.tsv.gz", 193.7),
    ("ISLR2", "GCST90059992", "GCST90059992_buildGRCh38.tsv.gz", 173.1),
]


def rng(gcst):
    n = int(gcst[4:])
    lo = ((n - 1) // 1000) * 1000 + 1
    return f"GCST{lo:06d}-GCST{lo+999:06d}"


for gene, gcst, fname, mb in FILES:
    url = f"{BASE}{rng(gcst)}/{gcst}/{fname}"
    dst = OUT / fname
    if dst.exists() and abs(dst.stat().st_size / 1024 / 1024 - mb) < 1:
        print(f"[跳过] {gene} 已存在 {dst.stat().st_size/1024/1024:.1f} MB", flush=True)
        continue
    tmp = OUT / (fname + ".part")
    print(f"[开始] {gene} {gcst} 目标 {mb} MB", flush=True)
    t0 = time.time()
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=300, context=ctx) as r, open(tmp, "wb") as f:
        got = 0
        while True:
            chunk = r.read(1 << 20)
            if not chunk:
                break
            f.write(chunk); got += len(chunk)
            if got % (20 << 20) < (1 << 20):
                print(f"  {gene}: {got/1024/1024:.0f} MB", flush=True)
    size_mb = tmp.stat().st_size / 1024 / 1024
    ok = abs(size_mb - mb) < 1
    print(f"[完成] {gene} {size_mb:.1f} MB, 校验 {'通过' if ok else '不符'} , 用时 {time.time()-t0:.0f}s", flush=True)
    if ok:
        os.replace(tmp, dst)
    else:
        tmp.unlink()
print("全部结束", flush=True)
