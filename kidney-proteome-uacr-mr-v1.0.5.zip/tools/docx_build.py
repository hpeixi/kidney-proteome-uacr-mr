# -*- coding: utf-8 -*-
"""通用 docx 构建器：把 md 稿件排版为期刊样式的 Word。"""
import re

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt


def build(md_text, out_path, size=12, table_pt=6.5, margins=2.2, line_numbers=True, cjk_font="SimSun"):
    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
        setattr(sec, m, Cm(margins))
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(size)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), cjk_font)
    st.paragraph_format.line_spacing = 2.0
    st.paragraph_format.space_before = Pt(0)
    st.paragraph_format.space_after = Pt(0)

    def runs(p, s):
        for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
            if not seg:
                continue
            if seg.startswith("**") and seg.endswith("**"):
                r = p.add_run(seg[2:-2])
                r.bold = True
            elif seg.startswith("^") and seg.endswith("^"):
                r = p.add_run(seg[1:-1])
                r.font.superscript = True
            else:
                p.add_run(seg)

    lines = md_text.split("\n")
    i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln or ln == "---":
            i += 1
            continue
        if ln.startswith("### "):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(2)
            r = p.add_run(ln[4:])
            r.bold = True
            r.italic = True
        elif ln.startswith("## "):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(4)
            r = p.add_run(ln[3:])
            r.bold = True
        elif ln.startswith("# "):
            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(6)
            r = p.add_run(ln[2:])
            r.bold = True
            r.font.size = Pt(14)
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            if not rows:
                continue
            t = doc.add_table(rows=len(rows), cols=len(rows[0]))
            t.style = "Table Grid"
            t.alignment = WD_TABLE_ALIGNMENT.CENTER
            for ri, row in enumerate(rows):
                for ci, val in enumerate(row):
                    cp = t.cell(ri, ci).paragraphs[0]
                    cp.paragraph_format.line_spacing = 1.0
                    cp.paragraph_format.space_after = Pt(0)
                    r = cp.add_run(val)
                    r.font.size = Pt(table_pt)
                    if ri == 0:
                        r.bold = True
            continue
        else:
            runs(doc.add_paragraph(), ln)
        i += 1

    if line_numbers:
        el = OxmlElement("w:lnNumType")
        el.set(qn("w:countBy"), "1")
        el.set(qn("w:restart"), "continuous")
        sec._sectPr.append(el)

    fp = sec.footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run()
    c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
    c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
    for x in (c1, it, c2):
        run._r.append(x)
    doc.save(out_path)
    return out_path


def abstract_words(docx_path):
    d = Document(docx_path)
    t = "\n".join(p.text for p in d.paragraphs)
    seg = t[t.index("Purpose."):t.index("Keywords:")]
    return len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*", seg))
