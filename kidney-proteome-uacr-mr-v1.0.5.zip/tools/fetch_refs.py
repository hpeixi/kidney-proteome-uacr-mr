# -*- coding: utf-8 -*-
"""按 PMID 取 PubMed 记录，生成带题名的 Vancouver 文献行。"""
import json, ssl, time, urllib.request, xml.etree.ElementTree as ET

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
PMIDS = ["31511532", "31152163", "29875488", "34857953", "37794186", "37774922",
         "38898508", "39333727", "38211557", "37014015", "24830394", "29686387",
         "27061298", "24114802", "30057032"]

url = ("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&retmode=xml&id="
       + ",".join(PMIDS))
raw = urllib.request.urlopen(urllib.request.Request(
    url, headers={"User-Agent": "Mozilla/5.0"}), timeout=60, context=ctx).read()
root = ET.fromstring(raw)

def text(el):
    return "".join(el.itertext()).strip() if el is not None else ""

lines = []
for art in root.findall(".//PubmedArticle"):
    pmid = text(art.find(".//PMID"))
    title = text(art.find(".//ArticleTitle")).rstrip(".")
    journal = text(art.find(".//ISOAbbreviation")) or text(art.find(".//Title"))
    year = text(art.find(".//PubDate/Year"))
    vol = text(art.find(".//Volume"))
    iss = text(art.find(".//Issue"))
    pg = text(art.find(".//MedlinePgn")) or text(art.find(".//ELocationID"))

    authors = []
    for a in art.findall(".//AuthorList/Author"):
        ln, ini = text(a.find("LastName")), text(a.find("Initials"))
        if ln:
            authors.append(f"{ln} {ini}".strip())
    if len(authors) > 3:
        astr = ", ".join(authors[:3]) + ", et al"
    else:
        astr = ", ".join(authors)

    loc = f"{year}"
    if vol:
        loc += f";{vol}"
        if iss:
            loc += f"({iss})"
        if pg:
            loc += f":{pg}"
    elif pg:
        loc += f":{pg}"
    lines.append({"pmid": pmid, "ref": f"{astr}. {title}. {journal}. {loc}."})

for i, r in enumerate(lines, 1):
    print(f"{i}. {r['ref']}")
print("条数:", len(lines))

json.dump(lines, open("refs_pubmed.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
