# -*- coding: utf-8 -*-
"""生成自包含发布工具包：三个交付包 + 上传脚本 + 说明 + 校验值。"""
import hashlib
import shutil
import zipfile
from pathlib import Path

ROOT = Path(".")
PKG = ROOT / "交付包"
KIT = PKG / "04_发布工具包"
if KIT.exists():
    shutil.rmtree(KIT)
(KIT / "tools").mkdir(parents=True)

for name in ("01_英文资料包.zip", "02_中文资料包.zip", "03_可溯源资料包.zip"):
    shutil.copy2(PKG / name, KIT / name)

shutil.copy2(ROOT / "repo/tools/publish_zenodo.py", KIT / "tools/publish_zenodo.py")
shutil.copy2(ROOT / "repo/tools/publish_github.py", KIT / "tools/publish_github.py")

readme = """# 发布工具包（v1.0.4）

本目录可直接上传，无需本机 git。

## 内容

- `01_英文资料包.zip`、`02_中文资料包.zip`、`03_可溯源资料包.zip`：投稿与溯源三包
- `tools/publish_zenodo.py`：以概念记录 23851408 建新版本并发布（上传本目录文件）
- `tools/publish_github.py`：走 Git Data API 推送仓库（需在 repo 目录运行）
- `SHA256SUMS_KIT.txt`：本目录文件的校验值

## Zenodo（一条命令）

```powershell
cd 04_发布工具包
$env:ZENODO_TOKEN = "你的 token"
python tools/publish_zenodo.py --dry-run
python tools/publish_zenodo.py
```

成功后脚本把版本 DOI 写入 `metadata/DOI_LAST_PUBLISHED.txt`；请补记到
`repo/metadata/DOI.txt` 的 v1.0.4 行。概念 DOI 始终为 10.5281/zenodo.23851408。

## GitHub

```powershell
$env:GITHUB_TOKEN = "ghp_你的 token"
python repo/tools/publish_github.py -m "manuscript v1.0.4"
```

## 上传后核对

1. 概念 DOI 指向最新版本；
2. 版本 DOI 与 DOI.txt 一致；
3. 仓库 main 分支含 `manuscripts/manuscript_en.docx`；
4. 仓库根目录存在 `PROVENANCE.md` 与 `交付包/03_可溯源资料包/SHA256SUMS.txt`。
"""
(KIT / "README.md").write_text(readme, encoding="utf-8")

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

lines = []
for p in sorted(KIT.rglob("*")):
    if p.is_file():
        lines.append(f"{sha(p)}  {p.relative_to(KIT).as_posix()}")
(KIT / "SHA256SUMS_KIT.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")

out = PKG / "04_发布工具包.zip"
if out.exists():
    out.unlink()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in KIT.rglob("*"):
        if f.is_file():
            zf.write(f, Path("04_发布工具包") / f.relative_to(KIT))
z = zipfile.ZipFile(out)
print("工具包:", len(z.namelist()), "条目 | 完好:", z.testzip() is None)
print("内容:", sorted(n.split("/")[-1] for n in z.namelist()))
print("工具包大小: %.2f MB" % (out.stat().st_size / 1e6))
