# -*- coding: utf-8 -*-
"""Figure 2 重绘：共定位（PP.H4）与独立复制双判据并列呈现。数据取自结果表，不手填效应量。"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pathlib import Path
from matplotlib.lines import Line2D

RES = Path("交付包/03_可溯源资料包/results")
FIG = Path("交付包/01_英文资料包/figures")

mr = pd.read_csv(RES / "cis_mr_results.csv")
col = pd.read_csv(RES / "coloc_final.csv")
hits = mr[mr.UACR_fdr < 0.05].copy()
hits = hits.merge(col[["gene", "H4"]], on="gene", how="left")
hits["pct"] = (np.expm1(hits.UACR_beta)) * 100
hits["lo"] = (np.expm1(hits.UACR_beta - 1.96 * hits.UACR_se)) * 100
hits["hi"] = (np.expm1(hits.UACR_beta + 1.96 * hits.UACR_se)) * 100
hits = hits.sort_values("H4", ascending=True).reset_index(drop=True)
print(hits[["gene", "n_snp", "pct", "lo", "hi", "H4"]].round(3).to_string())

# 复制状态：来自 Table 1 与 replication_extended.csv 的核验结果；None = 无独立数据
REP = {
 "APOA5": ("none", "No public pQTL"),
 "PCOLCE": ("consistent", "CSF SomaScan [18]"),
 "ISLR2": ("consistent", "Serum SomaScan [17]"),
 "BAG3": ("opposite", "Plasma Olink [5]"),
 "SERPINA10": ("conflict", "CSF, conflict [18]"),
 "ITIH1": ("consistent", "CSF, low conf. [18]"),
 "OAF": ("null", "CSF, null [18]"),
 "MCL1": ("none", "No independent data"),
 "FCGR2A": ("none", "No independent data"),
 "SERPINF2": ("none", "No independent data"),
 "RSPO3": ("none", "No independent data"),
 "ANGPTL1": ("not_eval", "Not evaluable"),
}
TIER = {"FCGR2A": "strong", "ITIH1": "strong", "ANGPTL1": "strong",
        "OAF": "moderate", "SERPINA10": "moderate", "RSPO3": "moderate"}
COL = {"consistent": "#1b7837", "conflict": "#e08214", "opposite": "#b2182b",
       "null": "#7f7f7f", "none": "#bbbbbb", "not_eval": "#d9d9d9"}
LAB = {"consistent": "Direction-consistent", "conflict": "Conflict",
       "opposite": "Opposite", "null": "Null", "none": "No independent data",
       "not_eval": "Not evaluable"}

fig = plt.figure(figsize=(17.2, 6.4))
gs = fig.add_gridspec(1, 3, width_ratios=[1.05, 1.15, 0.62], wspace=0.30)
y = np.arange(len(hits))

# Panel A：共定位
ax = fig.add_subplot(gs[0, 0])
for i, r in hits.iterrows():
    st = REP.get(r.gene, ("none", ""))[0]
    ax.plot([0, r.H4], [i, i], color=COL[st], lw=1.6, alpha=0.85, zorder=2)
    ax.scatter(r.H4, i, s=60, color=COL[st], edgecolor="black", linewidth=0.5, zorder=3)
    ax.text(r.H4 + 0.02, i, f"{r.H4:.2f}", va="center", fontsize=8)
ax.axvline(0.8, color="black", ls="--", lw=1.0)
ax.text(0.805, -0.9, "PP.H4 = 0.8", fontsize=8, ha="left")
ax.set_yticks(y); ax.set_yticklabels(hits.gene, fontsize=10, fontstyle="italic")
ax.set_xlim(0, 1.12); ax.set_ylim(-1.4, len(hits) - 0.4)
ax.set_xlabel("Colocalization posterior probability (PP.H4)", fontsize=10)
ax.set_title("A  Colocalization", fontsize=11, loc="left")
ax.grid(axis="x", color="0.9", lw=0.6)
ax.set_axisbelow(True)

# Panel B：效应量
ax = fig.add_subplot(gs[0, 1])
for i, r in hits.iterrows():
    st = REP.get(r.gene, ("none", ""))[0]
    ax.plot([r.lo, r.hi], [i, i], color=COL[st], lw=1.8, solid_capstyle="round")
    ax.scatter(r.pct, i, s=52, color=COL[st], edgecolor="black", linewidth=0.5, zorder=3)
    tier = TIER.get(r.gene, "inconclusive")
    mark = {"strong": "s", "moderate": "^", "inconclusive": "o"}[tier]
    ax.scatter(r.pct, i, s=26, marker=mark, facecolor="white", edgecolor="black",
               linewidth=0.6, zorder=4)
ax.axvline(0, color="black", lw=1.0)
ax.set_yticks(y); ax.set_yticklabels([]); ax.set_ylim(-1.4, len(hits) - 0.4)
ax.set_xlabel("Change in UACR per 1-SD higher protein (%)", fontsize=10)
ax.set_title("B  Effect on albuminuria", fontsize=11, loc="left")
ax.grid(axis="x", color="0.9", lw=0.6); ax.set_axisbelow(True)

# Panel C：双判据矩阵
ax = fig.add_subplot(gs[0, 2])
for i, r in hits.iterrows():
    st = REP.get(r.gene, ("none", ""))[0]
    ax.scatter(0, i, s=110, color="#2166ac" if r.H4 >= 0.8 else "white",
               edgecolor="black", linewidth=0.7, zorder=3)
    ax.scatter(1, i, s=110, color=COL[st], edgecolor="black", linewidth=0.7, zorder=3)
    ax.text(0.42, i, "yes" if r.H4 >= 0.8 else "no", va="center", fontsize=7,
            ha="center", color="0.35")
    ax.text(1.42, i, LAB[st].replace("Direction-consistent", "yes").replace("No independent data", "none"),
            va="center", fontsize=7, ha="left",
            color="#8c8c8c" if st in ("none", "not_eval") else COL[st])
ax.set_xlim(-0.5, 2.9); ax.set_ylim(-1.4, len(hits) - 0.4)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Shared\nvariant", "Independent\nreplication"], fontsize=9)
ax.set_yticks(y); ax.set_yticklabels([])
ax.set_title("C  Criteria met", fontsize=11, loc="left")
for s in ("top", "right", "left"):
    ax.spines[s].set_visible(False)
ax.tick_params(axis="y", length=0)

handles = [Line2D([], [], marker="o", ls="", mfc=COL[k], mec="black", label=LAB[k])
           for k in ["consistent", "conflict", "opposite", "null", "none", "not_eval"]]
handles += [Line2D([], [], marker="s", ls="", mfc="white", mec="black", label="Steiger strong"),
            Line2D([], [], marker="^", ls="", mfc="white", mec="black", label="Steiger moderate"),
            Line2D([], [], marker="o", ls="", mfc="white", mec="black", label="Steiger inconclusive")]
fig.legend(handles=handles, loc="lower center", ncol=5, fontsize=7.5, frameon=False,
           bbox_to_anchor=(0.5, 0.01))
fig.subplots_adjust(left=0.06, right=0.99, top=0.92, bottom=0.26)

for ext in ("png", "pdf", "tif"):
    p = FIG / f"Fig2_dual_criteria.{ext}"
    if ext == "tif":
        fig.savefig(p, dpi=300, pil_kwargs={"compression": "tiff_lzw"})
    else:
        fig.savefig(p, dpi=300)
    print(p, round(p.stat().st_size / 1024), "KB")
old = FIG / "Fig2_forest_UACR.png"
print("旧图仍在:", old.exists())
