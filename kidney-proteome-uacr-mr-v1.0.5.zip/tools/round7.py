# -*- coding: utf-8 -*-
"""第六轮：M1-M6 + MINOR 1/3/4/6/9。以源数据为准统一效应量，补效能边界与文献。"""
import json
import re
import ssl
import urllib.request
from pathlib import Path

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

# 取 [19] 的作者与页码
ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
u = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=36890639"
d = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}),
                                      timeout=40, context=ctx).read())["result"]["36890639"]
authors = [a["name"] for a in d["authors"]]
ref19 = (f"{', '.join(authors[:3])}{', et al' if len(authors) > 3 else ''}. {d['title'].rstrip('.')}. "
         f"{d['source']}. {d['pubdate']};{d['volume']}({d['issue']}):{d['pages']}.")
print("ref19:", ref19)

R = [
 # ---- M1 效应量对齐 ----
 ("(changes −6.4% to +5.3% per SD)", "(changes −6.6% to +5.1% per SD)"),
 ("with effects ranging from −6.4% (95% CI −8.9 to −3.8) for ISLR2 to +5.3% (+2.1 to +8.5) for BAG3 per 1-SD higher protein",
  "with effects ranging from −6.6% (95% CI −9.3 to −3.9) for ISLR2 to +5.1% (+2.1 to +8.2) for BAG3 per 1-SD higher protein"),
 # ---- M2 Steiger 结论 ----
 ("Steiger direction was consistent with protein→UACR for all twelve proteins (Z 0.58–36.11; Supplementary Table S17): the instruments explain more variance in protein than in UACR, as expected when the protein is the proximal trait.",
  "The Steiger point estimate was in the expected direction for all twelve proteins, but only six reached strong or moderate support (Table 1; Z = 36.11 for FCGR2A and 0.58 for MCL1; Supplementary Table S17): the instruments explain more variance in protein than in UACR, as expected when the protein is the proximal trait."),
 # ---- M3 结论降级 + 效能边界 ----
 ("eGFR-anchored screens cannot substitute for this approach; the five proteins surviving missense exclusion are candidates for validation.",
  "in this dataset, eGFR-anchored screening was not a substitute for this approach; the five of the eight that survived missense exclusion are candidates for validation."),
 ("Any proteome-wide MR anchored on eGFR inherits the same constraint: the proteins it prioritizes are not a substitute for those prioritized on the barrier phenotype, and an eGFR-derived list should not be read as a proxy for albuminuria biology.",
  "An eGFR-derived list should not be assumed to stand in for one built on the barrier phenotype. The test is, however, a weak one: with 12 and 30 hits among 582 proteins, at least three overlapping proteins would have been needed for P < 0.05 (P(X ≥ 3) = 0.020), so it can detect substantial overlap but cannot establish its absence, and it does not show that eGFR-directed screening is uninformative in general."),
 ("Mapping was name-based, with four problems in an audit of fifteen.",
  "The overlap test is exploratory: with these hit counts its power is minimal, and it cannot distinguish absent overlap from moderate overlap. Mapping was name-based, with four problems in an audit of fifteen."),
 # ---- M4 面板人群与样本量 ----
 ("a serum SomaScan panel from two isolated populations that assayed 184 neuro-related proteins [17] (2,917 participants in the GWAS Catalog entry) for ISLR2, and a cerebrospinal fluid SomaScan panel from a neurological cohort of clinically normal and neurodegenerative disease cases [18] (3,506 participants) for PCOLCE, ITIH1 and OAF",
  "a serum SomaScan panel from two isolated population-based cohorts that assayed 184 neuro-related proteins [17] (2,893 participants in the original report; 2,917 in the GWAS Catalog entry) for ISLR2, and a cerebrospinal fluid SomaScan panel from a cohort of cognitively normal and neurodegenerative disease participants [18] (3,506 samples; 6,361 proteins) for PCOLCE, ITIH1 and OAF"),
 ("| ISLR2 | 1 | -6.6 | -9.3 to -3.9 | 1.5×10⁻⁶ | 8.8×10⁻⁴ | 0.887 | Direction-consistent (serum; neurological cohort) [17] | inconclusive |",
  "| ISLR2 | 1 | -6.6 | -9.3 to -3.9 | 1.5×10⁻⁶ | 8.8×10⁻⁴ | 0.887 | Direction-consistent (serum; isolated cohorts) [17] | inconclusive |"),
 # ---- M5 OAF 补 [1] 功能证据 ----
 ("The one protein surviving the multi-instrument analysis, OAF, is also the clearest case of distinct causal variants (PP.H3 0.998) with no independent effect, so this dataset supports neither direction nor mechanism for it.",
  "The one protein surviving the multi-instrument analysis, OAF, is also the clearest case of distinct causal variants (PP.H3 0.998) with no independent effect in the panel tested; its case is not closed, because the UACR GWAS that supplied the outcome coupled albuminuria to plasma OAF and knockdown of the OAF orthologue reduced albumin uptake in Drosophila nephrocytes [1], which makes OAF the candidate most ready for experimental follow-up."),
 # ---- M6 观察性蛋白组学先例 ----
 ("Which circulating proteins influence it is largely unresolved [6].",
  "Observational plasma proteomics and genetic studies have associated several proteins with albuminuria and kidney function decline [19, 6], but no cis-pQTL screen has taken albuminuria as its primary outcome."),
 # ---- MINOR 1/3/9 ----
 ("eight colocalized (PP.H4 ≥ 0.8), five surviving missense exclusion",
  "eight colocalized (PP.H4 ≥ 0.8), five of the eight surviving missense exclusion"),
 ("This was a two-sample summary-data MR study; the analysis plan was fixed beforehand and reporting follows STROBE-MR.",
  "This was a two-sample summary-data MR study. The primary screen, colocalization and power analyses were prespecified; replication, the missense sensitivity analysis and the Steiger analysis were added during revision, and reporting follows STROBE-MR."),
 ("kept the direction of the primary estimate", "were direction-consistent with the primary estimate"),
 ("and we would not defend it.", "and we do not regard it as a candidate."),
 # ---- MINOR 6：表注 ----
 ("Steiger tiers: strong (Z ≥ 5), moderate (2 ≤ Z < 5), inconclusive (Z < 2); the lowest is MCL1 (Z = 0.58).",
  "Steiger tiers: strong (Z ≥ 5), moderate (2 ≤ Z < 5), inconclusive (Z < 2); the lowest is MCL1 (Z = 0.58), and strong Steiger support reflects direction only, not overall evidence strength."),
 # ---- ref 19 ----
 ("18. Western D, Timsina J, Wang L, et al. Proteogenomic analysis of human cerebrospinal fluid identifies neurologically relevant regulation and informs biomarkers. Nat Genet. 2024;56(12):2672-2684.",
  "18. Western D, Timsina J, Wang L, et al. Proteogenomic analysis of human cerebrospinal fluid identifies neurologically relevant regulation and informs biomarkers. Nat Genet. 2024;56(12):2672-2684.\n19. " + ref19),
]
fails = []
for a, b in R:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        fails.append(a[:55])
print("未匹配:", fails if fails else "无")
if fails:
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])))
print("含 −6.6%:", "−6.6%" in md, "| 含 6.62 表行:", "−6.62" in md, "| 含 P(X ≥ 3):", "P(X ≥ 3)" in md)
