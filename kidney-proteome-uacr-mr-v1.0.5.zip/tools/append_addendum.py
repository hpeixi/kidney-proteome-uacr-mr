# -*- coding: utf-8 -*-
"""修正应答表末尾乱码并追加本轮修订记录。"""
from pathlib import Path

p = Path("审稿意见应答表.md")
t = p.read_text(encoding="utf-8", errors="replace")

# 修掉上一版写入时的乱码字符
for bad in ["工作量大\ufffd\ufffd 3–5", "工作量大\ufffd 3–5"]:
    if bad in t:
        t = t.replace(bad, "工作量约 3–5")

addendum = """

## 六、追加修订（按第二份审稿意见执行）

| 意见 | 处理 | 状态 |
|---|---|---|
| C1 摘要/讨论/结论核心数字口径矛盾 | 三处统一为“12 个 UACR 相关蛋白中 8 个共定位达标；7 个有独立数据：4 个方向一致、1 个反转、1 个无效应、1 个不可评估；其余 5 个无数据”，与 Table 1 逐行对应 | 已改 |
| C5 正文无引用标注 | 正文插入 12 处 [n] 标注；新增第 16 条 Hemani 2017（PLoS Genet 2017;13(11):e1007081）并在正文引用；讨论中无文献支撑的功能描述改为名称性描述 | 部分（仍有若干生物学句子未加引） |
| M5 SERPINA10 工具数矛盾 | 查明该蛋白在暴露资源中有两个 aptamer 数据集：Table 1 用单工具数据集（prot-a-2688），敏感性分析用四工具数据集（prot-a-2689，β = 0.005，P = 0.28），正文已写明 | 已改 |
| M6 两个 P 值相同、尺度不明 | 改为分别报告 5.73×10⁻⁶（UACR）与 5.68×10⁻⁶（eGFR，四舍五入前），并补一句：两性状均为 CKDGen 自然对数尺度，eGFR 估计为每 SD 蛋白对应的 log eGFR 变化 | 已改 |
| DOI | 稿件、说明信、README、CITATION、DOI.txt 统一改为 Concept DOI 10.5281/zenodo.23851408，旧号 23853798 无残留 | 已改 |

当前稿件状态：12 页（双倍行距、连续行号）、摘要 248 词、文献 16 条、正文引用标注 12 处、表 1 为 13×7、em dash 计数 0。

仍需处理（本轮未动）：C2 换主面板、C3 功效与效应量矛盾、C4 31 个 eGFR 蛋白未列表，M1 错义变异敏感性、M2 官方映射、M3 多信号共定位、M4 全部蛋白反向 MR、M7 引言 “unknown” 措辞、M8 与既往 eGFR MR 比对、M9 边界 FDR 稳健性。
"""

if "## 六、追加修订" not in t:
    t = t.rstrip() + addendum
p.write_text(t, encoding="utf-8")

tail = p.read_text(encoding="utf-8").splitlines()
print("行数:", len(tail))
print("末尾三行:")
for ln in tail[-3:]:
    print("  ", ln[:80])
print("乱码残留:", "�" in p.read_text(encoding="utf-8"))
print("含追加节:", "## 六、追加修订" in p.read_text(encoding="utf-8"))
