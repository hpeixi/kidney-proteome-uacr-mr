# -*- coding: utf-8 -*-
"""摘要压回 250 以内、重建英文 docx、复核关键数字上下文。"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path("repo/tools").resolve()))
from docx_build import build, abstract_words  # noqa: E402

EN = Path("交付包/01_英文资料包")
p = EN / "manuscript_en.md"
md = p.read_text(encoding="utf-8")

old = ("In this dataset, eGFR-anchored screening was no substitute, and the five proteins "
       "that survived missense exclusion are candidates for validation.")
new = ("In this dataset, eGFR-anchored screening was no substitute; five proteins survived "
       "missense exclusion and are candidates for validation.")
assert old in md
md = md.replace(old, new, 1)
p.write_text(md, encoding="utf-8")

build(md, EN / "manuscript_en.docx")
print("摘要词数:", abstract_words(EN / "manuscript_en.docx"))

# 关键数字上下文
for pat in [r"12 UACR hits and 30 eGFR hits[^.]*\.", r"582 evaluable proteins[^.]*\.",
            r"0\.62[^.]*\.", r"P\(X ≥ 3\) = 0\.020", r"P = 0\.47", r"−6\.4% \(95% CI[^)]*\)",
            r"\+5\.3% \([^)]*\)"]:
    m = re.search(pat, md)
    print("✓" if m else "✗", pat[:34], "->", m.group(0)[:110] if m else "缺失")
print("em dash:", md.count("—"), "| 文献行:", len(re.findall(r"^\d{1,2}\. ", md, re.M)))
