# -*- coding: utf-8 -*-
"""比对远端 main 文件树与本地 repo 文件，列出推送时需要删除的路径。"""
import json
import ssl
import urllib.request
from pathlib import Path

OWNER_REPO = "hpeixi/kidney-proteome-uacr-mr"
ROOT = Path("repo")
SKIP = {".git", "__pycache__", ".ipynb_checkpoints"}

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE


def get(url):
    req = urllib.request.Request(url, headers={
        "User-Agent": "kidney-proteome-check/1.0",
        "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=45, context=ctx) as r:
        return json.loads(r.read())


ref = get(f"https://api.github.com/repos/{OWNER_REPO}/git/ref/heads/main")
sha = ref["object"]["sha"]
commit = get(f"https://api.github.com/repos/{OWNER_REPO}/git/commits/{sha}")
tree = get(f"https://api.github.com/repos/{OWNER_REPO}/git/trees/{commit['tree']['sha']}?recursive=1")
remote = {t["path"] for t in tree["tree"] if t["type"] == "blob"}

local = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*")
         if p.is_file() and not any(x in p.parts for x in SKIP)}

only_remote = sorted(remote - local)
only_local = sorted(local - remote)
same = remote & local

print(f"远端文件 {len(remote)} | 本地文件 {len(local)} | 同名 {len(same)}")
print(f"\n仅存在于远端（推送后需删除）{len(only_remote)} 个:")
for p in only_remote[:40]:
    print("  -", p)
print(f"\n本地新增 {len(only_local)} 个:")
for p in only_local[:40]:
    print("  +", p)
