# -*- coding: utf-8 -*-
"""补核验：摘要词数（md/docx 两种口径）、文献 18 条、表内状态、S16 引用，并重打包。"""
import re
import zipfile
from pathlib import Path

import openpyxl
from docx import Document

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"

md = (EN / "manuscript_en.md").read_text(encoding="utf-8")
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("md 摘要:", len(re.findall(pat, md[s:e])), "| 不含小标题:",
      len(re.findall(pat, re.sub(r"\*\*(Purpose|Methods|Results|Conclusion)\.\*\*", "", md[s:e]))))

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
cells = [c.text for t in d.tables for r in t.rows for c in r.cells]
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("docx 摘要:", len(re.findall(pat, ab)))
refs = [p.text for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]
print("文献:", len(refs), "| 末条:", refs[-1][:70])
print("引用标注:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)))
print("表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
print("表内状态:", sorted({c for c in cells if ("consistent" in c or "conflict" in c or c.strip() == "Null (CSF, SomaScan) [18]")}))
for k in ["five of which survived", "Supplementary Table S16", "No candidate was replicated in plasma",
          "PP.H3 0.998", "Cochran's Q", "winner's curse", "difficult to interpret", "30 proteins", "[4]"]:
    print(f"  {k}: {k in txt}")

wb = openpyxl.load_workbook(EN / "supplementary" / "Table_S1_S16.xlsx", read_only=True)
print("工作表数:", len(wb.sheetnames), "| S16 行:", wb["S16_evidence_tiers"].max_row)
wb.close()

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
