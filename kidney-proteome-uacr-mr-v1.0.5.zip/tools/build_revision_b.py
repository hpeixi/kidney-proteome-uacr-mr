# -*- coding: utf-8 -*-
"""按审稿意见（路径 B）重建英文稿 docx 与说明信，并核验数字、文献、摘要、页数。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
DOCX = EN / "manuscript_en.docx"

# ---------- 0) 保存旧版 docx 文本作数字基线 ----------
base_txt = "\n".join(p.text for p in Document(DOCX).paragraphs)
Path("repo/tools/manuscript_v104_text.txt").write_text(base_txt, encoding="utf-8")

# ---------- 1) 构建稿件 docx ----------
md = (EN / "manuscript_en.md").read_text(encoding="utf-8")
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, text):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", text):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(DOCX)
print("稿件 docx 已重建")

# ---------- 2) 说明信同步标题 ----------
title = md.splitlines()[0][2:].strip()
cl = (EN / "cover_letter.md").read_text(encoding="utf-8")
cl = re.sub(r'"Circulating plasma proteins and albuminuria[^"]*"', f'"{title}"', cl, count=1)
cl = cl.replace("as an original research article", "as a hypothesis-generating original research article")
(EN / "cover_letter.md").write_text(cl, encoding="utf-8")

cld = Document()
s2 = cld.sections[0]
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(s2, m, Cm(2.54))
st2 = cld.styles["Normal"]; st2.font.name = "Times New Roman"; st2.font.size = Pt(12)
st2.paragraph_format.line_spacing = 1.5; st2.paragraph_format.space_after = Pt(6)
for ln in cl.split("\n"):
    if ln.startswith("# "):
        p = cld.add_paragraph(); r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
        p.paragraph_format.space_after = Pt(12)
    elif ln.strip():
        cld.add_paragraph().add_run(ln.strip())
cld.save(EN / "cover_letter.docx")
print("说明信已更新标题并重建 docx")

# ---------- 3) 核验 ----------
new_txt = "\n".join(p.text for p in Document(DOCX).paragraphs)
num = r"[−+]?\d[\d,\.]*%?"
b, n = set(re.findall(num, base_txt)), set(re.findall(num, new_txt))
print("\n数字 token 基线/新版:", len(b), "/", len(n))
print("  新版缺失:", sorted(b - n))
print("  新版新增:", sorted(n - b))

refs = [p.text for p in Document(DOCX).paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]
ab = new_txt[new_txt.index("Purpose."):new_txt.index("Keywords:")]
print("文献:", len(refs), "| 摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("标题:", new_txt.splitlines()[0][:90])
print("em dash 数:", new_txt.count("—"), "| 含 candidate:", "candidate" in new_txt.lower())
print("DOI 23853798:", "23853798" in new_txt)

# ---------- 4) 重打 01 包 ----------
z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
with zipfile.ZipFile(z) as zf:
    print("\n01 zip:", len(zf.namelist()), "条目, 完整=", zf.testzip() is None)
