# -*- coding: utf-8 -*-
"""M1 落实：剔除错义工具后重算 12 个蛋白的 MR，与全工具结果对比。"""
import numpy as np
import pandas as pd
from scipy.stats import norm

RES = "交付包/03_可溯源资料包/results"
cis = pd.read_csv(f"{RES}/cis_snps.csv")
mis = pd.read_csv(f"{RES}/S11_missense_check.csv")
res = pd.read_csv(f"{RES}/cis_mr_results.csv").set_index("gene")

GENES = ["ISLR2", "ITIH1", "OAF", "APOA5", "SERPINA10", "SERPINF2", "BAG3",
         "MCL1", "PCOLCE", "FCGR2A", "ANGPTL1", "RSPO3"]
cis = cis[cis.gene.isin(GENES)].copy()
cis = cis.merge(mis[["gene", "rsid", "consequence", "is_missense"]], on=["gene", "rsid"], how="left")
cis["is_missense"] = cis["is_missense"].fillna(False)


def mr(df, out_b, out_se):
    wald = df[out_b] / df["b_exp"]
    se = np.sqrt((df[out_se] / df["b_exp"]) ** 2 +
                 (df[out_b] ** 2 * df["se_exp"] ** 2) / df["b_exp"] ** 4)
    w = 1 / se ** 2
    beta = (wald * w).sum() / w.sum()
    se_b = np.sqrt(1 / w.sum())
    return beta, se_b, len(df)


rows = []
for g, d in cis.groupby("gene"):
    full = mr(d, "UACR_b", "UACR_se")
    keep = d[~d.is_missense]
    excl = mr(keep, "UACR_b", "UACR_se") if len(keep) else None
    rows.append({
        "gene": g, "n_all": len(d), "n_missense": int(d.is_missense.sum()),
        "n_kept": len(keep),
        "beta_all": round(full[0], 5), "p_all": f"{2*norm.sf(abs(full[0]/full[1])):.2e}",
        "beta_noMissense": round(excl[0], 5) if excl else np.nan,
        "p_noMissense": f"{2*norm.sf(abs(excl[0]/excl[1])):.2e}" if excl else "not estimable",
        "sign_same": (np.sign(excl[0]) == np.sign(full[0])) if excl else None,
    })

out = pd.DataFrame(rows).sort_values("gene")
print(out.to_string(index=False))
print("\n可重算蛋白:", int(out.p_noMissense.ne("not estimable").sum()), "/", len(out))
est = out[out.p_noMissense != "not estimable"]
print("方向一致:", int(est.sign_same.sum()), "/", len(est))
print("重算后 P<0.05:", int((est.p_noMissense.astype(float) < 0.05).sum()), "/", len(est))

out.to_csv(f"{RES}/S12_missense_excluded_mr.csv", index=False, encoding="utf-8-sig")
print("已写 S12_missense_excluded_mr.csv")
