# -*- coding: utf-8 -*-
"""交付物实证：文件存在性、大小、SHA256、文档指标、包完整性。"""
import hashlib
import re
import zipfile
from pathlib import Path

from docx import Document

WS = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace")
KB = WS / "kidney_bioinfo_topics"
files = [
    KB / "交付包/01_英文资料包/manuscript_en.docx",
    KB / "交付包/01_英文资料包/manuscript_en.md",
    KB / "交付包/01_英文资料包/figures/Fig2_dual_criteria.png",
    KB / "交付包/01_英文资料包.zip",
    KB / "交付包/02_中文资料包/manuscript_zh.docx",
    KB / "交付包/02_中文资料包/manuscript_bilingual.docx",
    KB / "交付包/02_中文资料包.zip",
    KB / "交付包/03_可溯源资料包/PROVENANCE.md",
    KB / "交付包/03_可溯源资料包/SHA256SUMS.txt",
    KB / "交付包/03_可溯源资料包.zip",
    KB / "repo/tools/publish_zenodo.py",
    KB / "repo/tools/publish_github.py",
    KB / "repo/UPLOAD.md",
    WS / "cis_mr_results.csv",
]

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

print("== 交付物实证 ==")
for p in files:
    if p.exists():
        print(f"OK  {p.relative_to(WS).as_posix():58s} {p.stat().st_size:>9d}B  {sha(p)[:16]}")
    else:
        print(f"MISSING {p}")

d = Document(KB / "交付包/01_英文资料包/manuscript_en.docx")
t = "\n".join(x.text for x in d.paragraphs)
print("\nEN 摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*", t[t.index("Purpose."):t.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
z = Document(KB / "交付包/02_中文资料包/manuscript_zh.docx")
print("ZH 表:", f"{len(z.tables[0].rows)}x{len(z.tables[0].columns)}")

for zp in ("交付包/01_英文资料包.zip", "交付包/02_中文资料包.zip", "交付包/03_可溯源资料包.zip"):
    zf = zipfile.ZipFile(KB / zp)
    print(f"{zp}: {len(zf.namelist())} 条目, 完整性 {zf.testzip() is None}")

sums = (KB / "交付包/03_可溯源资料包/SHA256SUMS.txt").read_text(encoding="utf-8").strip().split("\n")
mism = 0
for line in sums:
    h, rel = line.split("  ", 1)
    p = KB / rel
    if p.exists() and sha(p) != h:
        mism += 1
print("SHA256 条目:", len(sums), "| 全量复核不符:", mism, "| 缺失:", sum(1 for l in sums if not (KB / l.split('  ', 1)[1]).exists()))
