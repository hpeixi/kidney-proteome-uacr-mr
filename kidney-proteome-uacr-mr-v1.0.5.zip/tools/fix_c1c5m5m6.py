# -*- coding: utf-8 -*-
"""按新审稿意见修 C1/C5/M5/M6，并把稿件 DOI 换成 Concept DOI。"""
import re
from pathlib import Path

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")
TR = Path("交付包/03_可溯源资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

R = []  # (old, new, label)

# ---------------- C5 补引用 ----------------
R += [
 ("Albuminuria reflects damage to the glomerular filtration barrier and is among the strongest predictors of kidney failure and cardiovascular death.",
  "Albuminuria reflects damage to the glomerular filtration barrier and is among the strongest predictors of kidney failure and cardiovascular death [1].", "C5-intro1a"),
 ("Which circulating proteins influence it is largely unresolved.",
  "Which circulating proteins influence it is largely unresolved [10].", "C5-intro1b"),
 ("Mendelian randomization (MR) sidesteps that difficulty by using genetic variants that shift a protein's concentration as instruments.",
  "Mendelian randomization (MR) sidesteps that difficulty by using genetic variants that shift a protein's concentration as instruments [14].", "C5-intro2a"),
 ("Proteome-wide MR has nominated proteins for eGFR, CKD diagnosis, diabetic kidney disease and IgA nephropathy, nearly always with eGFR or a diagnostic label as the outcome.",
  "Proteome-wide MR has nominated proteins for eGFR, CKD diagnosis, diabetic kidney disease and IgA nephropathy [6–9], nearly always with eGFR or a diagnostic label as the outcome.", "C5-intro2b"),
 ("Plasma pQTL summary statistics came from the SomaScan study of Sun and colleagues (3,301 European-ancestry participants; 3,282 aptamer datasets, retrieved through OpenGWAS).",
  "Plasma pQTL summary statistics came from the SomaScan study of Sun and colleagues (3,301 European-ancestry participants; 3,282 aptamer datasets, retrieved through OpenGWAS) [3].", "C5-method1"),
 ("UACR and eGFR summary statistics came from CKDGen (European-ancestry subsets of analyses that included 564,257 and 1,046,070 participants, respectively).",
  "UACR and eGFR summary statistics came from CKDGen (European-ancestry subsets of analyses that included 564,257 and 1,046,070 participants, respectively) [1,2].", "C5-method2"),
 ("those with two or more instruments by inverse-variance weighting.",
  "those with two or more instruments by inverse-variance weighting [14].", "C5-method3"),
 ("the principle underlying Steiger filtering (Hemani 2017); formal Steiger tests with P values were not run.",
  "the principle underlying Steiger filtering [16]; formal Steiger tests with P values were not run.", "C5-method4"),
 ("and posterior probabilities for five hypotheses were computed assuming a single causal variant (priors 1×10⁻⁴ per trait, 1×10⁻⁵ for a shared variant).",
  "and posterior probabilities for five hypotheses were computed assuming a single causal variant [11] (priors 1×10⁻⁴ per trait, 1×10⁻⁵ for a shared variant).", "C5-method5"),
 ("MR-Egger, weighted median and MR-PRESSO all require more than one variant, so none could be applied",
  "MR-Egger, weighted median and MR-PRESSO [12,13] all require more than one variant, so none could be applied", "C5-limit"),
 ("BAG3 did not: in UKB-PPP the estimate reversed",
  "BAG3 did not: in UKB-PPP [5] the estimate reversed", "C5-results"),
 ("ISLR2 remains uncharacterized in this context.",
  "ISLR2 remains uncharacterized in this context, although kidney-tissue eQTL data place several of these genes in glomerular and tubular compartments [15].", "C5-disc"),
]

# ---------------- C1 口径统一 ----------------
R += [
 ("**Conclusion.** Eight proteins met prespecified criteria. Seven were testable in independent panels: four replicated, one reversed, one was null and one was not evaluable. These candidates require experimental validation before causal inference.",
  "**Conclusion.** Of the 12 UACR-associated proteins, eight showed strong colocalization. Independent data existed for seven: four replicated in direction, one reversed, one was null and one could not be evaluated; five had none. These candidates require experimental validation before causal inference.", "C1-abstract"),
 ("Eight proteins met the prespecified criteria. Seven could be examined in independent panels: four kept their direction, one reversed, and two did not support the primary estimate.",
  "Of the 12 proteins associated with UACR, eight reached the colocalization criterion. Seven could be examined in independent panels: four kept their direction (SERPINA10, ISLR2, ITIH1, PCOLCE), BAG3 reversed, OAF was null, and ANGPTL1 could not be evaluated. Five had no independent data (APOA5, SERPINF2, MCL1, FCGR2A, RSPO3).", "C1-discussion"),
 ("In this cis-pQTL MR and colocalization analysis, eight proteins met prespecified criteria and are reported as prioritized candidates for albuminuria. Of the seven testable in independent panels, four replicated in direction, one reversed and two were null or not evaluable; five remain untested.",
  "In this cis-pQTL MR and colocalization analysis, eight of the 12 UACR-associated proteins met the prespecified colocalization criterion. Seven were testable in independent panels: four replicated in direction, one reversed, one was null and one could not be evaluated; five remain untested.", "C1-conclusion"),
]

# ---------------- M5 SERPINA10 ----------------
R += [
 ("Among 145 proteins with two or more instruments, only OAF kept FDR < 0.05 (β = −0.016, P = 6.9×10⁻⁵); SERPINA10 fell to P = 0.28.",
  "Among 145 proteins with two or more instruments, only OAF kept FDR < 0.05 (β = −0.016, P = 6.9×10⁻⁵). SERPINA10 is represented by two aptamer datasets; the estimate in Table 1 uses the single-instrument dataset, whereas the four-instrument dataset gave β = 0.005 (P = 0.28), so the multi-instrument estimate does not support the single-instrument result.", "M5"),
]

# ---------------- M6 P 值与尺度 ----------------
R += [
 ("1.46% lower UACR (95% CI −2.07 to −0.83) and 0.0025 lower eGFR (−0.0036 to −0.0014) per SD, both P = 5.7×10⁻⁶, from a single variant (rs1042779)",
  "1.46% lower UACR (95% CI −2.07 to −0.83; P = 5.73×10⁻⁶) and 0.0025 lower log eGFR (−0.0036 to −0.0014; P = 5.68×10⁻⁶) per SD, from a single variant (rs1042779)", "M6-values"),
]

# ---------------- 文献 16 ----------------
R += [
 ("15. Gillies CE, Putler R, Menon R, et al. An eQTL Landscape of Kidney Tissue in Human Nephrotic Syndrome. Am J Hum Genet. 2018;103(2):232-244.",
  "15. Gillies CE, Putler R, Menon R, et al. An eQTL Landscape of Kidney Tissue in Human Nephrotic Syndrome. Am J Hum Genet. 2018;103(2):232-244.\n16. Hemani G, Tilling K, Davey Smith G. Orienting the causal relationship between imprecisely measured traits using GWAS summary data. PLoS Genet. 2017;13(11):e1007081.", "ref16"),
]

fails = []
for old, new, label in R:
    if old in md:
        md = md.replace(old, new, 1)
    else:
        fails.append(label)

if fails:
    print("未匹配的替换:", fails)
    raise SystemExit(1)

# 尺度补一句（放在 M6 那句之后）
anchor = "from a single variant (rs1042779) in the ITIH1–ITIH3–ITIH4 cluster (Figure 3)."
if anchor in md:
    md = md.replace(anchor, anchor + " Both outcomes are analysed on the natural-log scale distributed by CKDGen, so the eGFR estimate is expressed in log eGFR units per SD of protein.", 1)
else:
    print("尺度句锚点未找到")

# DOI → Concept DOI
md = md.replace("10.5281/zenodo.23853798", "10.5281/zenodo.23851408")
md_path.write_text(md, encoding="utf-8")

# 其余文件 DOI
for p in [EN/"cover_letter.md", EN/"README.md", ZH/"manuscript_zh.md",
          ZH/"manuscript_bilingual.md", ZH/"README.md",
          TR/"metadata/CITATION.cff", Path("repo/metadata/CITATION.cff")]:
    t = p.read_text(encoding="utf-8")
    if "23853798" in t:
        p.write_text(t.replace("10.5281/zenodo.23853798", "10.5281/zenodo.23851408"), encoding="utf-8")
        print("DOI 已换:", p)

# DOI.txt 记录稿件所引
p = TR/"metadata"/"DOI.txt"
t = p.read_text(encoding="utf-8")
t = re.sub(r"DOI cited in the manuscript: .*", "DOI cited in the manuscript: 10.5281/zenodo.23851408 (Concept DOI, all versions)", t)
p.write_text(t, encoding="utf-8")

ab = md[md.index("**Purpose.**"):md.index("**Keywords:**")]
print("\n摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", re.sub(r"\*\*(Purpose|Methods|Results|Conclusion)\.\*\*", "", ab))))
print("正文引用标注数:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", md)))
print("文献条数:", len(re.findall(r"^\d{1,2}\. ", md, re.M)))
