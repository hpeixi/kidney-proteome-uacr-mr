# -*- coding: utf-8 -*-
"""中文稿定稿：修正口径错误、去模板化、表 1 补齐 P 与 Steiger 两列。"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path("repo/tools").resolve()))
from docx_build import build  # noqa: E402

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")

en_rows = {}
for ln in (EN / "manuscript_en.md").read_text(encoding="utf-8").split("\n"):
    if ln.startswith("| ") and ln.count("|") == 10:
        c = [x.strip() for x in ln.strip().strip("|").split("|")]
        if c[0] not in ("Gene", "---"):
            en_rows[c[0]] = {"n": c[1], "pct": c[2], "ci": c[3], "p": c[4],
                             "fdr": c[5], "h4": c[6], "rep": c[7], "steiger": c[8]}
print("英文表行数:", len(en_rows))

TIER_CN = {"strong": "强", "moderate": "中", "inconclusive": "无结论"}
REP_CN = {
 "Direction-consistent (serum; isolated cohorts) [17]": "方向一致（血清）[17]",
 "Direction-consistent (CSF; lowest confidence) [18]": "方向一致（CSF，证据最弱）[18]",
 "Direction-consistent (CSF) [18]": "方向一致（CSF）[18]",
 "Null (CSF) [18]": "阴性（CSF）[18]",
 "Conflict (CSF) [18]†": "不一致（CSF）[18]†",
 "Opposite (plasma; Olink) [5]": "方向相反（血浆 Olink）[5]",
 "No data": "无独立数据",
 "Not evaluable": "不可评估",
}

subs = [
 ("8 种蛋白符合预设标准，但仅 2 种可独立检验，且结果相互矛盾。该集合在生物学上高度异质，不指向单一通路。",
  "8 种蛋白符合预设标准。其中 7 种有独立数据：3 种方向一致，1 种不一致，1 种为阴性，1 种方向相反，1 种不可评估。这组蛋白并不指向单一通路。"),
 ("以 eGFR 为锚点的列表不应默认替代以白蛋白尿为结局的列表，但本研究的重叠检验很弱：582 种蛋白中 12 与 30 个命中的组合下，至少需 3 个重叠蛋白才达 P < 0.05（P(X≥3) = 0.020，期望重叠 0.62），因此本研究只能检出实质重叠，不能证明无重叠，也不足以说明以 eGFR 为导向的筛选普遍无效。",
  "以 eGFR 为锚点的列表不应默认替代以白蛋白尿为结局的列表，但本研究的重叠检验很弱：582 种蛋白中 12 与 30 个命中，至少需 3 个重叠才达 P < 0.05（P(X≥3) = 0.020，期望重叠 0.62）。该检验能检出实质重叠，却不能证明无重叠，也不足以说明以 eGFR 为导向的筛选普遍无效。"),
 ("ISLR2 与 MCL1 较难解释，MCL1 的共定位可能反映多效性变异。",
  "ISLR2 与 MCL1 较难解释，MCL1 的共定位信号可能来自多效性变异，本文不将其视为候选。"),
 ("12 种蛋白与 UACR 在 FDR < 0.05 时相关（表 1，图 2），遗传预测蛋白每升高 1 个标准差，效应从 ISLR2 的 −6.4%（95% CI −8.9 至 −3.8）到 BAG3 的 +5.3%（+2.1 至 +8.5）。",
  "12 种蛋白与 UACR 在 FDR < 0.05 时相关（表 1，图 2）；遗传预测蛋白每升高 1 个标准差，效应从 ISLR2 的 −6.4%（95% CI −8.9 至 −3.8）到 BAG3 的 +5.3%（+2.1 至 +8.5）。"),
]


def rebuild_table(s):
    head = ["| 基因 | 工具变量数 | 每标准差变化（%） | 95% CI | P | FDR | PP.H4 | 复现状态 | Steiger |",
            "|---|---|---|---|---|---|---|---|---|"]
    rows = []
    for g, v in en_rows.items():
        rows.append("| " + " | ".join([g, v["n"], v["pct"], v["ci"], v["p"], v["fdr"], v["h4"],
                                       REP_CN.get(v["rep"], v["rep"]),
                                       TIER_CN.get(v["steiger"], v["steiger"])]) + " |")
    lines = s.split("\n")
    out, i, replaced = [], 0, False
    while i < len(lines):
        if lines[i].startswith("| 基因 |"):
            out.extend(head + rows)
            i += 1
            while i < len(lines) and lines[i].startswith("|"):
                i += 1
            replaced = True
            continue
        out.append(lines[i]); i += 1
    return "\n".join(out), replaced


for name in ("manuscript_zh.md", "manuscript_bilingual.md"):
    f = ZH / name
    if not f.exists():
        print("缺失:", f)
        continue
    s = f.read_text(encoding="utf-8")
    for a, b in subs:
        if a in s:
            s = s.replace(a, b, 1)
        else:
            print("  未匹配:", name, a[:30])
    s, rep = rebuild_table(s)
    f.write_text(s, encoding="utf-8")
    print(name, "| 表重写:", rep, "| 剩“仅 2 种”:", s.count("仅 2 种"), "| 九列表头:", s.count("| Steiger |"))
    build(s, ZH / f"{name.replace('.md', '.docx')}")

from docx import Document
d = Document(ZH / "manuscript_zh.docx")
rows = [[c.text.strip() for c in r.cells] for r in d.tables[0].rows]
print("中文表:", len(rows), "x", len(rows[0]))
print("表头:", rows[0])
print("样例:", rows[1])
t = "\n".join(p.text for p in d.paragraphs)
print("含 7 种有独立数据:", "其中 7 种有独立数据" in t)
