# -*- coding: utf-8 -*-
"""压回 12 页：精简讨论、局限、方法、补充材料清单；重建 docx 并登记第四轮意见。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

subs = [
 # 讨论第二段合并
 ("PCOLCE matures procollagen, and a positive association is what a pro-fibrotic protein should show. BAG3, a chaperone with a role in podocyte biology, moved with albuminuria in the primary panel but reversed in UKB-PPP, and the reverse-direction analysis put albuminuria upstream of circulating BAG3. A shared signal says nothing about which trait is upstream, and BAG3 shows how easily that is missed with a single panel. APOA5, which governs triglyceride-rich lipoproteins, was inversely associated, consistent with a lipid–kidney axis; RSPO3 and ANGPTL1 have vascular functions; SERPINA10 restrains protein Z-dependent protease activity. ISLR2 remains uncharacterized in this context, although kidney-tissue eQTL data place several of these genes in glomerular and tubular compartments [15]. MCL1 is the weakest link in the list: it passed the colocalization threshold, yet its signal may reflect pleiotropic variants rather than a variant acting through MCL1 itself, and we would not defend it as a candidate on present evidence. The single protein that survived the multi-instrument analysis, OAF, is also the clearest case of distinct causal variants (PP.H3 0.998) and showed no independent effect; a dataset of this kind therefore supports neither direction nor mechanism for it. FCGR2A fell just below the threshold (0.678) and, given its immune-complex role, may be worth revisiting rather than dismissed.",
  "PCOLCE matures procollagen, so a positive association fits a pro-fibrotic direction. BAG3, a podocyte chaperone, moved with albuminuria in the primary panel but reversed in UKB-PPP, where reverse MR put albuminuria upstream; a shared signal says nothing about direction, and BAG3 shows how easily that is missed with one panel. APOA5 governs triglyceride-rich lipoproteins and was inversely associated, consistent with a lipid–kidney axis; RSPO3 and ANGPTL1 are vascular; SERPINA10 restrains protein Z-dependent protease activity. ISLR2 remains uncharacterized here, although kidney eQTL data place several of these genes in glomerular and tubular compartments [15]. MCL1 passed the colocalization threshold but its signal may reflect pleiotropic variants, and we would not defend it. The one protein surviving the multi-instrument analysis, OAF, is also the clearest case of distinct causal variants (PP.H3 0.998) with no independent effect, so this dataset supports neither direction nor mechanism for it. FCGR2A fell just below threshold (0.678) and, given its immune-complex role, is worth revisiting."),
 # 局限第一段
 ("The most consequential limitation is the instrument set. The primary panel (3,301 participants, SomaScan v3) is modest, aptamer cross-reactivity is a known problem for this generation of assays, and 74% of evaluable proteins had a single instrument. Single-instrument estimates cannot be protected against horizontal pleiotropy: MR-Egger, weighted median and MR-PRESSO [12,13] all require more than one variant, so none could be applied; the larger deCODE panel [4] would have allowed them but was not used for the primary analysis, and the estimates should be read as associations prioritized by genetic instruments rather than as causal effects.",
  "The instrument set is the most consequential limitation: the primary panel (3,301 participants, SomaScan v3) is modest, cross-reactivity is a known problem for this generation of assays, and 74% of evaluable proteins had one instrument. Single-instrument estimates cannot be protected against pleiotropy: MR-Egger, weighted median and MR-PRESSO [12,13] need more than one variant, so none was applied, and the larger deCODE panel [4] was not used. The estimates are therefore associations prioritized by genetic instruments, not causal effects."),
 # 方法：工具段
 ("Variants had to lie within 500 kb of the transcription start site of the encoding gene, reach P < 5×10⁻⁸ and carry F > 10.",
  "Variants lay within 500 kb of the transcription start site, reached P < 5×10⁻⁸ and carried F > 10."),
 ("Because SomaScan aptamers can bind differently when a coding variant alters the epitope, every instrument was annotated with Ensembl VEP (GRCh38); 7 of the 19 instruments used here were missense variants.",
  "Every instrument was annotated with Ensembl VEP (GRCh38), because aptamer binding can change when a coding variant alters the epitope; 7 of 19 were missense."),
 # 补充材料清单
 ("S1 instruments used for each protein; S2 all cis-MR estimates; S3 colocalization posteriors for the twelve proteins; S4 candidate table with replication status; S5 conditional power; S6 protein-to-gene mapping audit; S7 independent replication results; S8 panel coverage for the twelve proteins; S9 data sources and sample sizes; S10 all 31 proteins associated with eGFR; S11 variant consequences of the 19 instruments; S12 estimates after excluding missense instruments; S13 platform, ancestry and sample size of each replication panel; S14 hypergeometric test of overlap between the UACR and eGFR hit lists; S15 conditional power for the 31 eGFR estimates; S16 evidence tiers for the 12 UACR-associated proteins. All tables are provided in a single workbook; the completed STROBE-MR checklist is supplied as a separate file.",
  "S1 instruments; S2 all cis-MR estimates; S3 colocalization; S4 candidate table; S5 conditional power; S6 mapping audit; S7 independent replication; S8 panel coverage; S9 data sources; S10 the 31 eGFR estimates; S11 variant consequences; S12 estimates after missense exclusion; S13 replication panels; S14 overlap test; S15 eGFR power; S16 evidence tiers. Tables are in one workbook; the STROBE-MR checklist is supplied separately."),
]
for a, b in subs:
    assert a in md, a[:50]
    md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(3)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(1)
                r = cp.add_run(val); r.font.size = Pt(8)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)))
for k in ["five of which survived", "No candidate was replicated in plasma", "PP.H3 0.998", "Cochran", "P = 0.47", "30 proteins", "STROBE-MR checklist is supplied"]:
    print(f"  {k}: {k in txt}")

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")

# 应答表登记第四轮
p = Path("审稿意见应答表.md")
t = p.read_text(encoding="utf-8")
add = """
## 九、第四轮意见处理

| 条目 | 处理 | 状态 |
|---|---|---|
| M1 八个共定位蛋白未做交叉分层 | 新增 S16 证据分层表（12 蛋白 × 工具稳健性 × 共定位 × 方向），摘要改为“8 个共定位，其中 5 个经错义剔除后仍显著”，讨论写明 5+1+2 的分层 | 已改 |
| M2 复制成色被高估 | Table 1 全部改为 direction-consistent（标注血清/脑脊液与平台）、direction conflict、null；补面板原始文献 [17] Png 2021 Nat Commun、[18] Western 2024 Nat Genet；正文明写“no candidate was replicated in plasma on an independent platform” | 已改 |
| M3 OAF 张力未点破 | 讨论增写：唯一通过多工具检验的 OAF 恰为 PP.H3 0.998、且无独立效应，说明该数据无法区分因果与多效性 | 已改 |
| M4 ITIH1 表内与正文冲突 | Table 1 改为“Direction-consistent, lowest confidence (CSF)” | 已改 |
| M5 SERPINA10 属方向冲突 | 报告 5 个工具的单点 Wald（−0.015 至 +0.013）、IVW β = −0.007、Cochran's Q = 14.2、P = 0.007，并写明两个数据集方向不一致 | 已改 |
| M7 摘要缺阴性结果 | 摘要 Results 补入重叠检验（P = 0.47） | 已改 |
| M8 引文 [4] 未出现 | Limitations 引用 [4]（deCODE 面板未用于主分析） | 已改 |
| MINOR 1/2/3/4/5/6/7/9/10 | 30 蛋白口径、补 ANGPTL1、合并重复 “We therefore”、说明 100 kb 窗口与 500 kb 工具窗不同、注明血清面板来源、删去跨尺度“效应更大”比较、STROBE-MR 清单移入 supplementary、补样本重叠与 winner's curse、“hard to read” 改 “difficult to interpret” | 已改 |

未完成：M6（全部 12 个蛋白的正式 Steiger 检验）、MINOR 8（Figure 2 内标注最低证据蛋白）、M1 的面板升级、M4 的 coloc-SuSiE 重算——前三项分别缺标准化结局尺度、需改图、缺大面板数据；coloc-SuSiE 需 LD 面板与 R 环境。
"""
if "## 九、第四轮意见处理" not in t:
    t = t.rstrip() + "\n" + add
p.write_text(t, encoding="utf-8")
print("应答表行数:", len(t.splitlines()))
