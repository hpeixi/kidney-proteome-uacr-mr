# -*- coding: utf-8 -*-
"""修正工具包清单的自引用问题：清单文件不登记自身，并重新打包核验。"""
import hashlib
import zipfile
from pathlib import Path

PKG = Path("交付包")
KIT = PKG / "04_发布工具包"
SUMS = KIT / "SHA256SUMS_KIT.txt"


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


files = [p for p in sorted(KIT.rglob("*")) if p.is_file() and p != SUMS]
lines = [f"{sha(p)}  {p.relative_to(KIT).as_posix()}" for p in files]
SUMS.write_bytes(("\n".join(lines) + "\n").encode("utf-8"))

bad = 0
for line in SUMS.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    h, rel = line.split("  ", 1)
    p = KIT / rel
    bad += int((not p.exists()) or sha(p) != h)
print(f"清单 {len(lines)} 条 | 不符 {bad}")

out = PKG / "04_发布工具包.zip"
if out.exists():
    out.unlink()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in KIT.rglob("*"):
        if f.is_file():
            zf.write(f, Path("04_发布工具包") / f.relative_to(KIT))
z = zipfile.ZipFile(out)
print("zip:", len(z.namelist()), "条目 | 完好:", z.testzip() is None,
      "| %.2f MB" % (out.stat().st_size / 1e6))
print("含 release_all.ps1:", any(n.endswith("release_all.ps1") for n in z.namelist()))
print("含 .zenodo.json:", any(n.endswith(".zenodo.json") for n in z.namelist()))
