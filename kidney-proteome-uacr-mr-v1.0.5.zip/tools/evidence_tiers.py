# -*- coding: utf-8 -*-
"""取证据：复制面板原始文献、SERPINA10 四工具效应与 Cochran's Q、12 蛋白证据分层表。"""
import json
import ssl
import urllib.request

import numpy as np
import pandas as pd
from scipy.stats import chi2

RES = "交付包/03_可溯源资料包/results"
ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE

# 1) 面板文献
for pid in ["34857772", "39528825"]:
    u = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id={pid}"
    d = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}),
                                           timeout=40, context=ctx).read())["result"][pid]
    print(pid, "|", d["source"], d["pubdate"], d["volume"], d["issue"], d["pages"], "|",
          [a["name"] for a in d["authors"]][:2], "|", d["title"][:90])

# 2) SERPINA10 四个工具
cis = pd.read_csv(f"{RES}/cis_snps.csv")
s = cis[cis.gene == "SERPINA10"].copy()
s["wald"] = s.UACR_b / s.b_exp
s["wald_se"] = np.sqrt((s.UACR_se / s.b_exp) ** 2 + (s.UACR_b ** 2 * s.se_exp ** 2) / s.b_exp ** 4)
print("\nSERPINA10 工具:")
print(s[["rsid", "b_exp", "se_exp", "UACR_b", "UACR_se", "wald", "wald_se"]].to_string(index=False))
w = 1 / s.wald_se ** 2
beta = (s.wald * w).sum() / w.sum()
Q = float((w * (s.wald - beta) ** 2).sum())
dfree = len(s) - 1
print(f"IVW beta = {beta:.5f}, Q = {Q:.2f}, df = {dfree}, P_Q = {chi2.sf(Q, dfree):.3f}")

# 3) 证据分层表
mis = pd.read_csv(f"{RES}/S11_missense_check.csv")
coloc = pd.read_csv(f"{RES}/coloc_final.csv")
rep = pd.read_csv(f"{RES}/S7_independent_replication.csv")
s12 = pd.read_csv(f"{RES}/S12_missense_excluded_mr.csv")
GENES = ["ISLR2", "ITIH1", "OAF", "APOA5", "SERPINA10", "SERPINF2", "BAG3",
         "MCL1", "PCOLCE", "FCGR2A", "ANGPTL1", "RSPO3"]
rows = []
for g in GENES:
    n_all = int(cis[cis.gene == g].shape[0])
    n_mis = int(mis[(mis.gene == g) & (mis.is_missense)].shape[0])
    h4 = float(coloc.loc[coloc.gene == g, "H4"].iloc[0]) if (coloc.gene == g).any() else np.nan
    r = rep[rep.gene == g]
    direction = r.direction.iloc[0] if len(r) else "no data"
    robust = "single missense" if (n_all == 1 and n_mis == 1) else ("single" if n_all == 1 else "multi")
    after = s12.loc[s12.gene == g, "p_noMissense"].iloc[0] if (s12.gene == g).any() else "na"
    rows.append({"Gene": g, "Instruments": n_all, "Missense": n_mis, "Instrument robustness": robust,
                 "PP.H4": round(h4, 3) if pd.notna(h4) else "", "H4>=0.8": "yes" if pd.notna(h4) and h4 >= 0.8 else "no",
                 "Independent direction": direction, "P after missense exclusion": after})
e = pd.DataFrame(rows)

def tier(r):
    if r["Instrument robustness"] == "single missense":
        return "not testable (single missense instrument)"
    if str(r["P after missense exclusion"]) not in ("na",) and float(r["P after missense exclusion"]) >= 0.05:
        return "attenuated after missense exclusion"
    if r["H4>=0.8"] == "yes" and r["Independent direction"] in ("一致", "replicated"):
        return "robust in primary panel; direction-consistent elsewhere"
    if r["H4>=0.8"] == "yes":
        return "robust in primary panel; no independent support"
    return "below colocalization threshold"

e["Evidence tier"] = e.apply(tier, axis=1)
print("\n证据分层:")
print(e[["Gene", "Instruments", "Missense", "PP.H4", "H4>=0.8", "Independent direction", "Evidence tier"]].to_string(index=False))
e.to_csv(f"{RES}/S16_evidence_tiers.csv", index=False, encoding="utf-8-sig")
print("\n已写 S16_evidence_tiers.csv")
