# -*- coding: utf-8 -*-
"""DOI.txt 同时登记 Concept DOI 与 v1.0.4 版本 DOI；重打 03 包；量页数。"""
import zipfile
from pathlib import Path

import fitz

OUT = Path("交付包")
TR = OUT / "03_可溯源资料包"
CONCEPT, VERSION = "10.5281/zenodo.23851408", "10.5281/zenodo.23853798"

p = TR / "metadata" / "DOI.txt"
t = p.read_text(encoding="utf-8")
old = ("v1.0.4   DOI: 10.5281/zenodo.23851408\n")
new = (f"v1.0.4   Concept DOI: {CONCEPT}  (resolves to the latest version)\n"
       f"         Version DOI: {VERSION}  (this exact snapshot)\n")
assert old in t, "未找到 v1.0.4 行"
t = t.replace(old, new, 1)
t = t.replace("DOI cited in the manuscript: 10.5281/zenodo.23851408",
              f"DOI cited in the manuscript: {CONCEPT} (Concept DOI)")
p.write_text(t, encoding="utf-8")

z = OUT / "03_可溯源资料包.zip"
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in TR.rglob("*"):
        if f.is_file():
            zf.write(f, Path("03_可溯源资料包") / f.relative_to(TR))
with zipfile.ZipFile(z) as zf:
    print("03 zip:", len(zf.namelist()), "条目, 完整=", zf.testzip() is None)

print("\n== DOI.txt 前 8 行")
for ln in p.read_text(encoding="utf-8").splitlines()[:8]:
    print("  ", ln)

pdf = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace\document-preview-238555177\preview.pdf")
if pdf.exists():
    d = fitz.open(pdf)
    txt = "".join(pg.get_text() for pg in d)
    print("\n英文稿页数:", d.page_count, "| 含 Concept DOI:", CONCEPT in txt)
else:
    print("\n预览 PDF 不存在，页数未测")
