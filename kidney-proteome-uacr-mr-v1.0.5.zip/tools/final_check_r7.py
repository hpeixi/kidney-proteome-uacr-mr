# -*- coding: utf-8 -*-
"""交付前终检：页数、字数、表格与源数据一致性、图件、包完整性。"""
import re
import zipfile
from pathlib import Path

import fitz
import numpy as np
import pandas as pd
from docx import Document

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")
RES = Path("交付包/03_可溯源资料包/results")

mr = pd.read_csv(RES / "cis_mr_results.csv")
h = mr[mr.UACR_fdr < 0.05]
truth = {r.gene: (np.expm1(r.UACR_beta) * 100,
                  np.expm1(r.UACR_beta - 1.96 * r.UACR_se) * 100,
                  np.expm1(r.UACR_beta + 1.96 * r.UACR_se) * 100) for r in h.itertuples()}

d = Document(EN / "manuscript_en.docx")
t = "\n".join(p.text for p in d.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
abs_n = len(re.findall(pat, t[t.index("Purpose."):t.index("Keywords:")]))
rows = [[c.text.strip() for c in r.cells] for r in d.tables[0].rows]
ok = 0
for r in rows[1:]:
    if r[0] in truth:
        p, lo, hi = truth[r[0]]
        e2 = f"{p:+.1f}" if p > 0 else f"{p:.1f}"
        e3 = f"{lo:.1f} to {hi:.1f}"
        ok += int(r[2] == e2 and r[3] == e3)
print("摘要:", abs_n, "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(rows)}x{len(rows[0])}", "| 表内与源数据一致:", f"{ok}/12")
print("图注 双判据:", "Colocalization and replication displayed together" in t,
      "| 效能边界:", "P(X ≥ 3) = 0.020" in t,
      "| 降级:", "was no substitute" in t,
      "| [19]:", "[19" in t,
      "| Steiger 限定:", "only six reached strong or moderate support" in t)
figs = sorted(p.name for p in (EN / "figures").glob("Fig2*"))
print("Fig2 文件:", figs)
for z in ("交付包/01_英文资料包.zip", "交付包/02_中文资料包.zip", "交付包/03_可溯源资料包.zip"):
    zf = zipfile.ZipFile(z)
    print(z, len(zf.namelist()), "条目 | 完好:", zf.testzip() is None)

zh = Document(ZH / "manuscript_zh.docx")
zt = "\n".join(p.text for p in zh.paragraphs)
print("中文: P = 0.47 ->", "P = 0.47" in zt, "| 不可互换残留 ->", "不可互换" in zt,
      "| 不应默认替代 ->", "不应默认替代" in zt, "| 文献:", len([p for p in zh.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
