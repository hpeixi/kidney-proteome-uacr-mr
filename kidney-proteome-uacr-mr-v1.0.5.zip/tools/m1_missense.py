# -*- coding: utf-8 -*-
"""M1：查询 12 个候选蛋白全部工具的变异后果（是否错义/终止等），判断是否需要剔除。"""
import json
import ssl
import time
import urllib.request
from pathlib import Path

import pandas as pd

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
GENES = ["ISLR2", "ITIH1", "OAF", "APOA5", "SERPINA10", "SERPINF2", "BAG3",
         "MCL1", "PCOLCE", "FCGR2A", "ANGPTL1", "RSPO3"]
cis = pd.read_csv("交付包/03_可溯源资料包/results/cis_snps.csv")
inst = cis[cis.gene.isin(GENES)][["gene", "rsid", "ea", "nea"]].drop_duplicates()
print("待查工具数:", len(inst))

rows = []
for _, r in inst.iterrows():
    url = f"https://rest.ensembl.org/variation/human/{r.rsid}?content-type=application/json"
    try:
        resp = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}),
                                      timeout=30, context=ctx)
        d = json.loads(resp.read().decode())
        cons = d.get("most_severe_consequence", "?")
        cls = ",".join(d.get("consequence_type", [])[:3]) if isinstance(d.get("consequence_type"), list) else ""
        mapped = d.get("mappings", [{}])[0].get("assembly_name", "")
    except Exception as e:
        cons, cls, mapped = f"ERR:{type(e).__name__}", "", ""
    rows.append({"gene": r.gene, "rsid": r.rsid, "consequence": cons, "detail": cls, "assembly": mapped})
    time.sleep(0.12)

res = pd.DataFrame(rows)
res["is_missense"] = res.consequence.str.contains("missense|stop_gained|stop_lost|frameshift|splice", na=False)
print(res.to_string(index=False))
print("\n错义/功能变异数:", int(res.is_missense.sum()), "/", len(res))
res.to_csv("交付包/03_可溯源资料包/results/S11_missense_check.csv", index=False, encoding="utf-8-sig")
print("已写 S11_missense_check.csv")
