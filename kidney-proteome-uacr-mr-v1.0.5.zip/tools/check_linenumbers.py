# -*- coding: utf-8 -*-
"""检查行号/页码设置，并生成无行号版本。"""
import sys
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn

sys.path.insert(0, str(Path("repo/tools").resolve()))
from docx_build import build  # noqa: E402

EN = Path("交付包/01_英文资料包")
src = EN / "manuscript_en.docx"
d = Document(src)
sect = d.sections[0]
ln = sect._sectPr.find(qn("w:lnNumType"))
print("行号设置:", None if ln is None else {k.split('}')[-1]: v for k, v in ln.attrib.items()})
foot = sect.footer.paragraphs[0]
print("页脚字段:", [n.text for n in foot._p.iter(qn("w:instrText"))])
print("批注数:", len(d.inline_shapes), "| 修订标记:", "有" if b"w:ins" in d.element.xml.encode() else "无")

md = (EN / "manuscript_en.md").read_text(encoding="utf-8")
out = EN / "manuscript_en_nolines.docx"
build(md, out, line_numbers=False)
d2 = Document(out)
ln2 = d2.sections[0]._sectPr.find(qn("w:lnNumType"))
print("无行号版:", out.name, "| 行号元素:", ln2, "| 段落:", len(d2.paragraphs),
      "| 表:", f"{len(d2.tables[0].rows)}x{len(d2.tables[0].columns)}")
