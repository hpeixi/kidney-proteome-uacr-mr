# -*- coding: utf-8 -*-
"""把通讯作者 ORCID 同步到中文稿/对照稿，更新英文包 README，重打两个 zip。"""
import re, zipfile, os, shutil
from pathlib import Path
from docx import Document

OUT = Path("..")
EN, ZH = OUT / "01_英文资料包", OUT / "02_中文资料包"
ORCID = "0009-0006-5762-8650"
MAIL = "623067910@qq.com"

# ---- 1) 中文 md ----
p = ZH / "manuscript_zh.md"
t = p.read_text(encoding="utf-8")
if ORCID not in t:
    assert t.count(MAIL) == 1
    t = t.replace(MAIL, f"{MAIL}；ORCID：{ORCID}")
    p.write_text(t, encoding="utf-8")
print("中文 md ORCID:", ORCID in p.read_text(encoding="utf-8"))

# ---- 2) 中文/对照 docx 原地追加 ----
for f in ["manuscript_zh.docx", "manuscript_bilingual.docx"]:
    p = ZH / f
    d = Document(p)
    hit = 0
    for para in d.paragraphs:
        if MAIL in para.text and ORCID not in para.text:
            para.add_run(f"；ORCID：{ORCID}")
            hit += 1
    d.save(p)
    txt = "\n".join(x.text for x in Document(p).paragraphs)
    print(f"{f}: 追加 {hit} 处, 校验 {ORCID in txt}")

# ---- 3) 英文包 README ----
readme = """# Circulating plasma proteins and albuminuria — submission package (English)

Manuscript: *Circulating plasma proteins and albuminuria: a cis-pQTL Mendelian randomization
and colocalization study*.
Target journal: International Urology and Nephrology (Springer).

Formatting: A4, Times New Roman 12 pt, double-spaced, continuous line numbers, page numbers
in the footer. Abstract 246 words (242 excluding section labels). 15 references in Vancouver
style with article titles, volume, issue and pages.

## Contents

| Path | Content |
|---|---|
| `manuscript_en.docx` | Submission-ready manuscript (double-spaced, line numbers, page numbers) |
| `manuscript_en.md` | Same text in Markdown |
| `cover_letter.docx` / `.md` | Cover letter to the Editor-in-Chief |
| `STROBE-MR_checklist_EN.docx` / `.md` | STROBE-MR checklist, 20 items, mapped to manuscript sections |
| `figures/*.tif` | Fig. 1-4, TIFF 300 dpi (journal-preferred format) |
| `figures/*.png` / `*.pdf` | Same figures as PNG 300 dpi and vector PDF |
| `supplementary/Table_S1_S9.xlsx` | Supplementary tables S1-S9, English sheet names |
| `references/reference_list.md` | The 15 references, complete with titles |

## Authors

Peixi Huang^1,2^ (ORCID 0009-0004-5436-7788); Dingzhuo Hong^2^; Zhiyuan Gao^2^;
Xikui Zhang^1^ (corresponding author, ORCID 0009-0006-5762-8650; 623067910@qq.com).

## Figures

Fig. 1 study design; Fig. 2 forest plot of the 12 UACR-associated proteins (BAG3 in red,
not replicated); Fig. 3 concordance of UACR and eGFR effects; Fig. 4 colocalization
posterior probabilities.

## Data and code

GitHub: https://github.com/hpeixi/kidney-proteome-uacr-mr
Zenodo (v1.0.2): https://doi.org/10.5281/zenodo.23851813

Exposure: OpenGWAS `prot-a` (Sun 2018, 3,282 proteins, n=3,301). Primary outcome: CKDGen
UACR (Teumer 2019, European subset). Control outcome: CKDGen eGFR (Wuttke 2019, European
subset). Public summary statistics only; no individual-level data.

## Points a reviewer will press

- 73.7% of proteins had a single cis instrument; all F statistics exceeded 10 (median minimum 68.0).
- Colocalization was approximated without an LD matrix; H3-dominant signals (OAF, SERPINF2)
  are reported as distinct causal variants, not as strong candidates.
- Independent replication was possible for 2 of 8 candidates: SERPINA10 replicated in the same
  direction, BAG3 did not (opposite direction; reverse MR supports reverse causation).
- No experimental validation; the study is purely computational.

Numbers in the text are traceable through `数字溯源表.csv` in the traceability package.
"""
(EN / "README.md").write_text(readme, encoding="utf-8")

# ---- 4) 重打 zip ----
for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(folder):
            for fn in files:
                fp = Path(root) / fn
                zf.write(fp, Path(name) / fp.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, {z.stat().st_size/1024/1024:.1f} MB, 完整={zf.testzip() is None}")
