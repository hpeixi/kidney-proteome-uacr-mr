# -*- coding: utf-8 -*-
"""把仓库内容作为新版本发布到 Zenodo。

用法：
    setx ZENODO_TOKEN "你的token"      # 只需一次，或临时 $env:ZENODO_TOKEN="..."
    python repo/tools/publish_zenodo.py --dry-run
    python repo/tools/publish_zenodo.py

凭据从环境变量 ZENODO_TOKEN 读取；缺失时直接退出（不会尝试匿名上传）。
"""
import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

API = "https://zenodo.org/api"
CONCEPT = "23851408"  # 概念 DOI 记录，新版本挂在其下
ROOT = Path(__file__).resolve().parents[1]
EXCLUDE_DIRS = {".git", "__pycache__", ".ipynb_checkpoints"}


def token():
    t = os.environ.get("ZENODO_TOKEN", "").strip()
    if not t:
        print("错误：未设置环境变量 ZENODO_TOKEN，无法发布。", file=sys.stderr)
        print('设置方式（PowerShell）：$env:ZENODO_TOKEN="你的token"', file=sys.stderr)
        sys.exit(2)
    return t


def call(url, method="GET", data=None, headers=None, raw=False):
    h = {"Authorization": f"Bearer {token()}"} if url.startswith(API) else {}
    h.update(headers or {})
    body = None
    if data is not None:
        body = data if isinstance(data, bytes) else json.dumps(data).encode()
        h.setdefault("Content-Type", "application/json")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            payload = r.read()
            return payload if raw else json.loads(payload or b"{}")
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code} {url}\n{e.read()[:400].decode(errors='replace')}", file=sys.stderr)
        raise


def collect():
    files = []
    for p in ROOT.rglob("*"):
        if p.is_file() and not any(part in EXCLUDE_DIRS for part in p.parts):
            files.append(p)
    return sorted(files)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--files", nargs="*", help="仅上传这些文件（默认整个仓库）")
    args = ap.parse_args()

    files = [Path(f).expanduser().resolve() for f in args.files] if args.files else collect()
    total = sum(f.stat().st_size for f in files)
    print(f"待上传 {len(files)} 个文件，合计 {total/1e6:.1f} MB")

    if args.dry_run:
        for f in files[:15]:
            try:
                shown = f.relative_to(ROOT).as_posix()
            except ValueError:
                shown = str(f)
            print("  ", shown)
        print("  ...（dry-run，未调用 API）")
        token()  # 仍校验凭据是否存在
        return

    token()
    concept = call(f"{API}/records/{CONCEPT}")
    latest = concept.get("links", {}).get("latest")
    latest_id = latest.rstrip("/").split("/")[-1] if latest else concept["id"]
    print("最新版本记录:", latest_id)

    draft = call(f"{API}/deposit/depositions/{latest_id}/actions/newversion", method="POST")
    draft_id = draft["links"]["latest_draft"].rstrip("/").split("/")[-1]
    print("新草稿:", draft_id)

    meta = json.loads((ROOT / ".zenodo.json").read_text(encoding="utf-8"))
    call(f"{API}/deposit/depositions/{draft_id}", method="PUT", data={"metadata": meta})

    dep = call(f"{API}/deposit/depositions/{draft_id}")
    for old_file in dep.get("files", []):
        call(f"{API}/deposit/depositions/{draft_id}/files/{old_file['id']}", method="DELETE")
        print("  清除草稿内已有文件:", old_file.get("filename") or old_file.get("key"))
    dep = call(f"{API}/deposit/depositions/{draft_id}")
    bucket = dep["links"]["bucket"]
    for f in files:
        try:
            rel = f.relative_to(ROOT).as_posix()
        except ValueError:
            rel = f.name
        call(f"{bucket}/{rel}", method="PUT", data=f.read_bytes(), raw=True,
             headers={"Content-Type": "application/octet-stream"})
        print("  已上传", rel)

    rec = call(f"{API}/deposit/depositions/{draft_id}/actions/publish", method="POST")
    doi = rec.get("doi", "")
    print("已发布。版本 DOI:", doi)
    print("概念 DOI: 10.5281/zenodo.23851408")
    Path(ROOT / "metadata" / "DOI_LAST_PUBLISHED.txt").write_text(doi + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
