# -*- coding: utf-8 -*-
"""校正：以 cis_mr_results.csv（expm1）为准，统一摘要/正文/Table 1 的 ISLR2、BAG3；图注改为 A-C 面板。"""
import re
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
RES = Path("交付包/03_可溯源资料包/results")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

# ---- 源数据：12 个 UACR 命中 ----
mr = pd.read_csv(RES / "cis_mr_results.csv")
col = pd.read_csv(RES / "coloc_final.csv")
h = mr[mr.UACR_fdr < 0.05].merge(col[["gene", "H4"]], on="gene", how="left")
h["pct"] = np.expm1(h.UACR_beta) * 100
h["lo"] = np.expm1(h.UACR_beta - 1.96 * h.UACR_se) * 100
h["hi"] = np.expm1(h.UACR_beta + 1.96 * h.UACR_se) * 100
truth = {r.gene: (round(r.pct, 1), round(r.lo, 1), round(r.hi, 1)) for r in h.itertuples()}
print("源数据(1 位小数):", {k: truth[k] for k in ("ISLR2", "BAG3", "PCOLCE", "OAF")})

# ---- 表格逐行核对 ----
rows = [ln for ln in md.splitlines() if ln.startswith("| ") and ln.count("|") >= 8]
bad = []
for ln in rows:
    c = [x.strip() for x in ln.strip().strip("|").split("|")]
    if c[0] in truth:
        p, lo, hi = truth[c[0]]
        tv = c[2].replace("+", "")
        try:
            ok = abs(float(tv) - p) <= 0.06
        except ValueError:
            ok = False
        if not ok:
            bad.append((c[0], c[2], p, c[3], f"{lo} to {hi}"))
print("表格与源数据不符:", bad if bad else "无")

# ---- 修正文本（回到 expm1 真值）----
fixes = [
 ("(changes −6.6% to +5.1% per SD)", "(changes −6.4% to +5.3% per SD)"),
 ("−6.6% (95% CI −9.3 to −3.9) for ISLR2 to +5.1% (+2.1 to +8.2) for BAG3",
  "−6.4% (95% CI −8.9 to −3.8) for ISLR2 to +5.3% (+2.1 to +8.5) for BAG3"),
 ("| ISLR2 | 1 | -6.6 | -9.3 to -3.9 |", "| ISLR2 | 1 | -6.4 | -8.9 to -3.8 |"),
 ("| BAG3 | 1 | +5.1 | 2.1 to 8.2 |", "| BAG3 | 1 | +5.3 | 2.1 to 8.5 |"),
 # 图注：改为三面板双判据
 ("**Figure 2.** Cis-pQTL MR estimates for the 12 UACR-associated proteins, coded by two criteria: marker fill shows whether the region passed the colocalization threshold (filled, PP.H4 ≥ 0.8; open, below), and colour shows the independent replication status.",
  "**Figure 2.** Colocalization and independent replication displayed side by side for the 12 UACR-associated proteins, ordered by PP.H4. (A) Posterior probability of a shared causal variant; the dashed line marks PP.H4 = 0.8. (B) Change in UACR per 1-SD higher genetically predicted protein (95% CI); the inner symbol marks the Steiger tier (square, strong; triangle, moderate; circle, inconclusive). (C) Whether each region met each criterion: a shared variant (PP.H4 ≥ 0.8) and direction-consistent replication in an independent panel. Marker colour in all panels encodes replication status: green, direction-consistent; orange, conflicting estimates; red, opposite direction; grey, null; pale grey, no independent data or not evaluable."),
]
for a, b in fixes:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        print("未匹配:", a[:50])
md_path.write_text(md, encoding="utf-8")

# ---- 重建 docx ----
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.2))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        trows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                trows.append(cells)
            i += 1
        t = doc.add_table(rows=len(trows), cols=len(trows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(trows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val); r.font.size = Pt(6.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
cells = [c.text.strip() for t in d.tables for r in t.rows for c in r.cells]
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
print("摘要 −6.4→+5.3:", "−6.4% to +5.3%" in txt,
      "| 正文 ISLR2:", "−6.4% (95% CI −8.9 to −3.8)" in txt,
      "| 表 -6.4:", "-6.4" in cells, "| 表 5.3:", "+5.3" in cells)
print("图注三面板:", "whether each region met each criterion" in txt)

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
