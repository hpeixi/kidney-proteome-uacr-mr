# -*- coding: utf-8 -*-
import re
from docx import Document
from docx.shared import Pt

p = "manuscript_en.docx"
d = Document(p)
ps = [x for x in d.paragraphs if x.text.strip()]

# 行距 / 字号 / 页码
ls = {}
for x in ps:
    v = x.paragraph_format.line_spacing
    ls[v] = ls.get(v, 0) + 1
print("行距分布:", ls)
sz = {}
for x in ps:
    for r in x.runs:
        if r.font.size:
            sz[r.font.size.pt] = sz.get(r.font.size.pt, 0) + 1
print("字号分布:", sz)
xml = d.element.xml
print("含页码域:", "PAGE" in xml, "| 含行号:", "lnNumType" in xml)

# 摘要词数
txt = "\n".join(x.text for x in ps)
ab = re.search(r"## Abstract\n(.*?)\n## Introduction", txt, re.S)
if ab:
    body = re.sub(r"\*\*(Purpose|Methods|Results|Conclusion)\.\*\*", "", ab.group(1))
    print("摘要词数:", len(re.findall(r"[A-Za-z0-9%\-\u2013]+", body)))

# 正文字数（不含文献、表、图注）
main = re.split(r"## References", txt)[0]
words = len(re.findall(r"[A-Za-z0-9%\-\u2013]+", re.sub(r"^#.*$", "", main, flags=re.M)))
print("正文词数(含摘要):", words)

# 参考文献是否有题名
refs = [x.text for x in ps if re.match(r"^\d{1,2}\. ", x.text.strip())]
print("文献条数:", len(refs))
print("示例:", refs[0])
has_title = sum(1 for r in refs if len(re.sub(r"^\d+\. ", "", r).split(".")) >= 4 and len(r) > 60)
print("疑似含题名的条目数:", has_title, "/", len(refs))
