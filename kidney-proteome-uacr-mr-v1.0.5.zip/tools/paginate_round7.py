# -*- coding: utf-8 -*-
"""压回 12 页：去冗约 50 词 + 四边距 2.2 cm；重建 docx 与 01 包。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

subs = [
 ("The test is, however, a weak one: with 12 and 30 hits among 582 proteins, at least three overlapping proteins would have been needed for P < 0.05 (P(X ≥ 3) = 0.020), so it can detect substantial overlap but cannot establish its absence, and it does not show that eGFR-directed screening is uninformative in general.",
  "The test is weak, however: with 12 and 30 hits among 582 proteins, at least three overlaps would have been needed for P < 0.05 (P(X ≥ 3) = 0.020), so it can detect substantial overlap but not its absence."),
 ("a serum SomaScan panel from two isolated population-based cohorts that assayed 184 neuro-related proteins [17] (2,893 participants in the original report; 2,917 in the GWAS Catalog entry) for ISLR2, and a cerebrospinal fluid SomaScan panel from a cohort of cognitively normal and neurodegenerative disease participants [18] (3,506 samples; 6,361 proteins) for PCOLCE, ITIH1 and OAF",
  "a serum SomaScan panel from two isolated population-based cohorts assaying 184 neuro-related proteins [17] (2,893 participants; 2,917 in the GWAS Catalog entry) for ISLR2, and a cerebrospinal fluid SomaScan panel from cognitively normal and neurodegenerative disease participants [18] (3,506 samples) for PCOLCE, ITIH1 and OAF"),
 ("its case is not closed, because the UACR GWAS that supplied the outcome coupled albuminuria to plasma OAF and knockdown of the OAF orthologue reduced albumin uptake in Drosophila nephrocytes [1], which makes OAF the candidate most ready for experimental follow-up.",
  "its case is not closed, because the UACR GWAS coupled albuminuria to plasma OAF and knockdown of the OAF orthologue reduced albumin uptake in Drosophila nephrocytes [1], making OAF the candidate most ready for experimental follow-up."),
 ("The Steiger point estimate was in the expected direction for all twelve proteins, but only six reached strong or moderate support (Table 1; Z = 36.11 for FCGR2A and 0.58 for MCL1; Supplementary Table S17): the instruments explain more variance in protein than in UACR, as expected when the protein is the proximal trait.",
  "The Steiger point estimate lay in the expected direction for all twelve, but only six reached strong or moderate support (Table 1; Z = 36.11 for FCGR2A, 0.58 for MCL1; Supplementary Table S17); the instruments explain more variance in protein than in UACR, as expected for a proximal trait."),
 ("The obstacles are concrete: published panels are modest, most proteins carry a single instrument, and colocalization under a single-causal-variant assumption can only approximate the posterior probability of a shared variant.",
  "The obstacles are concrete: panels are modest, most proteins carry a single instrument, and colocalization under a single-causal-variant assumption can only approximate the posterior probability of a shared variant."),
]
for a, b in subs:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        print("未匹配:", a[:45])
md_path.write_text(md, encoding="utf-8")

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.2))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val); r.font.size = Pt(6.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
print("M1 三处一致:", "−6.6% to +5.1%" in txt and "−6.6% (95% CI −9.3 to −3.9)" in txt)
print("M3 效能边界:", "P(X ≥ 3) = 0.020" in txt, "| M4 双口径:", "2,893 participants" in txt)

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
