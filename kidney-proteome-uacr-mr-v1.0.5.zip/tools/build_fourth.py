# -*- coding: utf-8 -*-
"""摘要压回 250 内、S16 并入工作簿、重建 docx 与包，并逐项核验第四轮意见落点。"""
import re
import zipfile
from pathlib import Path

import openpyxl
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
RES = TR / "results"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"


def abstract_count(text):
    s = text.index("**Purpose.**"); e = text.index("**Keywords:**")
    return len(re.findall(pat, text[s:e]))


# 1) 摘要补“五个经得起错义剔除”
a = "and eight colocalized (PP.H4 ≥ 0.8)."
b = "and eight colocalized (PP.H4 ≥ 0.8), five of which survived exclusion of missense instruments."
if a in md:
    md = md.replace(a, b, 1)

# 2) 逐条压缩至 250 内
trims = [
 ("We asked which proteins are prioritized by cis instruments for albuminuria rather than for eGFR.",
  "We asked which proteins are prioritized for albuminuria rather than eGFR."),
 ("Two-sample MR used cis protein quantitative trait loci for 3,282 plasma proteins measured in 3,301 European-ancestry participants, tested against European-ancestry summary statistics for the urinary albumin-to-creatinine ratio (UACR) and eGFR (CKDGen).",
  "Two-sample MR used cis pQTLs for 3,282 plasma proteins (3,301 European-ancestry participants) against summary statistics for the urinary albumin-to-creatinine ratio (UACR) and eGFR (CKDGen)."),
 ("Instruments lay within 500 kb of the encoding gene with F-statistics exceeding 10 (weakest instrument F = 29.8).",
  "Instruments lay within 500 kb of the gene with F > 10 (weakest 29.8)."),
 ("Twelve proteins were associated with UACR at a false discovery rate below 0.05",
  "Twelve proteins were associated with UACR at false discovery rate < 0.05"),
 ("of the 3,282 proteins, 2,162 carried at least one genome-wide significant pQTL; cis restriction left 582 evaluable proteins, 429 with a single instrument.",
  "of the 3,282 proteins, 2,162 carried a genome-wide significant pQTL; cis restriction left 582, 429 with a single instrument."),
]
for x, y in trims:
    if x in md and abstract_count(md) > 250:
        md = md.replace(x, y, 1)
md_path.write_text(md, encoding="utf-8")
print("摘要词数(截断前):", abstract_count(md))

# 3) 补充材料清单加 S16
a2 = "S15 conditional power for the 31 eGFR estimates."
b2 = "S15 conditional power for the 31 eGFR estimates; S16 evidence tiers for the 12 UACR-associated proteins."
if a2 in md:
    md = md.replace(a2, b2, 1)
    md_path.write_text(md, encoding="utf-8")

# 4) 工作簿并入 S16
s16 = pd.read_csv(RES / "S16_evidence_tiers.csv")
def rebuild(src, dst):
    wb = openpyxl.load_workbook(src)
    name = "S16_evidence_tiers"
    if name in wb.sheetnames:
        del wb[name]
    ws = wb.create_sheet(name)
    ws.append(list(s16.columns))
    for _, r in s16.iterrows():
        ws.append([None if pd.isna(v) else v for v in r.values])
    wb.save(dst); wb.close()

en_old = EN / "supplementary" / "Table_S1_S15.xlsx"
en_new = EN / "supplementary" / "Table_S1_S16.xlsx"
zh_old = ZH / "supplementary" / "投稿材料_补充表_S1_S15.xlsx"
zh_new = ZH / "supplementary" / "投稿材料_补充表_S1_S16.xlsx"
rebuild(en_old, en_new); rebuild(zh_old, zh_new)
en_old.unlink(); zh_old.unlink()
for p in [EN / "README.md", ZH / "README.md"]:
    t = p.read_text(encoding="utf-8")
    t = t.replace("Table_S1_S15.xlsx", "Table_S1_S16.xlsx").replace("投稿材料_补充表_S1_S15.xlsx", "投稿材料_补充表_S1_S16.xlsx")
    t = t.replace("S1–S15", "S1–S16").replace("S1-S15", "S1-S16")
    p.write_text(t, encoding="utf-8")

# 5) 重建 docx
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(3)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(8.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

# 6) 核验
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
cells = [c.text for t in d.tables for r in t.rows for c in r.cells]
print("摘要:", abstract_count("\n".join([txt])), "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
checks = ["five of which survived", "Supplementary Table S16", "No candidate was replicated in plasma",
          "PP.H3 0.998", "Cochran's Q", "[4]", "winner's curse", "difficult to interpret", "30 proteins"]
print("落点:", {k: (k in txt or k in "".join(cells)) for k in checks})
print("表内状态:", sorted({c for c in cells if "consistent" in c or "conflict" in c or "Null" in c}))
wb = openpyxl.load_workbook(en_new, read_only=True)
print("工作表:", len(wb.sheetnames), "| S16 行:", wb["S16_evidence_tiers"].max_row)
wb.close()

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
