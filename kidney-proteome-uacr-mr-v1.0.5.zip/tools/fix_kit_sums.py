# -*- coding: utf-8 -*-
"""校验 04 工具包清单（按 splitlines 处理 CRLF），并重写为 LF。"""
import hashlib
import zipfile
from pathlib import Path

PKG = Path("交付包")
KIT = PKG / "04_发布工具包"


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


entries = [f"{sha(p)}  {p.relative_to(KIT).as_posix()}"
           for p in sorted(KIT.rglob("*")) if p.is_file()]
(KIT / "SHA256SUMS_KIT.txt").write_bytes(("\n".join(entries) + "\n").encode("utf-8"))

text = (KIT / "SHA256SUMS_KIT.txt").read_text(encoding="utf-8")
bad, missing = 0, 0
for line in text.splitlines():
    if not line.strip():
        continue
    h, rel = line.split("  ", 1)
    p = KIT / rel
    if not p.exists():
        missing += 1
        continue
    bad += int(sha(p) != h)
print(f"清单 {len(text.splitlines())} 条 | 不符 {bad} | 缺失 {missing}")

out = PKG / "04_发布工具包.zip"
if out.exists():
    out.unlink()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in KIT.rglob("*"):
        if f.is_file():
            zf.write(f, Path("04_发布工具包") / f.relative_to(KIT))
z = zipfile.ZipFile(out)
print("zip:", len(z.namelist()), "条目 | 完好:", z.testzip() is None,
      "| %.2f MB" % (out.stat().st_size / 1e6))
