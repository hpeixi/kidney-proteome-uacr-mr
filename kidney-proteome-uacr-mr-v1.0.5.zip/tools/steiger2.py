# -*- coding: utf-8 -*-
"""重算 Steiger：用 r^2 = 2f(1-f)beta^2（标准化性状）。

假定：1) log-UACR 标准差 = 1；2) 等位基因频率以 CKDGen 的 Freq1 代替暴露面板频率。
缺失 n_total_sum 的工具从该蛋白的 Steiger 计算中剔除，并在表中标注。
"""
import gzip
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm

RES = Path("交付包/03_可溯源资料包/results")
GENES = ["ISLR2", "ITIH1", "OAF", "APOA5", "SERPINA10", "SERPINF2", "BAG3",
         "MCL1", "PCOLCE", "FCGR2A", "ANGPTL1", "RSPO3"]
N_EXP = 3301

cis = pd.read_csv(RES / "cis_snps.csv")
cis = cis[cis.gene.isin(GENES)].copy()
wanted = set(cis.rsid)

# 取 Freq1 与 n_total_sum
info = {}
with gzip.open("data/UACR_EA_Teumer2019.tbl.rsid.gz", "rt", errors="ignore") as fh:
    header = fh.readline().split()
    i_rs, i_f, i_n = header.index("RSID"), header.index("Freq1"), header.index("n_total_sum")
    for line in fh:
        p = line.rstrip("\n").split()
        if p[i_rs] in wanted:
            try:
                info[p[i_rs]] = (float(p[i_f]), int(float(p[i_n])))
            except ValueError:
                info[p[i_rs]] = (float(p[i_f]), None)
            if len(info) == len(wanted):
                break
print("取到频率:", len(info), "/", len(wanted), "| 有样本量:", sum(1 for v in info.values() if v[1]))

rows = []
for _, r in cis.iterrows():
    f, n_o = info.get(r.rsid, (np.nan, None))
    if not np.isfinite(f) or n_o is None:
        continue
    r2e = 2 * f * (1 - f) * r.b_exp ** 2
    r2o = 2 * f * (1 - f) * r.UACR_b ** 2          # SD(log UACR) = 1
    rows.append({"gene": r.gene, "rsid": r.rsid, "eaf": f, "n_outcome": n_o,
                 "r2_exp": r2e, "r2_out": r2o})
d = pd.DataFrame(rows)

out = []
for g, s in d.groupby("gene"):
    r2e, r2o = s.r2_exp.mean(), s.r2_out.mean()
    ne, no = N_EXP, s.n_outcome.mean()
    se = np.sqrt((1 - r2e) ** 2 / ne + (1 - r2o) ** 2 / no)
    z = (r2e - r2o) / se if se > 0 else np.nan
    p = 2 * norm.sf(abs(z)) if np.isfinite(z) else np.nan
    out.append({"Gene": g, "Instruments used": len(s), "r2_exposure": round(r2e, 5),
                "r2_outcome": round(r2o, 7), "Steiger Z": round(z, 2),
                "P": f"{p:.2e}" if np.isfinite(p) else "na",
                "Direction": ("protein→UACR" if z > 0 else "UACR→protein") if np.isfinite(z) else "na",
                "Note": "" if len(s) == len(cis[cis.gene == g]) else "one instrument lacked N"})
res = pd.DataFrame(out).sort_values("Gene")
print(res.to_string(index=False))
res.to_csv(RES / "S17_steiger.csv", index=False, encoding="utf-8-sig")
print("\n判为 protein→UACR:", int((res.Direction == "protein→UACR").sum()), "/", len(res))
print("r2 最大:", res.r2_exposure.max(), "| 全部 <1:", bool((res.r2_exposure < 1).all()))
