# -*- coding: utf-8 -*-
"""把 release_all.ps1 存为 UTF-8 BOM（Windows PowerShell 5.1 才能正确读中文）。"""
from pathlib import Path

p = Path("repo/tools/release_all.ps1")
s = p.read_text(encoding="utf-8")
p.write_text(s, encoding="utf-8-sig")
raw = p.read_bytes()
print("BOM:", raw[:3] == b"\xef\xbb\xbf", "| 字节:", len(raw), "| 含尖括号:", "<记录" in s)
