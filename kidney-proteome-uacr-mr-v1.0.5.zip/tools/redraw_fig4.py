# -*- coding: utf-8 -*-
"""重绘 Fig4：图例移到坐标区外，避免遮挡条形。"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

EN = Path("交付包/01_英文资料包")
RES = Path("交付包/03_可溯源资料包/results")

c = pd.read_csv(RES / "coloc_final.csv").sort_values("H4", ascending=True)
fig, ax = plt.subplots(figsize=(7.2, 5.6))
y = np.arange(len(c))
ax.barh(y - 0.2, c.H3, height=0.38, color="#9aa5b1", label="PP.H3 (distinct causal variants)")
ax.barh(y + 0.2, c.H4, height=0.38, color="#2b6cb0", label="PP.H4 (shared causal variant)")
ax.axvline(0.8, color="crimson", linestyle="--", linewidth=1)
ax.set_yticks(y); ax.set_yticklabels(c.gene, fontsize=8)
ax.set_xlim(0, 1.02); ax.set_xlabel("Posterior probability", fontsize=9)
ax.tick_params(axis="x", labelsize=8)
for spine in ("top", "right"):
    ax.spines[spine].set_visible(False)
ax.set_title("Colocalization posteriors at the 12 UACR-associated regions", fontsize=9)
ax.legend(fontsize=7.5, loc="upper center", bbox_to_anchor=(0.5, -0.13), ncol=2, frameon=False)
fig.tight_layout()
for ext in ["png", "pdf", "tif"]:
    fig.savefig(EN / "figures" / f"Fig4_coloc.{ext}", dpi=300, bbox_inches="tight")
plt.close(fig)
print("Fig4 重绘完成:", {f.suffix: f.stat().st_size for f in sorted((EN / "figures").glob("Fig4_coloc.*"))})
