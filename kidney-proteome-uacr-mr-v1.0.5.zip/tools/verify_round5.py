# -*- coding: utf-8 -*-
"""第五轮终检：页数、表结构、三处 SERPINA10 一致性、Steiger 分档、MINOR 落点；并登记第十二节。"""
import re
import zipfile
from pathlib import Path

import fitz
import openpyxl
import pandas as pd
from docx import Document

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")
TR = Path("交付包/03_可溯源资料包")
pdf = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace\document-preview-1843157226\preview.pdf")

print("页数:", fitz.open(pdf).page_count if pdf.exists() else "PDF 缺失")

doc = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in doc.paragraphs)
cells = [c.text for t in doc.tables for r in t.rows for c in r.cells]
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in doc.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(doc.tables[0].rows)}x{len(doc.tables[0].columns)}")

tbl = doc.tables[0]
hdr = [c.text for c in tbl.rows[0].cells]
print("表头:", hdr)
print("P 列存在:", "P" in hdr)

# SERPINA10 三处一致性
print("摘要措辞 inconsistently:", "SERPINA10 inconsistently" in txt)
print("正文陈述句:", "the two datasets therefore conflict" in txt)
print("表内该行:", [c.text for r in tbl.rows for c in r.cells if c.text.startswith("SERPINA10")])

# Steiger 分档
tiers = [r.cells[-1].text for r in tbl.rows[1:]]
print("Steiger 分档:", pd.Series(tiers).value_counts().to_dict())

for k in ["Z = 0.58", "inconclusive", "184 neuro-related proteins", "neurological cohorts rather than general populations",
          "no candidate was replicated in plasma from a general population", "per-SD protein changes in log UACR",
          "and albuminuria measures barrier integrity", "unresolved [6]"]:
    print(f"  {k}: {k in txt}")

wb = openpyxl.load_workbook(EN / "supplementary/Table_S1_S17.xlsx", read_only=True)
print("EN 工作簿表数:", len(wb.sheetnames), "| S17 行:", wb["S17_Steiger"].max_row,
      "| 含 Tier 列:", "Tier" in [c.value for c in next(wb["S17_Steiger"].iter_rows(max_row=1))])
wb.close()

for n in ["01_英文资料包", "02_中文资料包", "03_可溯源资料包"]:
    z = Path("交付包") / f"{n}.zip"
    with zipfile.ZipFile(z) as zf:
        print(f"{n}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")

p = Path("审稿意见应答表.md")
t = p.read_text(encoding="utf-8")
add = """
## 十二、第五轮意见处理

| 条目 | 处理 | 状态 |
|---|---|---|
| M1 SERPINA10 三处矛盾 | 正文首句改为陈述句（“gave β = −0.0098 … but its four-instrument dataset gave β = 0.005 (P = 0.28) … so the two datasets therefore conflict”），Q = 14.2、P = 0.007 写入正文；摘要 “inconsistently”、Table 1 “Conflict (CSF; neurological cohort)”、正文三处用词统一；两数据集并列于 S7 | 已改 |
| M2 摘要漏 ITIH1 | 摘要改为 “ISLR2, ITIH1 and PCOLCE were direction-consistent in independent panels (one serum, two CSF)” | 已改 |
| M3 Steiger 全标 ok | 改为 strong / moderate / inconclusive 三档（strong 3、moderate 3、inconclusive 6）；正文与表注点明最低者为 MCL1（Z = 0.58）；S17 增 Tier 列并列 Z、P、N | 已改 |
| M4 复制面板人群与覆盖 | Methods 写明血清面板来自两个隔离人群、仅 184 个神经相关蛋白，脑脊液面板为神经疾病队列（临床正常 + 神经退行性疾病，3,506 例）；Table 1 措辞改为 “Direction-consistent (serum/CSF; neurological cohort)”；Limitations 增 “come from neurological cohorts rather than general populations”，并写明无候选在一般人群血浆独立平台复制 | 已改 |
| M5 Table 1 缺 P 值、SERPINA10 两数据集不可见 | Table 1 增 P 列（9 列），并加脚注说明 SERPINA10 的双数据集与异质性、Steiger 分档定义 | 已改 |
| MINOR 1 尺度不可比 | Results 增句：复制估计为“per-SD protein change in log UACR”，与表 1 百分比不同尺度 | 已改 |
| MINOR 2 语法 | 改为 “eGFR measures filtration capacity, and albuminuria measures barrier integrity” | 已改 |
| MINOR 3 引用不贴切 | [10] 改为 [6]（Lanktree 2023） | 已改 |
| MINOR 5 ITIH1 权重 | 摘要该句后加 “on the weakest evidence in the table” | 已改 |
| MINOR 4/6/7 | 未做：三个蛋白的反向 MR、Figure 2 重绘、基金确认 | 未完成 |
"""
if "## 十二、第五轮意见处理" not in t:
    t = t.rstrip() + "\n" + add
p.write_text(t, encoding="utf-8")
print("应答表行数:", len(t.splitlines()))
