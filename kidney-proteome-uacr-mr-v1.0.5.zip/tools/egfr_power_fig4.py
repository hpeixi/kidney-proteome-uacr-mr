# -*- coding: utf-8 -*-
"""eGFR 侧条件功效（S15）+ 图 4 加 PP.H3，并重建稿件与包。"""
import re
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import openpyxl
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
RES = TR / "results"

# ---------- 1) eGFR 条件功效 ----------
res = pd.read_csv(RES / "cis_mr_results.csv")
e = res[res.eGFR_fdr < 0.05].copy()
Z_A05, Z_BONF = 1.96 + 0.84, 3.93 + 0.84
e["beta_min_80_alpha05"] = (Z_A05 * e.eGFR_se).round(6)
e["beta_min_80_bonf"] = (Z_BONF * e.eGFR_se).round(6)
e["ratio_obs_to_min"] = (e.eGFR_beta.abs() / e.beta_min_80_alpha05).round(2)
s15 = e[["gene", "protein", "n_snp", "eGFR_beta", "eGFR_se", "eGFR_p", "eGFR_fdr",
          "beta_min_80_alpha05", "beta_min_80_bonf", "ratio_obs_to_min"]].copy()
s15.columns = ["Gene", "Protein", "Instruments", "beta", "SE", "P", "FDR",
               "Min detectable beta (80% power, alpha 0.05)", "Min detectable beta (Bonferroni)", "Observed/min"]
s15 = s15.sort_values("FDR")
s15.to_csv(RES / "S15_eGFR_power.csv", index=False, encoding="utf-8-sig")
print("S15 行数:", len(s15), "| 达到自身 alpha0.05 阈值比例:",
      int((s15["Observed/min"] >= 1).sum()), "/", len(s15),
      "| 中位 ratio:", s15["Observed/min"].median())

# ---------- 2) 图 4：PP.H3 + PP.H4 ----------
c = pd.read_csv(RES / "coloc_final.csv").sort_values("H4", ascending=True)
fig, ax = plt.subplots(figsize=(7.2, 5.2))
y = np.arange(len(c))
ax.barh(y - 0.2, c.H3, height=0.38, color="#9aa5b1", label="PP.H3 (distinct causal variants)")
ax.barh(y + 0.2, c.H4, height=0.38, color="#2b6cb0", label="PP.H4 (shared causal variant)")
ax.axvline(0.8, color="crimson", linestyle="--", linewidth=1)
ax.set_yticks(y); ax.set_yticklabels(c.gene, fontsize=8)
ax.set_xlim(0, 1.02); ax.set_xlabel("Posterior probability", fontsize=9)
ax.tick_params(axis="x", labelsize=8)
for spine in ("top", "right"):
    ax.spines[spine].set_visible(False)
ax.legend(fontsize=7.5, loc="lower right", frameon=False)
ax.set_title("Colocalization posteriors at the 12 UACR-associated regions", fontsize=9)
fig.tight_layout()
for ext in ["png", "pdf", "tif"]:
    p = EN / "figures" / f"Fig4_coloc.{ext}"
    fig.savefig(p, dpi=300, bbox_inches="tight")
plt.close(fig)
print("Fig4 已重绘:", [f.stat().st_size for f in sorted((EN / 'figures').glob('Fig4_coloc.*'))])

# ---------- 3) 改稿 ----------
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
subs = [
 ("estimates for all 31 are given in Supplementary Table S10.",
  "estimates for all 31 are given in Supplementary Table S10, with conditional power in Supplementary Table S15."),
 ("**Figure 4.** Posterior probabilities of colocalization between pQTL and UACR signals.",
  "**Figure 4.** Posterior probability of a shared causal variant (PP.H4) and of distinct causal variants (PP.H3) at each of the 12 regions; the dashed line marks the prespecified 0.8 threshold."),
 ("S14 hypergeometric test of overlap between the UACR and eGFR hit lists.",
  "S14 hypergeometric test of overlap between the UACR and eGFR hit lists; S15 conditional power for the 31 eGFR estimates."),
]
for a, b in subs:
    assert a in md, a[:50]
    md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")

# ---------- 4) 工作簿加 S15 ----------
def rebuild_book(src, dst):
    wb = openpyxl.load_workbook(src)
    name = "S15_eGFR_power"
    if name in wb.sheetnames:
        del wb[name]
    ws = wb.create_sheet(name)
    ws.append(list(s15.columns))
    for _, row in s15.iterrows():
        ws.append([None if pd.isna(v) else v for v in row.values])
    wb.save(dst); wb.close()

en_old = EN / "supplementary" / "Table_S1_S14.xlsx"
en_new = EN / "supplementary" / "Table_S1_S15.xlsx"
zh_old = ZH / "supplementary" / "投稿材料_补充表_S1_S14.xlsx"
zh_new = ZH / "supplementary" / "投稿材料_补充表_S1_S15.xlsx"
rebuild_book(en_old, en_new); rebuild_book(zh_old, zh_new)
en_old.unlink(); zh_old.unlink()
for p in [EN / "README.md", ZH / "README.md"]:
    t = p.read_text(encoding="utf-8")
    t = t.replace("Table_S1_S14.xlsx", "Table_S1_S15.xlsx").replace("投稿材料_补充表_S1_S14.xlsx", "投稿材料_补充表_S1_S15.xlsx")
    t = t.replace("S1–S14", "S1–S15").replace("S1-S14", "S1-S15")
    p.write_text(t, encoding="utf-8")

# ---------- 5) 重建 docx ----------
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(3)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

# ---------- 6) 核验与打包 ----------
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("摘要:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)),
      "| S15 引用:", "Supplementary Table S15" in txt,
      "| 图注含 PP.H3:", "PP.H3" in txt)
wb = openpyxl.load_workbook(en_new, read_only=True)
print("工作表:", len(wb.sheetnames), "| S15 行:", wb["S15_eGFR_power"].max_row)
wb.close()

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
