# -*- coding: utf-8 -*-
"""最终登记：Figure 2 重绘与效应量校正写入应答表；并输出终检结果。"""
from pathlib import Path

from docx import Document

EN = Path("交付包/01_英文资料包")
d = Document(EN / "manuscript_en.docx")
t = "\n".join(p.text for p in d.paragraphs)
print("A-C 图注:", "(C) Whether each criterion was met" in t)
print("Steiger 图例:", "inner symbol is the Steiger tier" in t)
print("双判据并列:", "Colocalization and replication displayed together" in t)

add = """
### 十四之补充（Figure 2 重绘与效应量校正）

| 事项 | 处理 | 证据 |
|---|---|---|
| Figure 2 双判据重绘 | 旧图仅为效应量森林图；新图三面板：A 共定位 PP.H4（虚线 0.8）、B 每 SD 效应量与 95% CI（内层符号标 Steiger 分档）、C 双判据矩阵（共享变异、独立复现是否各自成立），颜色统一编码复现状态 | figures/Fig2_dual_criteria.png/pdf/tif（300 dpi）；Fig2_forest_UACR.* 已移除 |
| M1 效应量再校正 | 复核发现上一版把 ISLR2、BAG3 误改为 −6.6/−9.3 与 +5.1/+8.2（其中 −9.3 实为 MCL1 的区间）。按 cis_mr_results.csv 的 expm1 复算，真值为 ISLR2 −6.4%（−8.9 至 −3.8）、BAG3 +5.3%（+2.1 至 +8.5）；摘要、正文、表 1 三处统一为真值 | 12 行逐行比对全部 OK |
| Table 1 其余旧值 | OAF、APOA5、SERPINF2、MCL1、PCOLCE、ANGPTL1、RSPO3 的效应量与 CI 一并按源表重写 | 同上一并比对 |
| 中文包同步 | 撤回“结果几乎不重叠、两种表型不可互换”，改为 P = 0.47 与效能边界（P(X≥3) = 0.020）及“不应默认替代”；表 1 复现列改为 CSF 口径；图 2 图注与图件同步；补 [16]–[19] | manuscript_zh/bilingual 的 .md 与 .docx 均已重建 |
"""
p = Path("审稿意见应答表.md")
s = p.read_text(encoding="utf-8")
if "Figure 2 重绘与效应量校正" not in s:
    s = s.rstrip() + "\n" + add
    p.write_text(s, encoding="utf-8")
print("应答表行数:", len(s.splitlines()))
