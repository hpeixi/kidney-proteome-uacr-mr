# -*- coding: utf-8 -*-
"""对比润色前后数字与基因名，检查摘要词数。"""
import re
from pathlib import Path

old = Path("repo/tools/manuscript_en_before_polish.md").read_text(encoding="utf-8")
new = Path("交付包/01_英文资料包/manuscript_en.md").read_text(encoding="utf-8")

num = r"[−+]?\d[\d,\.]*%?"
o, n = set(re.findall(num, old)), set(re.findall(num, new))
print("基线数字 token:", len(o), "| 新版:", len(n))
print("新版缺失:", sorted(o - n))
print("新版新增:", sorted(n - o))

genes = ["APOA5", "MCL1", "BAG3", "ISLR2", "SERPINA10", "ANGPTL1", "PCOLCE", "RSPO3",
         "FCGR2A", "ITIH1", "OAF", "SERPINF2", "ITIH3", "ITIH4"]
missing = [g for g in genes if g in old and g not in new]
print("基因名缺失:", missing)

ab = new[new.index("**Purpose.**"):new.index("**Keywords:**")]
w = len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", re.sub(r"\*\*(Purpose|Methods|Results|Conclusion)\.\*\*", "", ab)))
w_all = len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab))
print("摘要词数(不含小标题):", w, "| 含小标题:", w_all)

body = new[new.index("## Introduction"):new.index("## References")]
print("正文字数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*", body)))
