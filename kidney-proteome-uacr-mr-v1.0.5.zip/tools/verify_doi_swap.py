# -*- coding: utf-8 -*-
"""核验 DOI 替换结果，并把误放进英文包的构建脚本移出、重打 zip。"""
import re, shutil, zipfile
from pathlib import Path
from docx import Document

OUT = Path("交付包"); EN, ZH, TR = OUT/"01_英文资料包", OUT/"02_中文资料包", OUT/"03_可溯源资料包"
NEW, OLD = "10.5281/zenodo.23852899", "10.5281/zenodo.23851813"

print("== DOI 核验")
targets = [EN/"manuscript_en.md", EN/"manuscript_en.docx", EN/"cover_letter.md", EN/"cover_letter.docx",
           EN/"README.md", ZH/"manuscript_zh.md", ZH/"manuscript_zh.docx",
           ZH/"manuscript_bilingual.md", ZH/"manuscript_bilingual.docx", ZH/"README.md",
           TR/"metadata/CITATION.cff", Path("repo/metadata/CITATION.cff")]
for p in targets:
    if p.suffix == ".docx":
        t = "\n".join(x.text for x in Document(p).paragraphs)
    else:
        t = p.read_text(encoding="utf-8")
    print(f"  {p.as_posix()}: 新={NEW in t}, 旧残留={OLD in t}")

d = (TR/"metadata/DOI.txt").read_text(encoding="utf-8")
print("  DOI.txt v1.0.3 行:", [l for l in d.splitlines() if l.startswith("v1.0.3")][0][:60])
print("  DOI.txt 保留 v1.0.2 历史:", "23851813" in d)

# ---- 构建脚本移出交付包 ----
tools = Path("repo/tools"); tools.mkdir(parents=True, exist_ok=True)
stray = [p for p in EN.iterdir() if p.is_file() and (p.suffix in {".py", ".json"})]
for p in stray:
    shutil.move(str(p), str(tools/p.name))
    print("  移出:", p.name)

# ---- 重打 01 zip ----
z = OUT/"01_英文资料包.zip"
if z.exists(): z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包")/f.relative_to(EN))
with zipfile.ZipFile(z) as zf:
    names = zf.namelist()
print(f"\n01 zip: {len(names)} 条目, 完整={zipfile.ZipFile(z).testzip() is None}")
print("  包内文件:", sorted(Path(n).name for n in names if Path(n).parent.name == "01_英文资料包"))
