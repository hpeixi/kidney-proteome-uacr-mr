# -*- coding: utf-8 -*-
import re, os, zipfile
from pathlib import Path
from docx import Document
from PIL import Image

OUT = Path("..")
EN, ZH = OUT / "01_英文资料包", OUT / "02_中文资料包"
O_CORR = "0009-0006-5762-8650"
O_FIRST = "0009-0004-5436-7788"

def dtxt(p):
    return "\n".join(x.text for x in Document(p).paragraphs)

print("== ORCID 落位")
for f in [EN/"manuscript_en.docx", EN/"cover_letter.md", EN/"cover_letter.docx",
          ZH/"manuscript_zh.md", ZH/"manuscript_zh.docx", ZH/"manuscript_bilingual.docx"]:
    t = dtxt(f) if f.suffix == ".docx" else f.read_text(encoding="utf-8")
    print(f"  {f.relative_to(OUT)}: 通讯={O_CORR in t}, 一作={O_FIRST in t}")

print("\n== 英文稿格式")
d = Document(EN/"manuscript_en.docx")
txt = dtxt(EN/"manuscript_en.docx")
refs = [p.text for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]
print("  行距(样式):", d.styles["Normal"].paragraph_format.line_spacing,
      "| 行号:", "lnNumType" in d.element.xml, "| 页码域:", "PAGE" in d.sections[0].footer.paragraphs[0]._p.xml)
print("  文献:", len(refs), "| 全部含题名:", all(len(r) > 55 for r in refs))
print("  示例:", refs[0][:110])
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
n = len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab))
print("  摘要词数:", n, "| 表:", len(d.tables), "| 段落:", len(d.paragraphs))

print("\n== 图件")
for f in sorted(os.listdir(EN/"figures")):
    if f.endswith(".tif"):
        im = Image.open(EN/"figures"/f)
        print(f"  {f}: {im.size}, dpi={im.info.get('dpi')}")

print("\n== 压缩包")
for z in [OUT/"01_英文资料包.zip", OUT/"02_中文资料包.zip", OUT/"03_可溯源资料包.zip"]:
    with zipfile.ZipFile(z) as zf:
        names = zf.namelist()
        print(f"  {z.name}: {len(names)} 条目, 完整={zf.testzip() is None}, {z.stat().st_size/1024/1024:.1f} MB")
