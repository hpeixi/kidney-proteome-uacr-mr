# Circulating plasma proteins and albuminuria: a cis-pQTL Mendelian randomization and colocalization study

**Authors:** Peixi Huang^1,2^ (ORCID 0009-0004-5436-7788), Dingzhuo Hong^2^, Zhiyuan Gao^2^, Xikui Zhang^1^ (ORCID 0009-0006-5762-8650)

**Affiliations:** 1. Fujian University of Traditional Chinese Medicine, Fuzhou 350122, Fujian, China; 2. Department of Nephrology, The Second Affiliated Hospital of Guizhou Medical University, Kaili 556000, Guizhou, China

**Corresponding author:** Xikui Zhang, Chief Physician, Professor, Doctoral Supervisor, Department of Nephrology, The Second Affiliated Hospital of Guizhou Medical University, Kaili 556000, Guizhou, China. E-mail: 623067910@qq.com; ORCID: 0009-0006-5762-8650

**First author:** Peixi Huang (born 1988), attending physician, PhD candidate. E-mail: hpeixi@foxmail.com; ORCID: 0009-0004-5436-7788

**Funding:** None.

---

## Abstract

**Purpose.** Albuminuria reflects injury to the glomerular filtration barrier and predicts chronic kidney disease progression, but which circulating proteins causally influence it remains uncertain. Most proteome-wide Mendelian randomization (MR) studies have used estimated glomerular filtration rate (eGFR) or a diagnostic label as the outcome.

**Methods.** Two-sample MR used cis protein quantitative trait loci for 3,282 plasma proteins measured in 3,301 European-ancestry individuals, tested against European-ancestry summary statistics for the urinary albumin-to-creatinine ratio (UACR; CKDGen) and eGFR (CKDGen). Instruments were restricted to variants within 500 kb of the encoding gene with F > 10. Effects were estimated by the Wald ratio or inverse-variance weighting; colocalization used an approximate Bayes factor.

**Results.** Of 3,282 proteins, 2,162 had at least one genome-wide significant pQTL; after cis restriction, 582 proteins remained evaluable (769 variant–protein pairs; 429 with a single instrument; median minimum F 68.0). Twelve proteins were associated with UACR at false discovery rate < 0.05, with changes from −6.4% to +5.3% per 1-SD higher genetically predicted protein; eight colocalized (PP.H4 ≥ 0.8). Thirty-one proteins were associated with eGFR, and only ITIH1 was significant for both traits with discordant directions. SERPINA10 replicated in an independent panel, whereas BAG3 showed an opposite direction in a larger panel; reverse-direction analysis supported BAG3 as a consequence rather than a cause.

**Conclusion.** Eight circulating proteins met prespecified genetic and colocalization criteria for an effect on albuminuria. Of two testable in independent panels, one replicated and one was contradicted; the remaining candidates require replication.

**Keywords:** Albuminuria; Mendelian randomization; Plasma proteome; Colocalization; Chronic kidney disease

---

## Introduction

Albuminuria marks glomerular injury and predicts kidney failure and cardiovascular death, yet its protein determinants are poorly defined. Observational associations are difficult to interpret because circulating protein concentrations themselves change as kidney function declines, producing reverse causation and confounding by disease severity.

Mendelian randomization (MR) uses genetic variants that alter an exposure as instruments and is less vulnerable to these biases. Proteome-wide MR has prioritized proteins for eGFR, CKD diagnosis, diabetic kidney disease and IgA nephropathy, but almost always with eGFR or a diagnostic label as the outcome. Albuminuria and eGFR capture different biology: eGFR reflects filtration capacity, whereas albuminuria reflects the integrity of the filtration barrier. We therefore performed a cis-pQTL MR study with albuminuria as the primary outcome, eGFR as a comparator, and colocalization to separate shared causal variants from linkage disequilibrium.

## Methods

### Design and data sources

Two-sample summary-data MR; the analysis plan was fixed before the main analysis and reporting follows STROBE-MR. Plasma pQTL summary statistics were from the SomaScan study of Sun and colleagues (3,301 European-ancestry participants; 3,282 aptamer datasets via OpenGWAS). UACR and eGFR summary statistics were from CKDGen (European-ancestry subsets of analyses including 564,257 and 1,046,070 participants, respectively). All data were summary-level. Sources are listed in Supplementary Table S9.

### Instruments and protein-to-gene mapping

Variants were restricted to 500 kb around the transcription start site of the encoding gene, required P < 5×10⁻⁸ and F > 10, and were aligned to GRCh37 coordinates from the outcome datasets (positions reported by the exposure resource used mixed builds). Protein names were mapped to genes through UniProt, preferring reviewed human entries; ambiguous mappings were excluded. For the twelve prioritized proteins, each lead variant was confirmed to lie within 500 kb of the mapped gene. A manual check of fifteen random mappings found three paralog assignments and one unmapped protein (none prioritized).

### Estimation and inference

Single-instrument proteins were analysed by the Wald ratio (β outcome / β protein) with delta-method standard errors; proteins with two or more instruments by inverse-variance weighting. Directionality was examined by comparing explained variance. Multiple testing used Benjamini–Hochberg FDR across evaluable proteins (Bonferroni threshold 8.6×10⁻⁵). Conditional power, derived from each standard error, showed a median detectable change of 3.6% in UACR at 80% power and Bonferroni alpha (2.1% at FDR 0.05).

### Colocalization

For proteins reaching FDR < 0.05, UACR variants within 100 kb of the lead pQTL were matched to pQTL effects, and posterior probabilities for five hypotheses were computed under a single causal variant assumption (priors 1×10⁻⁴ for each trait, 1×10⁻⁵ for a shared variant). PP.H4 ≥ 0.8 was prespecified as strong evidence.

### Replication, sensitivity and reverse direction

Independent pQTL datasets were sought for the prioritized proteins. A multi-instrument sensitivity analysis was restricted to proteins with two or more cis instruments. A reverse-direction MR used pruned UACR instruments to estimate effects on BAG3. Analyses used Python 3.12 (NumPy, SciPy, pandas) with data retrieved through the OpenGWAS API.

## Results

### Instruments

Of 3,282 proteins, 2,162 had at least one genome-wide significant pQTL (3,854 records; 2,271 unique variants). After cis restriction, 769 variant–protein pairs covering 582 proteins remained; 429 (73.7%) had a single instrument, and the median minimum F was 68.0 (range 29.8–2,758).

### Proteins associated with UACR and eGFR

Twelve proteins were associated with UACR at FDR < 0.05 (Table 1, Figure 2), with effects from −6.4% (95% CI −8.9 to −3.8) for ISLR2 to +5.3% (+2.1 to +8.5) for BAG3 per 1-SD higher protein. Nine were inversely and three (BAG3, PCOLCE, FCGR2A) positively associated. Thirty-one proteins were associated with eGFR. Only ITIH1 was significant for both, with discordant directions: a 1.46% lower UACR (95% CI −2.07 to −0.83) and a 0.0025 lower eGFR (−0.0036 to −0.0014) per SD (both P = 5.7×10⁻⁶), based on a single variant (rs1042779) in the ITIH1–ITIH3–ITIH4 cluster (Figure 3).

### Colocalization

Eight of the twelve proteins showed strong evidence of a shared causal variant: APOA5 (0.996), MCL1 (0.984), BAG3 (0.966), ISLR2 (0.887), SERPINA10 (0.882), ANGPTL1 (0.873), PCOLCE (0.852) and RSPO3 (0.817). FCGR2A (0.678) and ITIH1 (0.614) were intermediate, and OAF (PP.H3 0.998) and SERPINF2 (0.952) showed distinct causal variants (Figure 4).

### Replication, sensitivity and reverse direction

SERPINA10 replicated with a consistent direction (three cis variants; β = −0.0098, SE 0.0028, P = 4.0×10⁻⁴), whereas BAG3 was contradicted in the UKB-PPP panel (405 cis variants; β = −0.032, SE 0.0025, P = 7.2×10⁻³⁶ versus +0.051 in the primary panel). ANGPTL1 had no genome-wide significant cis variant in the independent dataset, and five proteins had no independent data. Among 145 proteins with two or more instruments, only OAF retained FDR < 0.05 (β = −0.016, P = 6.9×10⁻⁵), and SERPINA10 did not reach significance (P = 0.28). A reverse-direction analysis using 57 pruned UACR instruments associated UACR with lower BAG3 (β = −0.26, SE 0.054, P = 1.3×10⁻⁶).

## Discussion

Eight proteins met prespecified criteria for an effect on albuminuria, but independent testing was possible for only two and gave discordant results. The set is biologically heterogeneous and does not map onto a single pathway.

PCOLCE enhances procollagen maturation, and its positive association fits a pro-fibrotic direction. BAG3 is a chaperone implicated in podocyte biology; its positive association implied higher albuminuria with higher protein, but this was not reproduced in UKB-PPP, and the reverse-direction analysis suggested that albuminuria lowers circulating BAG3. APOA5 regulates triglyceride-rich lipoproteins and its inverse association is compatible with a lipid–kidney axis; RSPO3 and ANGPTL1 have vascular roles; SERPINA10 inhibits protein Z-dependent protease activity. ISLR2 and MCL1 are less easily interpreted, and MCL1 colocalization may reflect pleiotropic variants.

The near-absence of overlap between UACR and eGFR results argues that the two phenotypes are not interchangeable readouts and supports treating albuminuria as a distinct outcome in proteomic causal inference.

## Limitations

The exposure panel was modest and 74% of proteins had a single instrument, precluding pleiotropy-robust estimators. Colocalization assumed one causal variant, used a 100 kb window and no ancestry-matched LD matrix. Reverse MR was performed only for BAG3. Analyses were restricted to European ancestry. Protein-to-gene mapping was name-based. No experimental validation was performed, and the proteins should be regarded as candidates.

## Conclusions

This cis-pQTL MR and colocalization analysis identified eight candidate proteins for albuminuria, one of which replicated and one of which was contradicted in an independent panel. The results support albuminuria as a phenotype distinct from eGFR and provide a prioritized list for functional follow-up.

## Declarations

**Ethics approval and consent to participate.** Not applicable; only publicly available summary statistics were used.

**Consent for publication.** Not applicable.

**Availability of data and materials.** All summary statistics are publicly available from CKDGen and OpenGWAS. Derived tables are provided as supplementary files and deposited at https://github.com/hpeixi/kidney-proteome-uacr-mr (DOI: 10.5281/zenodo.23851408).

**Competing interests.** The authors declare that they have no competing interests.

**Funding.** The authors received no specific funding for this work.

**Authors' contributions.** Peixi Huang designed the study, performed the analyses and drafted the manuscript. Dingzhuo Hong and Zhiyuan Gao contributed to data interpretation and critical revision. Xikui Zhang supervised the study and revised the manuscript. All authors read and approved the final manuscript.

## References
1. Teumer A, Li Y, Ghasemi S, et al. Genome-wide association meta-analyses and fine-mapping elucidate pathways influencing albuminuria. Nat Commun. 2019;10(1):4130.
2. Wuttke M, Li Y, Li M, et al. A catalog of genetic loci associated with kidney function from analyses of a million individuals. Nat Genet. 2019;51(6):957-972.
3. Sun BB, Maranville JC, Peters JE, et al. Genomic atlas of the human plasma proteome. Nature. 2018;558(7708):73-79.
4. Ferkingstad E, Sulem P, Atlason BA, et al. Large-scale integration of the plasma proteome with genetics and disease. Nat Genet. 2021;53(12):1712-1721.
5. Sun BB, Chiou J, Traylor M, et al. Plasma proteomic associations with genetics and health in the UK Biobank. Nature. 2023;622(7982):329-338.
6. Lanktree MB, Perrot N, Smyth A, et al. A novel multi-ancestry proteome-wide Mendelian randomization study implicates extracellular proteins, tubular cells, and fibroblasts in estimated glomerular filtration rate regulation. Kidney Int. 2023;104(6):1170-1184.
7. Si S, Liu H, Xu L, et al. Identification of novel therapeutic targets for chronic kidney disease and kidney function by integrating multi-omics proteome with transcriptome. Genome Med. 2024;16(1):84.
8. Zhao P, Li Z, Xue S, et al. Proteome-wide mendelian randomization identifies novel therapeutic targets for chronic kidney disease. Sci Rep. 2024;14(1):22114.
9. Zhang W, Ma L, Zhou Q, et al. Therapeutic Targets for Diabetic Kidney Disease: Proteome-Wide Mendelian Randomization and Colocalization Analyses. Diabetes. 2024;73(4):618-627.
10. Deo R, Dubin RF, Ren Y, et al. Proteomic cardiovascular risk assessment in chronic kidney disease. Eur Heart J. 2023;44(23):2095-2110.
11. Giambartolomei C, Vukcevic D, Schadt EE, et al. Bayesian test for colocalisation between pairs of genetic association studies using summary statistics. PLoS Genet. 2014;10(5):e1004383.
12. Verbanck M, Chen CY, Neale B, et al. Detection of widespread horizontal pleiotropy in causal relationships inferred from Mendelian randomization between complex traits and diseases. Nat Genet. 2018;50(5):693-698.
13. Bowden J, Davey Smith G, Haycock PC, et al. Consistent Estimation in Mendelian Randomization with Some Invalid Instruments Using a Weighted Median Estimator. Genet Epidemiol. 2016;40(4):304-14.
14. Burgess S, Butterworth A, Thompson SG. Mendelian randomization analysis with multiple genetic variants using summarized data. Genet Epidemiol. 2013;37(7):658-65.
15. Gillies CE, Putler R, Menon R, et al. An eQTL Landscape of Kidney Tissue in Human Nephrotic Syndrome. Am J Hum Genet. 2018;103(2):232-244.

## Table

**Table 1.** Proteins associated with UACR at FDR < 0.05, with replication status.

| Gene | Instruments | Change per SD (%) | 95% CI | FDR | PP.H4 | Replication |
|---|---|---|---|---|---|---|
| ISLR2 | 1 | −6.4 | −8.9 to −3.8 | 8.8×10⁻⁴ | 0.887 | Not available |
| ITIH1 | 1 | −1.5 | −2.1 to −0.8 | 1.6×10⁻³ | 0.614 | Not available |
| OAF | 2 | −1.6 | −2.3 to −0.8 | 1.3×10⁻² | 0.002 | Not available |
| APOA5 | 1 | −5.0 | −7.4 to −2.5 | 1.4×10⁻² | 0.996 | Not available |
| SERPINA10 | 1 | −1.2 | −1.9 to −0.6 | 1.7×10⁻² | 0.882 | Replicated |
| SERPINF2 | 1 | −4.5 | −6.9 to −2.0 | 4.0×10⁻² | 0.048 | Not available |
| BAG3 | 1 | +5.3 | +2.1 to +8.5 | 4.6×10⁻² | 0.966 | Not replicated (opposite) |
| MCL1 | 1 | −6.0 | −9.3 to −2.6 | 4.6×10⁻² | 0.984 | Not available |
| PCOLCE | 1 | +3.7 | +1.6 to +5.9 | 4.6×10⁻² | 0.852 | Not available |
| FCGR2A | 2 | +0.5 | +0.2 to +0.9 | 4.6×10⁻² | 0.678 | Not available |
| ANGPTL1 | 2 | −1.6 | −2.6 to −0.7 | 4.6×10⁻² | 0.873 | Not evaluable |
| RSPO3 | 1 | −2.5 | −4.0 to −1.0 | 4.7×10⁻² | 0.817 | Not available |

## Figure legends

**Figure 1.** Study design and evidence flow.

**Figure 2.** Cis-pQTL MR estimates for the 12 proteins associated with UACR; BAG3 is shown in red as not replicated.

**Figure 3.** Concordance between effects on UACR and on eGFR.

**Figure 4.** Posterior probabilities of colocalization between pQTL and UACR signals.
