# -*- coding: utf-8 -*-
"""交付前最终核对：稿件、表格、包、校验清单、仓库同步状态。"""
import hashlib
import re
import zipfile
from pathlib import Path

from docx import Document

ROOT = Path(".")
EN = ROOT / "交付包/01_英文资料包"
ZH = ROOT / "交付包/02_中文资料包"
TR = ROOT / "交付包/03_可溯源资料包"
REPO = ROOT / "repo"

d = Document(EN / "manuscript_en.docx")
t = "\n".join(p.text for p in d.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*"
print("EN 摘要:", len(re.findall(pat, t[t.index("Purpose."):t.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
rows = [[c.text.strip() for c in r.cells] for r in d.tables[0].rows]
print("EN 表列:", rows[0])
print("EN 关键句:", all(k in t for k in [
    "no candidate replicated in plasma", "P = 0.47", "P(X ≥ 3) = 0.020",
    "The list matters less than what the screen shows", "In this dataset, eGFR-anchored screening was no substitute"]))
print("EN 数字:", "−6.4% (95% CI −8.9 to −3.8)" in t, "+5.3% (+2.1 to +8.5)" in t)

z = Document(ZH / "manuscript_zh.docx")
zt = "\n".join(p.text for p in z.paragraphs)
zr = [[c.text.strip() for c in r.cells] for r in z.tables[0].rows]
print("ZH 表:", f"{len(zr)}x{len(zr[0])}", "| 表头:", zr[0])
print("ZH 关键:", all(k in zt for k in ["P = 0.47", "不应默认替代", "其中 7 种有独立数据"]),
      "| 旧断言残留:", "几乎不重叠" in zt or "仅 2 种" in zt)

for zp in ("交付包/01_英文资料包.zip", "交付包/02_中文资料包.zip", "交付包/03_可溯源资料包.zip"):
    zf = zipfile.ZipFile(zp)
    print(zp, len(zf.namelist()), "条目 | 完好:", zf.testzip() is None)

sums = (TR / "SHA256SUMS.txt").read_text(encoding="utf-8").strip().split("\n")
print("SHA256 行数:", len(sums))
bad = 0
for line in sums[:5] + sums[-3:]:
    h, rel = line.split("  ", 1)
    p = ROOT / rel
    if p.exists():
        hh = hashlib.sha256(p.read_bytes()).hexdigest()
        bad += int(hh != h)
print("抽样校验不符:", bad)

print("repo 稿件:", sorted(p.name for p in (REPO / "manuscripts").glob("*")))
print("repo 图件:", sorted(p.name for p in (REPO / "figures").glob("*")))
print("上传脚本:", [p.name for p in (REPO / "tools").glob("publish_*.py")],
      "| UPLOAD.md:", (REPO / "UPLOAD.md").exists())
print("PROVENANCE:", (REPO / "PROVENANCE.md").exists(), (TR / "PROVENANCE.md").exists())
