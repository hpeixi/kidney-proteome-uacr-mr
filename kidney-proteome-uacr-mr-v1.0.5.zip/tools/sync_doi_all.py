# -*- coding: utf-8 -*-
"""核验全部交付文件的 DOI，修正中文/对照 docx，重打 02 包并汇总。"""
import re
import zipfile
from pathlib import Path

from docx import Document

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
NEW, OLD = "10.5281/zenodo.23851408", "10.5281/zenodo.23853798"


def docx_text(p):
    d = Document(p)
    cells = [c.text for t in d.tables for r in t.rows for c in r.cells]
    return "\n".join([x.text for x in d.paragraphs] + cells), d


def swap_docx(p):
    d = Document(p)
    n = 0
    for para in d.paragraphs:
        if OLD in para.text:
            n += para.text.count(OLD)
            done = False
            for r in para.runs:
                if OLD in r.text:
                    r.text = r.text.replace(OLD, NEW); done = True
            if not done:
                full = para.text.replace(OLD, NEW)
                para.runs[0].text = full
                for r in para.runs[1:]:
                    r.text = ""
    if n:
        d.save(p)
    return n


targets = [EN/"manuscript_en.docx", EN/"cover_letter.docx", ZH/"manuscript_zh.docx",
           ZH/"manuscript_bilingual.docx"]
print("== 修正前")
for p in targets:
    t, _ = docx_text(p)
    print(f"  {p.name}: 新={NEW in t}, 旧={OLD in t}")

print("\n== 就地替换旧 DOI")
for p in targets:
    n = swap_docx(p)
    if n:
        print(f"  {p.name}: 替换 {n} 处")

print("\n== 修正后")
ok = True
for p in targets:
    t, _ = docx_text(p)
    good = NEW in t and OLD not in t
    ok &= good
    print(f"  {'OK ' if good else 'BAD'} {p.name}")

for p in [EN/"README.md", ZH/"README.md", TR/"metadata/CITATION.cff",
          Path("repo/metadata/CITATION.cff"), TR/"metadata/DOI.txt"]:
    t = p.read_text(encoding="utf-8")
    good = NEW in t and OLD not in t
    ok &= good
    print(f"  {'OK ' if good else 'BAD'} {p.as_posix()}")

# 重打 02 包
z = OUT / "02_中文资料包.zip"
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in ZH.rglob("*"):
        if f.is_file():
            zf.write(f, Path("02_中文资料包") / f.relative_to(ZH))
with zipfile.ZipFile(z) as zf:
    print(f"\n02 zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")

print("\n总判定:", "全部一致" if ok else "仍有不一致")
