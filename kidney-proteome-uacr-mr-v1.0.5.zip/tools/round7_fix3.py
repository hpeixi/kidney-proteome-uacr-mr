# -*- coding: utf-8 -*-
"""Table 1 十二行全部按源表重写；确认图注 A-C；删除旧 Fig2 三件；重建并打包。"""
import re
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
FIG = EN / "figures"
RES = Path("交付包/03_可溯源资料包/results")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

mr = pd.read_csv(RES / "cis_mr_results.csv")
col = pd.read_csv(RES / "coloc_final.csv")
h = mr[mr.UACR_fdr < 0.05].merge(col[["gene", "H4"]], on="gene", how="left")
truth = {}
for r in h.itertuples():
    truth[r.gene] = (np.expm1(r.UACR_beta) * 100,
                     np.expm1(r.UACR_beta - 1.96 * r.UACR_se) * 100,
                     np.expm1(r.UACR_beta + 1.96 * r.UACR_se) * 100)

out, changed, missing = [], [], []
for ln in md.split("\n"):
    if ln.startswith("| ") and ln.count("|") >= 8:
        c = [x.strip() for x in ln.strip().strip("|").split("|")]
        if c[0] in truth:
            p, lo, hi = truth[c[0]]
            new2 = f"{p:+.1f}" if p > 0 else f"{p:.1f}"
            new3 = f"{lo:.1f} to {hi:.1f}"
            if c[2] != new2 or c[3] != new3:
                changed.append((c[0], c[2], c[3], new2, new3))
            c[2], c[3] = new2, new3
            ln = "| " + " | ".join(c) + " |"
    out.append(ln)
md = "\n".join(out)
print("改写行:", changed if changed else "无")
gott = {g for g in truth if f"| {g} |" in md}
print("表内命中数:", len(gott), "| 缺失:", set(truth) - gott)
md_path.write_text(md, encoding="utf-8")

cap_ok = "whether each region met each criterion" in md.lower()
print("图注三面板:", cap_ok)

for old in ("Fig2_forest_UACR.png", "Fig2_forest_UACR.pdf", "Fig2_forest_UACR.tif"):
    f = FIG / old
    if f.exists():
        f.unlink()
print("figures 现存:", sorted(p.name for p in FIG.glob("Fig2*")))

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.2))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        trows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                trows.append(cells)
            i += 1
        t = doc.add_table(rows=len(trows), cols=len(trows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(trows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val); r.font.size = Pt(6.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
tbl = [[c.text.strip() for c in r.cells] for r in d.tables[0].rows]
txt = "\n".join(p.text for p in d.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(tbl)}x{len(tbl[0])}")
for r in tbl[1:]:
    g = r[0]
    if g in truth:
        p, lo, hi = truth[g]
        exp2 = f"{p:+.1f}" if p > 0 else f"{p:.1f}"
        exp3 = f"{lo:.1f} to {hi:.1f}"
        flag = "OK" if (r[2] == exp2 and r[3] == exp3) else f"DIFF {r[2]}|{r[3]} vs {exp2}|{exp3}"
        print(f"  {g}: {flag}")

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
