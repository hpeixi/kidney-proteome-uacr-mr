# -*- coding: utf-8 -*-
"""用 4 个新面板计算 ISLR2/ITIH1/OAF/PCOLCE 的独立复现（Wald 或 IVW）。"""
import gzip
import json
import ssl
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
EXT = Path("data/pqtl_ext")
cis = pd.read_csv("交付包/03_可溯源资料包/results/cis_snps.csv")
res = pd.read_csv("交付包/03_可溯源资料包/results/cis_mr_results.csv")

GENES = ["ISLR2", "ITIH1", "OAF", "PCOLCE"]
FILES = {
    "PCOLCE": ("GCST90421386.tsv.gz", "rs_id"),
    "ITIH1": ("GCST90427174.tsv.gz", "rs_id"),
    "OAF": ("GCST90426688.tsv.gz", "rs_id"),
    "ISLR2": ("GCST90059992_buildGRCh38.tsv.gz", "pos"),
}


def ensembl_pos(rsid):
    url = f"https://rest.ensembl.org/variation/human/{rsid}?content-type=application/json"
    r = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}),
                               timeout=40, context=ctx)
    d = json.loads(r.read().decode())
    for m in d.get("mappings", []):
        if m.get("assembly_name") == "GRCh38":
            return m["seq_region_name"], m["start"], sorted(m.get("allele_string", "").split("/"))
    return None


targets = cis[cis.gene.isin(GENES)]
# ISLR2 的 b38 坐标
islr = targets[targets.gene == "ISLR2"].iloc[0]
chrom38, pos38, alleles38 = ensembl_pos(islr.rsid)
print(f"ISLR2 {islr.rsid} GRCh38: chr{chrom38}:{pos38} 等位基因 {alleles38}")

rows = []
for gene, (fname, mode) in FILES.items():
    inst = targets[targets.gene == gene]
    wanted = set(inst.rsid)
    print(f"\n扫描 {gene} ({fname}) 目标 {sorted(wanted)}")
    hits = []
    with gzip.open(EXT / fname, "rt", encoding="utf-8", errors="ignore") as fh:
        header = fh.readline().rstrip("\n").split("\t")
        idx = {c: i for i, c in enumerate(header)}
        for line in fh:
            if mode == "rs_id":
                parts = line.rstrip("\n").split("\t")
                if parts[idx["rs_id"]] in wanted:
                    hits.append(parts)
                    if len(hits) >= len(wanted):
                        break
            else:
                low = line[:200]
                if f"\t{pos38}\t" in low:
                    parts = line.rstrip("\n").split("\t")
                    if parts[idx["chromosome"]] in (str(chrom38), f"chr{chrom38}") and parts[idx["base_pair_location"]] == str(pos38):
                        hits.append(parts)
                        break
    print(f"  命中 {len(hits)} 个位点")
    for h in hits:
        if mode == "rs_id":
            rec = {"gene": gene, "rsid": h[idx["rs_id"]], "b_rep": float(h[idx["beta"]]),
                   "se_rep": float(h[idx["standard_error"]]), "ea_rep": h[idx["effect_allele"]],
                   "nea_rep": h[idx["other_allele"]], "eaf": h[idx["effect_allele_frequency"]], "n": h[idx["n"]]}
        else:
            rec = {"gene": gene, "rsid": islr.rsid, "b_rep": float(h[idx["beta"]]),
                   "se_rep": float(h[idx["standard_error"]]), "ea_rep": h[idx["effect_allele"]],
                   "nea_rep": h[idx["other_allele"]], "eaf": h[idx["effect_allele_frequency"]], "n": "?"}
        rows.append(rec)

rep = pd.DataFrame(rows)
if rep.empty:
    print("\n没有任何位点命中，终止")
    raise SystemExit(0)

m = rep.merge(targets[["gene", "rsid", "b_exp", "se_exp", "ea", "nea", "UACR_b", "UACR_se"]], on=["gene", "rsid"], how="left")
# 等位基因对齐
def align(r):
    if r.ea == r.ea_rep:
        return r.b_rep
    if r.ea == r.nea_rep and r.nea == r.ea_rep:
        return -r.b_rep
    return np.nan
m["b_rep_aligned"] = m.apply(align, axis=1)
m["wald"] = m.UACR_b / m.b_rep_aligned
m["wald_se"] = np.sqrt((m.UACR_se / m.b_rep_aligned) ** 2 +
                       (m.UACR_b ** 2 * m.se_rep ** 2) / m.b_rep_aligned ** 4)
print("\n逐位点:")
print(m[["gene", "rsid", "b_rep_aligned", "se_rep", "UACR_b", "wald", "wald_se"]].to_string(index=False))

out = []
for gene, g in m.groupby("gene"):
    g = g.dropna(subset=["b_rep_aligned"])
    if g.empty:
        continue
    w = 1 / g.wald_se ** 2
    beta = (g.wald * w).sum() / w.sum()
    se = np.sqrt(1 / w.sum())
    z = beta / se
    from scipy.stats import norm
    p = 2 * norm.sf(abs(z))
    primary = float(res.loc[res.gene == gene, "UACR_beta"].iloc[0])
    out.append({"gene": gene, "n_snp": len(g), "beta_rep": round(beta, 5), "se_rep": round(se, 5),
                "p_rep": f"{p:.2e}", "beta_primary": round(primary, 5),
                "direction": "concordant" if np.sign(beta) == np.sign(primary) else "opposite"})

rep_out = pd.DataFrame(out)
print("\n复现结果:")
print(rep_out.to_string(index=False))
rep_out.to_csv("交付包/03_可溯源资料包/results/replication_extended.csv", index=False, encoding="utf-8-sig")
m.to_csv("交付包/03_可溯源资料包/results/replication_extended_snps.csv", index=False, encoding="utf-8-sig")
print("\n已写出 replication_extended.csv 与 replication_extended_snps.csv")
