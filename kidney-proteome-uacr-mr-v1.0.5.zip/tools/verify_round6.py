# -*- coding: utf-8 -*-
"""终检：页数、图注、图件入包，并登记第十三节。"""
import re
import zipfile
from pathlib import Path

import fitz
from docx import Document

EN = Path("交付包/01_英文资料包")
pdf = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace\document-preview-521824530\preview.pdf")
print("页数:", fitz.open(pdf).page_count if pdf.exists() else "PDF 缺失")

doc = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in doc.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in doc.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(doc.tables[0].rows)}x{len(doc.tables[0].columns)}")
print("图注双判据:", "marker fill shows whether the region passed the colocalization threshold" in txt)
print("普适性句:", "Any proteome-wide MR anchored on eGFR inherits the same constraint" in txt)

z = EN.with_suffix(".zip")
with zipfile.ZipFile(z) as zf:
    names = [n for n in zf.namelist() if "Fig2_forest" in n]
    print("01 包内 Fig2 文件:", names, "| 条目总数:", len(zf.namelist()), "| 完整:", zf.testzip() is None)

for f in sorted((EN / "figures").glob("Fig2_forest_UACR.*")):
    print(f"  {f.name}: {round(f.stat().st_size/1024)} KB")

p = Path("审稿意见应答表.md")
t = p.read_text(encoding="utf-8")
add = """
## 十三、negative control 普适性 + Figure 2 双判据

| 项目 | 处理 |
|---|---|
| 讨论末段 | 增写 “That negative control … generalizes beyond this screen”，并点明 “Any proteome-wide MR anchored on eGFR inherits the same constraint: the proteins it prioritizes are not a substitute for those prioritized on the barrier phenotype”；结论句保留“eGFR 导向筛选不能恢复白蛋白尿导向清单” |
| 摘要结论 | 改为 “eGFR-anchored screens cannot substitute for this approach”（摘要 248 词，仍 ≤250） |
| Figure 2 | 重绘为双判据：**填充**表示共定位是否达标（实心 PP.H4 ≥ 0.8，空心 < 0.8），**颜色**表示复制状态（方向一致/冲突/相反/无效应/不可评估/无数据）；保留森林图与 95% CI；PNG 300 dpi、PDF、TIFF 三格式齐备；图注同步改写 |
| 图上核对 | 12 个蛋白齐全；实心 8 个（即 PP.H4 ≥ 0.8 的 8 个）、空心 4 个；分类计数：方向一致 3、冲突 1、相反 1、无效应 1、不可评估 1、无数据 5 |
"""
if "## 十三、negative control 普适性" not in t:
    t = t.rstrip() + "\n" + add
p.write_text(t, encoding="utf-8")
print("应答表行数:", len(t.splitlines()))
