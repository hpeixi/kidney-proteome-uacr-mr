# -*- coding: utf-8 -*-
"""英文定稿：修缺陷、去模板化改写；断言所有数字 token 不变。"""
import re
from collections import Counter
from pathlib import Path

EN = Path("交付包/01_英文资料包")
p = EN / "manuscript_en.md"
md = p.read_text(encoding="utf-8")

num = lambda s: Counter(re.findall(r"[0-9][0-9,.\u00d7\u207b\u2070-\u209f]*", s))
before = num(md)

R = [
 # --- 缺陷：摘要多余逗号、结论句首小写 ---
 ("Twelve proteins were associated with UACR at false discovery rate < 0.05, (changes −6.4% to +5.3% per SD), and eight colocalized (PP.H4 ≥ 0.8), five of the eight surviving missense exclusion.",
  "Twelve proteins were associated with UACR at false discovery rate < 0.05 (changes −6.4% to +5.3% per SD), and eight colocalized (PP.H4 ≥ 0.8), five of them surviving missense exclusion."),
 ("An albuminuria-directed cis-pQTL screen is feasible, but no protein replicated in plasma independently, and the lists overlapped no more than chance. in this dataset, eGFR-anchored screening was no substitute; five of the eight surviving missense exclusion are candidates for validation.",
  "An albuminuria-directed cis-pQTL screen is feasible, but no protein replicated independently in plasma and the two lists overlapped no more than chance. In this dataset, eGFR-anchored screening was no substitute, and the five proteins that survived missense exclusion are candidates for validation."),
 ("only ITIH1 reached significance for both, in opposite directions, on the weakest evidence in the table.",
  "only ITIH1 reached significance for both, in opposite directions, on the weakest evidence of the twelve."),
 # --- 准确性：四套复制数据 vs “panels”；三套 CSF 分开写 ---
 ("Four further panels came from the GWAS Catalog: a serum SomaScan panel from two isolated population-based cohorts assaying 184 neuro-related proteins [17] (2,893 participants; 2,917 in the GWAS Catalog entry) for ISLR2, and a cerebrospinal fluid SomaScan panel from cognitively normal and neurodegenerative disease participants [18] (3,506 samples) for PCOLCE, ITIH1 and OAF.",
  "Four further datasets came from the GWAS Catalog, spanning two biofluids: a serum SomaScan panel from two isolated population-based cohorts assaying 184 neuro-related proteins [17] (2,893 participants; 2,917 in the GWAS Catalog entry) for ISLR2, and three cerebrospinal fluid datasets from cognitively normal and neurodegenerative disease participants [18] (3,506 samples each) for ITIH1, PCOLCE and OAF."),
 ("Four further panels were retrieved from public repositories:", "Four further datasets were retrieved from public repositories:"),
 # --- 去重复：讨论段两次“12 and 30 hits among 582 proteins” ---
 ("With 12 UACR and 30 eGFR hits among 582 evaluable proteins, expected overlap is 0.62 and one is compatible with chance (P = 0.47, Supplementary Table S14). An eGFR-derived list should not be assumed to stand in for one built on the barrier phenotype. The test is weak, however: with 12 and 30 hits among 582 proteins, at least three overlaps would have been needed for P < 0.05 (P(X ≥ 3) = 0.020), so it can detect substantial overlap but not its absence.",
  "Among 582 evaluable proteins, 12 UACR hits and 30 eGFR hits give an expected overlap of 0.62, and the single shared protein is compatible with chance (P = 0.47, Supplementary Table S14). An eGFR-derived list should not be assumed to stand in for one built on the barrier phenotype. The test is weak, though: at least three overlapping proteins would have been needed for P < 0.05 (P(X ≥ 3) = 0.020), so it can detect substantial overlap but not its absence."),
 # --- 句式去模板化 ---
 ("Our question was narrower than \"which proteins affect the kidney\". We asked which circulating proteins are prioritized by cis genetic instruments when the outcome is albuminuria rather than eGFR, and whether the two lists converge.",
  "The question we could answer was narrower than \"which proteins affect the kidney\": which circulating proteins are prioritized by cis genetic instruments when the outcome is albuminuria rather than eGFR, and whether the two lists converge."),
 ("This paper reports a cis-pQTL MR screen with albuminuria as the primary outcome and eGFR as a comparator, an approximate colocalization analysis, and an explicit test of one candidate in larger independent data, which failed.",
  "What follows is a cis-pQTL MR screen with albuminuria as the primary outcome and eGFR as a comparator, an approximate colocalization analysis, and a test of the prioritised proteins in larger independent data, which largely failed."),
 ("Its value lies less in the list than in three observations. Of the eight colocalized proteins",
  "The list matters less than what the screen shows. Of the eight colocalized proteins"),
 ("And an eGFR-directed screen would not have recovered this set.",
  "An eGFR-directed screen would not have recovered this set either."),
 ("The estimates are therefore associations prioritized by genetic instruments, not causal effects.",
  "The estimates are associations prioritized by genetic instruments, not causal effects."),
 ("a shared signal says nothing about direction, and BAG3 shows how easily that is missed with one panel.",
  "a shared signal says nothing about direction, and BAG3 shows how easily one panel can mislead on that point."),
 ("ISLR2 remains uncharacterized here, although kidney eQTL data place several of these genes in glomerular and tubular compartments [15].",
  "ISLR2 stays uncharacterized here, although kidney eQTL data place several of these genes in glomerular and tubular compartments [15]."),
 # --- 表格：面板措辞与 Methods 一致 ---
 ("| OAF | 2 | -1.6 | -2.3 to -0.8 | 6.9×10⁻⁵ | 1.3×10⁻² | 0.002 | Null (CSF; neurological cohort) [18] | moderate |",
  "| OAF | 2 | -1.6 | -2.3 to -0.8 | 6.9×10⁻⁵ | 1.3×10⁻² | 0.002 | Null (CSF) [18] | moderate |"),
 ("| SERPINA10 | 1 | -1.2 | -1.9 to -0.6 | 1.5×10⁻⁴ | 1.7×10⁻² | 0.882 | Conflict (CSF; neurological cohort) [18]† | moderate |",
  "| SERPINA10 | 1 | -1.2 | -1.9 to -0.6 | 1.5×10⁻⁴ | 1.7×10⁻² | 0.882 | Conflict (CSF) [18]† | moderate |"),
 ("| PCOLCE | 1 | +3.7 | 1.6 to 5.9 | 6.4×10⁻⁴ | 4.6×10⁻² | 0.852 | Direction-consistent (CSF; neurological cohort) [18] | inconclusive |",
  "| PCOLCE | 1 | +3.7 | 1.6 to 5.9 | 6.4×10⁻⁴ | 4.6×10⁻² | 0.852 | Direction-consistent (CSF) [18] | inconclusive |"),
]
miss = []
for a, b in R:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        miss.append(a[:60])
print("未匹配:", miss if miss else "无")
if miss:
    raise SystemExit(1)

after = num(md)
diff = {k: (before[k], after[k]) for k in set(before) | set(after) if before[k] != after[k]}
print("数字 token 差异:", diff if diff else "无（全部保留）")
p.write_text(md, encoding="utf-8")

body = md[md.index("## Abstract"):md.index("**Keywords:**")]
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*"
print("摘要词数:", len(re.findall(pat, body)))
print("em dash:", md.count("—"), "| 段落数:", len([x for x in md.split("\n") if x and not x.startswith(("#", "|", "*", "-"))]))
