# -*- coding: utf-8 -*-
import re
from docx import Document
from PIL import Image

d = Document("manuscript_en.docx")
ps = [x.text.strip() for x in d.paragraphs]

# 找 Abstract 与 Introduction 段
i_ab = next(i for i, t in enumerate(ps) if t == "Abstract")
i_in = next(i for i, t in enumerate(ps) if t == "Introduction")
ab = " ".join(ps[i_ab + 1:i_in])
print("摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*", ab)))

kw = next((t for t in ps if t.startswith("Keywords")), "")
print("关键词:", kw[:90])

# 正文（Introduction 到 References）
i_ref = next(i for i, t in enumerate(ps) if t == "References")
main = " ".join(ps[i_in:i_ref])
print("正文词数(不含摘要/文献):", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*", main)))

# 图件尺寸与分辨率
for f in ["Fig1_study_design.png", "Fig2_forest_UACR.png", "Fig3_concordance.png", "Fig4_coloc.png"]:
    im = Image.open(f"figures/{f}")
    w, h = im.size
    dpi = im.info.get("dpi", ("?", "?"))
    print(f"  {f}: {w}x{h} px, 标注 {dpi}, 3.5in 宽时 {w/3.5:.0f} dpi")
