# -*- coding: utf-8 -*-
"""核验发布工具包：条目名编码、内容可用性、校验值自洽。"""
import hashlib
import zipfile
from pathlib import Path

PKG = Path("交付包")
kit_zip = PKG / "04_发布工具包.zip"
z = zipfile.ZipFile(kit_zip)
print("条目数:", len(z.namelist()), "| 完整性:", z.testzip() is None)
for n in z.namelist():
    info = z.getinfo(n)
    print(f"  {info.file_size:>9d}B  flag=0x{info.flag_bits:04x}  {n!r}")

# 中文名可读性：解压后比对大小
tmp = Path("_kit_check")
if tmp.exists():
    import shutil
    shutil.rmtree(tmp)
z.extractall(tmp)
print("解压后顶层:", [p.name for p in tmp.iterdir()])

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

sums = (tmp / "04_发布工具包/SHA256SUMS_KIT.txt").read_text(encoding="utf-8").strip().split("\n")
bad = 0
for line in sums:
    h, rel = line.split("  ", 1)
    p = tmp / "04_发布工具包" / rel
    if not p.exists() or sha(p) != h:
        bad += 1
print("清单条数:", len(sums), "| 不符或缺失:", bad)

kz = tmp / "04_发布工具包/03_可溯源资料包.zip"
inner = zipfile.ZipFile(kz)
print("溯源包内前 5 个条目:", inner.namelist()[:5])
print("溯源包条目:", len(inner.namelist()), "| 完好:", inner.testzip() is None)
inner.close()
z.close()

import gc
import shutil
gc.collect()
shutil.rmtree(tmp, ignore_errors=True)
print("临时目录已清理:", not tmp.exists())
