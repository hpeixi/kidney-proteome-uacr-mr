# -*- coding: utf-8 -*-
"""仓库与溯源包同步：清理旧图、纳入最终稿、更新 README、重算校验值。"""
import hashlib
import shutil
import zipfile
from pathlib import Path

ROOT = Path(".")
EN = ROOT / "交付包/01_英文资料包"
ZH = ROOT / "交付包/02_中文资料包"
TR = ROOT / "交付包/03_可溯源资料包"
REPO = ROOT / "repo"

# 1) 图件：删除旧森林图，纳入双判据图
for ext in ("png", "pdf"):
    old = REPO / "figures" / f"Fig2_forest_UACR.{ext}"
    if old.exists():
        old.unlink()
    src = EN / "figures" / f"Fig2_dual_criteria.{ext}"
    if src.exists():
        shutil.copy2(src, REPO / "figures" / src.name)
print("repo/figures:", sorted(p.name for p in (REPO / "figures").glob("*")))

# 2) 最终稿副本
mdir = REPO / "manuscripts"
mdir.mkdir(exist_ok=True)
for src in (EN / "manuscript_en.md", EN / "manuscript_en.docx",
            ZH / "manuscript_zh.md", ZH / "manuscript_zh.docx"):
    if src.exists():
        shutil.copy2(src, mdir / src.name)
stale = REPO / "manuscript_en_before_polish.md"
if stale.exists():
    stale.unlink()
print("repo/manuscripts:", sorted(p.name for p in mdir.glob("*")))

# 3) README 更新
rd = REPO / "README.md"
s = rd.read_text(encoding="utf-8")
s = s.replace(
 "- **Results**: 582 proteins with cis instruments; 12 associated with UACR (FDR < 0.05); 8 colocalized (PP.H4 ≥ 0.8); SERPINA10 replicated, BAG3 opposite direction",
 "- **Results**: 582 proteins with cis instruments; 12 associated with UACR (FDR < 0.05); 8 colocalized (PP.H4 ≥ 0.8); no candidate replicated in general-population plasma; overlap with the eGFR-directed list was no greater than chance (P = 0.47)")
s = s.replace(
 "analysis/   8 Python scripts (instruments, MR, colocalization, replication, figures)",
 "analysis/   8 Python scripts (instruments, MR, colocalization, replication, figures)\ntools/      release, provenance and figure scripts (publish_zenodo.py, publish_github.py, fig2_dual_criteria.py)")
s = s.replace(
 "figures/    4 figures (PNG 300 dpi + PDF)",
 "figures/    4 figures (PNG 300 dpi + PDF); Figure 2 is the three-panel dual-criteria figure\nmanuscripts/ final English and Chinese manuscripts (.md and .docx)")
s = s.replace("Citation and DOI: see `metadata/CITATION.cff` (DOI pending release).",
              "Citation and DOI: see `metadata/CITATION.cff`; concept DOI 10.5281/zenodo.23851408 (always resolves to the latest version). Release steps: `UPLOAD.md`.")
rd.write_text(s, encoding="utf-8")
print("README 更新:", "P = 0.47" in s, "| 双判据说明:", "three-panel dual-criteria" in s)

# 4) 上传脚本进溯源包
for name in ("publish_zenodo.py", "publish_github.py", "docx_build.py", "fig2_dual_criteria.py",
             "polish_en.py", "polish_zh.py", "finalize_provenance.py"):
    src = REPO / "tools" / name
    if src.exists():
        shutil.copy2(src, TR / "scripts" / name)
shutil.copy2(REPO / "UPLOAD.md", TR / "UPLOAD.md")
print("溯源包脚本:", len(list((TR / "scripts").glob("*.py"))))

# 5) 重算 SHA256
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for c in iter(lambda: fh.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

targets = []
for sub in ("results", "scripts", "metadata", "references", "docs"):
    d = TR / sub
    if d.exists():
        targets += sorted(p for p in d.rglob("*") if p.is_file())
targets += sorted((EN / "figures").glob("*"))
targets += sorted((ZH / "figures").glob("*"))
lines = [f"{sha(p)}  {p.relative_to(ROOT).as_posix()}" for p in targets if p.is_file()]
(TR / "SHA256SUMS.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
print("SHA256 条目:", len(lines))

# 6) 重建三包
def pack(folder, label, zpath):
    zp = Path(zpath)
    if zp.exists():
        zp.unlink()
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(label) / f.relative_to(folder))
    z = zipfile.ZipFile(zp)
    bad = [n for n in z.namelist() if "Fig2_forest" in n]
    print(zpath, len(z.namelist()), "条目 | 完好:", z.testzip() is None, "| 残留旧图:", bad or "无")

pack(EN, "01_英文资料包", "交付包/01_英文资料包.zip")
pack(ZH, "02_中文资料包", "交付包/02_中文资料包.zip")
pack(TR, "03_可溯源资料包", "交付包/03_可溯源资料包.zip")

# 7) 全仓检查
hits = [p.as_posix() for p in ROOT.rglob("*") if p.is_file() and "Fig2_forest" in p.name]
print("全仓旧图残留:", hits or "无")
