# -*- coding: utf-8 -*-
"""按审稿人第五节 reposition：可行性示范 + 阴性对照；改英文稿、说明信、中文稿标题。"""
import re
from pathlib import Path

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

NEW_TITLE = ("# Albuminuria-directed cis-pQTL Mendelian randomization: feasibility and a negative "
             "control for proteome-wide screens")

R = [
 (md.splitlines()[0], NEW_TITLE),
 ("Albuminuria indicates injury to the filtration barrier and precedes kidney function loss, yet which proteins act on it remain incompletely characterized. Proteome-wide Mendelian randomization (MR) has used estimated glomerular filtration rate (eGFR) or diagnostic labels as outcomes. We asked which proteins are prioritized for albuminuria rather than eGFR.",
  "Albuminuria indicates injury to the filtration barrier and precedes kidney function loss, yet which proteins act on it remain incompletely characterized. Proteome-wide Mendelian randomization (MR) has used estimated glomerular filtration rate (eGFR) or diagnostic labels as outcomes. Whether albuminuria-directed screening finds proteins that eGFR-directed screening misses has not been tested directly."),
 ("Of 12 UACR-associated proteins, eight colocalized strongly. Independent data existed for seven: three replicated, one inconsistently, one reversed, one was null and one was not evaluable; five had none. These candidates require experimental validation.",
  "An albuminuria-directed cis-pQTL screen is feasible, but no protein replicated in plasma on an independent platform, and the UACR and eGFR lists overlapped no more than chance. eGFR is therefore not a substitute for albuminuria-directed screening; the five proteins that survived missense exclusion are candidates for validation."),
 ("Of the 12 proteins associated with UACR, eight reached the colocalization criterion. Seven could be examined in independent panels: ISLR2, ITIH1 and PCOLCE kept their direction, SERPINA10 only inconsistently, BAG3 reversed, OAF was null, and ANGPTL1 could not be evaluated. Five had no independent data (APOA5, SERPINF2, MCL1, FCGR2A, RSPO3). Cross-classified by instrument robustness (Supplementary Table S16), five of the eight colocalized proteins kept an unchanged direction after missense instruments were excluded, one lost significance, and two rested on a single missense variant and could not be re-estimated. The list is heterogeneous.",
  "An albuminuria-directed cis-pQTL screen proved feasible: 582 proteins were evaluable and twelve were associated with UACR. Its value lies less in the list than in three observations. Of the eight colocalized proteins, five kept their direction after missense instruments were excluded, one lost significance and two could not be re-estimated (Supplementary Table S16). No candidate was replicated in plasma on an independent platform. And an eGFR-directed screen would not have recovered this set."),
 ("The lists overlapped in one protein (ITIH1). With 12 UACR and 30 eGFR hits among 582 evaluable proteins, expected overlap is 0.62, and one is compatible with chance (P = 0.47, Supplementary Table S14). These data therefore do not show distinct protein architectures; they show that a UACR-specific set was not recovered from eGFR.",
  "That negative control is the main result. With 12 UACR and 30 eGFR hits among 582 evaluable proteins, expected overlap is 0.62 and one is compatible with chance (P = 0.47, Supplementary Table S14). We therefore do not claim that the two traits have different protein architectures; we show that a screen built on eGFR does not recover an albuminuria-directed list, which is the practical question a proteome-wide screen faces."),
 ("In this cis-pQTL MR and colocalization analysis, eight of the 12 UACR-associated proteins met the prespecified colocalization criterion. Seven were testable in independent panels: three replicated in direction, one replicated inconsistently, one reversed, one was null and one could not be evaluated; five remain untested. Replication in larger pQTL panels, direction testing for every candidate, and experimental work are needed before any of these proteins is treated as causal.",
  "An albuminuria-directed cis-pQTL screen is feasible on public data, but it produces candidates rather than causal proteins: five survived missense exclusion, none replicated in plasma on an independent platform, and the eGFR list was not a substitute. The negative control, rather than the candidate list, is the transferable result."),
]
fails = []
for a, b in R:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        fails.append(a[:60])
print("未匹配:", fails if fails else "无")
if fails:
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])), "| 新标题:", md.splitlines()[0][:90])

# 说明信同步标题与定位
cl_path = EN / "cover_letter.md"
cl = cl_path.read_text(encoding="utf-8")
old_t = re.search(r'"Prioritizing candidate plasma proteins[^"]*"', cl)
if old_t:
    cl = cl.replace(old_t.group(0), '"' + NEW_TITLE[2:] + '"')
cl = cl.replace("hypothesis-generating original research article",
                "hypothesis-generating original research article that reports a negative control")
cl_path.write_text(cl, encoding="utf-8")
print("说明信标题含 Albuminuria-directed:", "Albuminuria-directed" in cl)

# 中文稿标题
zh_path = ZH / "manuscript_zh.md"
zh = zh_path.read_text(encoding="utf-8")
old_zh = "# 循环血浆蛋白与白蛋白尿：一项顺式 pQTL 孟德尔随机化与共定位研究"
if old_zh in zh:
    zh = zh.replace(old_zh, "# 白蛋白尿导向的顺式 pQTL 孟德尔随机化：可行性与阴性对照研究", 1)
    zh_path.write_text(zh, encoding="utf-8")
print("中文标题已换:", "可行性与阴性对照" in zh)
