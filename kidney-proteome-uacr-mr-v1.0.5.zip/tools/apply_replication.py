# -*- coding: utf-8 -*-
"""把新增 4 个蛋白的复现结果写入稿件正文、表 1、S7，并重建 docx。"""
import re
import zipfile
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
TR = Path("交付包/03_可溯源资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

# ---------- 1) 正文替换 ----------
subs = [
 # 摘要结果句
 ("SERPINA10 replicated in an independent panel, whereas BAG3 changed direction in a larger panel.",
  "SERPINA10, ISLR2, ITIH1 and PCOLCE replicated in the same direction in independent panels; BAG3 changed direction and OAF was null."),
 # 摘要结论
 ("**Conclusion.** Eight proteins met prespecified criteria and are reported as candidates. Independent panels existed for two: one agreed, one contradicted. These candidates require replication and experimental validation before causal inference is drawn.",
  "**Conclusion.** Eight proteins met prespecified criteria. Seven were testable in independent panels: four replicated, one reversed, one was null and one was not evaluable. These candidates require experimental validation before causal inference is drawn."),
 # 结果段
 ("SERPINA10 replicated in the same direction (three cis variants; β = −0.0098, SE 0.0028, P = 4.0×10⁻⁴). BAG3 did not: in UKB-PPP the estimate reversed (405 cis variants; β = −0.032, SE 0.0025, P = 7.2×10⁻³⁶, against +0.051 in the primary panel). ANGPTL1 had no genome-wide significant cis variant in the independent dataset, and five proteins had no independent data at all.",
  "SERPINA10 replicated in the same direction (three cis variants; β = −0.0098, SE 0.0028, P = 4.0×10⁻⁴). BAG3 did not: in UKB-PPP the estimate reversed (405 cis variants; β = −0.032, SE 0.0025, P = 7.2×10⁻³⁶, against +0.051 in the primary panel). Four further panels were retrieved from public repositories: ISLR2 (n = 2,917; β = −0.081, SE 0.019, P = 2.3×10⁻⁵), ITIH1 (β = −0.106, SE 0.036, P = 3.3×10⁻³) and PCOLCE (β = 0.075, SE 0.026, P = 4.2×10⁻³) kept the direction of the primary estimate, although their effect sizes were larger, whereas OAF did not replicate (β = 0.002, SE 0.005, P = 0.69). ANGPTL1 had no genome-wide significant cis variant in its panel, and five proteins (APOA5, SERPINF2, MCL1, FCGR2A, RSPO3) had no independent data."),
 # 讨论首段
 ("Eight proteins met the prespecified criteria, but independent panels existed for only two, and they disagreed.",
  "Eight proteins met the prespecified criteria. Seven could be examined in independent panels: four kept their direction, one reversed, and two did not support the primary estimate."),
 # 结论
 ("In this cis-pQTL MR and colocalization analysis, eight proteins met prespecified criteria and are reported as prioritized candidates for albuminuria. One survived independent testing, one was contradicted, and six remain untested.",
  "In this cis-pQTL MR and colocalization analysis, eight proteins met prespecified criteria and are reported as prioritized candidates for albuminuria. Of the seven testable in independent panels, four replicated in direction, one reversed and two were null or not evaluable; five remain untested."),
 # 方法补一句面板来源
 ("Reverse-direction MR used pruned UACR instruments to estimate effects on BAG3.",
  "Further pQTL panels were retrieved from the GWAS Catalog for ISLR2 (n = 2,917) and for PCOLCE, ITIH1 and OAF (n = 3,506 each). Reverse-direction MR used pruned UACR instruments to estimate effects on BAG3."),
 # 表 1 复现列
 ("| ISLR2 | 1 | −6.4 | −8.9 to −3.8 | 8.8×10⁻⁴ | 0.887 | Not available |",
  "| ISLR2 | 1 | −6.4 | −8.9 to −3.8 | 8.8×10⁻⁴ | 0.887 | Replicated |"),
 ("| ITIH1 | 1 | −1.5 | −2.1 to −0.8 | 1.6×10⁻³ | 0.614 | Not available |",
  "| ITIH1 | 1 | −1.5 | −2.1 to −0.8 | 1.6×10⁻³ | 0.614 | Replicated |"),
 ("| OAF | 2 | −1.6 | −2.3 to −0.8 | 1.3×10⁻² | 0.002 | Not available |",
  "| OAF | 2 | −1.6 | −2.3 to −0.8 | 1.3×10⁻² | 0.002 | Not replicated (null) |"),
 ("| PCOLCE | 1 | +3.7 | +1.6 to +5.9 | 4.6×10⁻² | 0.852 | Not available |",
  "| PCOLCE | 1 | +3.7 | +1.6 to +5.9 | 4.6×10⁻² | 0.852 | Replicated |"),
]
for a, b in subs:
    assert a in md, a[:50]
    md = md.replace(a, b)
md_path.write_text(md, encoding="utf-8")
print("正文与表 1 已更新")

# ---------- 2) S7 补充表 ----------
s7 = TR / "results" / "S7_independent_replication.csv"
s = pd.read_csv(s7)
print("S7 原列:", list(s.columns), "| 原行数", len(s))
new = pd.DataFrame([
    {"gene": "ISLR2", "panel": "GCST90059992", "n_cis_snp": 1, "beta_replication": -0.0813,
     "se_replication": 0.0192, "p_replication": "2.3e-05", "beta_prota": -0.0662, "direction": "replicated"},
    {"gene": "ITIH1", "panel": "GCST90427174", "n_cis_snp": 1, "beta_replication": -0.1060,
     "se_replication": 0.0360, "p_replication": "3.3e-03", "beta_prota": -0.0146, "direction": "replicated"},
    {"gene": "OAF", "panel": "GCST90426688", "n_cis_snp": 1, "beta_replication": 0.0021,
     "se_replication": 0.0052, "p_replication": "6.9e-01", "beta_prota": -0.0158, "direction": "null"},
    {"gene": "PCOLCE", "panel": "GCST90421386", "n_cis_snp": 1, "beta_replication": 0.0746,
     "se_replication": 0.0261, "p_replication": "4.2e-03", "beta_prota": 0.0364, "direction": "replicated"},
])
s = pd.concat([s, new[s.columns]], ignore_index=True)
s.to_csv(s7, index=False, encoding="utf-8-sig")
print("S7 现行数:", len(s))

# ---------- 3) 重建 docx ----------
def build():
    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
        setattr(sec, m, Cm(2.54))
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"; st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    st.paragraph_format.line_spacing = 2.0
    st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)

    def add_runs(p, text):
        for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", text):
            if not seg:
                continue
            if seg.startswith("**") and seg.endswith("**"):
                r = p.add_run(seg[2:-2]); r.bold = True
            elif seg.startswith("^") and seg.endswith("^"):
                r = p.add_run(seg[1:-1]); r.font.superscript = True
            else:
                p.add_run(seg)

    lines = md.split("\n"); i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln or ln == "---":
            i += 1; continue
        if ln.startswith("### "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
            r = p.add_run(ln[4:]); r.bold = True; r.italic = True
        elif ln.startswith("## "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
            r = p.add_run(ln[3:]); r.bold = True
        elif ln.startswith("# "):
            p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
            r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            t = doc.add_table(rows=len(rows), cols=len(rows[0]))
            t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
            for ri, row in enumerate(rows):
                for ci, val in enumerate(row):
                    cp = t.cell(ri, ci).paragraphs[0]
                    cp.paragraph_format.line_spacing = 1.0
                    cp.paragraph_format.space_after = Pt(2)
                    r = cp.add_run(val); r.font.size = Pt(9)
                    if ri == 0:
                        r.bold = True
            continue
        else:
            add_runs(doc.add_paragraph(), ln)
        i += 1

    el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
    sec._sectPr.append(el)
    fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run()
    c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
    c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
    for x in (c1, it, c2):
        run._r.append(x)
    doc.save(EN / "manuscript_en.docx")


build()

# ---------- 4) 核验 + 重打包 ----------
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
print("表行数:", len(d.tables[0].rows), "列:", len(d.tables[0].columns))
for k in ["0.081", "0.106", "0.075", "0.69", "2,917", "3,506", "23853798"]:
    print(f"  含 {k}:", k in txt)

for folder, name in [(EN, "01_英文资料包"), (TR, "03_可溯源资料包")]:
    z = Path("交付包") / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
