# -*- coding: utf-8 -*-
"""最终核验：页数、关键落点、包内条目。"""
import re
import zipfile
from pathlib import Path

import fitz
from docx import Document

EN = Path("交付包/01_英文资料包")
pdf = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace\document-preview-2181150199\preview.pdf")
if pdf.exists():
    d = fitz.open(pdf)
    print("页数:", d.page_count)
    t = "".join(p.get_text() for p in d)
    for k in ["five of which survived", "No candidate was replicated in plasma",
              "PP.H3 0.998", "Cochran", "P = 0.47", "30 proteins"]:
        print(f"  {k}: {k in t}")
else:
    print("PDF 未找到")

doc = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in doc.paragraphs)
cells = [c.text for tb in doc.tables for r in tb.rows for c in r.cells]
print("\n摘要:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*",
                              txt[txt.index("Purpose."):txt.index("Keywords:")])))
print("文献:", len([p for p in doc.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
print("表内状态:", sorted({c for c in cells if any(k in c for k in ["consistent", "conflict", "Null"])}))

for n in ["01_英文资料包", "02_中文资料包", "03_可溯源资料包"]:
    z = Path("交付包") / f"{n}.zip"
    with zipfile.ZipFile(z) as zf:
        print(f"{n}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
