# -*- coding: utf-8 -*-
"""核验 23851408 是否已统一落到全部交付物，并量页数。"""
import re
import zipfile
from pathlib import Path

import fitz
from docx import Document

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
DOI = "10.5281/zenodo.23851408"
OTHERS = ["10.5281/zenodo.23852899", "10.5281/zenodo.23853798", "10.5281/zenodo.23851813"]

files = [EN/"manuscript_en.md", EN/"manuscript_en.docx", EN/"cover_letter.md", EN/"cover_letter.docx",
         EN/"README.md", ZH/"manuscript_zh.md", ZH/"manuscript_zh.docx", ZH/"manuscript_bilingual.md",
         ZH/"manuscript_bilingual.docx", ZH/"README.md", TR/"metadata/CITATION.cff", Path("repo/metadata/CITATION.cff")]

print("== 逐文件核验")
allok = True
for f in files:
    t = "\n".join(x.text for x in Document(f).paragraphs) if f.suffix == ".docx" else f.read_text(encoding="utf-8")
    ok = DOI in t and not any(o in t for o in OTHERS)
    allok &= ok
    print(f"  {'OK ' if ok else 'BAD'} {f.as_posix()}  (含目标DOI={DOI in t})")

print("\n== DOI.txt")
dt = (TR/"metadata"/"DOI.txt").read_text(encoding="utf-8")
print("  首行:", dt.splitlines()[0])
print("  稿件引用行:", [l for l in dt.splitlines() if l.startswith("DOI cited")][0])
print("  v1.0.4 行:", [l for l in dt.splitlines() if l.startswith("v1.0.4")][0])

print("\n== 压缩包")
for name in ["01_英文资料包", "02_中文资料包", "03_可溯源资料包"]:
    z = OUT/f"{name}.zip"
    with zipfile.ZipFile(z) as zf:
        members = [m for m in zf.namelist() if m.endswith((".md", ".cff", ".txt"))]
        hits = sum(1 for m in members if DOI.encode() in zf.read(m))
        print(f"  {name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}, 含目标DOI的文件 {hits} 个")

print("\n== 稿件")
d = Document(EN/"manuscript_en.docx")
txt = "\n".join(x.text for x in d.paragraphs)
print("  文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", txt[txt.index("Purpose."):txt.index("Keywords:")])))
print("  ORCID 一作/通讯:", "0009-0004-5436-7788" in txt, "/", "0009-0006-5762-8650" in txt)

pdf = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace\document-preview-238555177\preview.pdf")
if pdf.exists():
    doc = fitz.open(pdf)
    print("  渲染页数:", doc.page_count, "| 该 PDF 中含目标 DOI:", DOI in "".join(p.get_text() for p in doc))
print("\n总判定:", "全部通过" if allok else "有文件不一致")
