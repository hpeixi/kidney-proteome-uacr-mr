# -*- coding: utf-8 -*-
"""压缩版面回到 12 页内：精简三处冗句、收紧标题间距；并核对表内判定文字。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

subs = [
 ("The study contributes three things: a cis-pQTL MR screen with albuminuria as the primary outcome and eGFR as a comparator in the same instrument set (Methods; Results); an approximate colocalization analysis that separates shared from distinct signals (Methods; Results; Figure 4); and an explicit test of one candidate in larger independent data, which failed and is reported as such (Results; Discussion).",
  "We therefore report a cis-pQTL MR screen with albuminuria as the primary outcome and eGFR as a comparator, an approximate colocalization analysis, and an explicit test of one candidate in larger independent data, which failed."),
 ("The replication panels for ISLR2, ITIH1, PCOLCE and OAF are SomaScan-based, and those for ITIH1, PCOLCE and OAF are cerebrospinal fluid rather than plasma; agreement between them and the primary panel therefore cannot exclude aptamer or biofluid effects, and only BAG3 was tested on a different platform (Olink).",
  "The replication panels are SomaScan-based, and three of the four are cerebrospinal fluid rather than plasma, so agreement cannot exclude aptamer or biofluid effects; only BAG3 was tested on another platform (Olink)."),
 ("Power is derived from the same standard error that determines significance, so this comparison is close to tautological; the proteins whose effects sit nearest their detectable limit (FCGR2A +0.5%, SERPINA10 −1.2%, ITIH1 −1.5%) are the least secure.",
  "Power and significance derive from the same standard error, so this comparison is near-tautological; FCGR2A (+0.5%), SERPINA10 (−1.2%) and ITIH1 (−1.5%) sit nearest their limits and are the least secure."),
]
for a, b in subs:
    assert a in md, a[:50]
    md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(3)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
cells = [c.text for t in d.tables for r in t.rows for c in r.cells]
txt = "\n".join(p.text for p in d.paragraphs)
print("表内 Inconsistently replicated 单元格:", sum(1 for c in cells if c.strip() == "Inconsistently replicated"))
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("摘要:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
