# -*- coding: utf-8 -*-
"""按第四轮意见改稿：证据分层(S16)、Table 1 措辞、摘要补重叠检验、OAF 张力、引文 [4]、面板文献 [17][18]。"""
import re
from pathlib import Path

import pandas as pd

EN = Path("交付包/01_英文资料包")
RES = Path("交付包/03_可溯源资料包/results")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

R = [
 # ---- Table 1 状态重写（M2/M4/M5）----
 ("| ISLR2 | 1 | −6.4 | −8.9 to −3.8 | 8.8×10⁻⁴ | 0.887 | Replicated |",
  "| ISLR2 | 1 | −6.4 | −8.9 to −3.8 | 8.8×10⁻⁴ | 0.887 | Direction-consistent (serum, SomaScan) [17] |"),
 ("| ITIH1 | 1 | −1.5 | −2.1 to −0.8 | 1.6×10⁻³ | 0.614 | Replicated |",
  "| ITIH1 | 1 | −1.5 | −2.1 to −0.8 | 1.6×10⁻³ | 0.614 | Direction-consistent, lowest confidence (CSF) [18] |"),
 ("| OAF | 2 | −1.6 | −2.3 to −0.8 | 1.3×10⁻² | 0.002 | Not replicated (null) |",
  "| OAF | 2 | −1.6 | −2.3 to −0.8 | 1.3×10⁻² | 0.002 | Null (CSF, SomaScan) [18] |"),
 ("| SERPINA10 | 1 | −1.2 | −1.9 to −0.6 | 1.7×10⁻² | 0.882 | Inconsistently replicated |",
  "| SERPINA10 | 1 | −1.2 | −1.9 to −0.6 | 1.7×10⁻² | 0.882 | Direction conflict (CSF) [18] |"),
 ("| PCOLCE | 1 | +3.7 | +1.6 to +5.9 | 4.6×10⁻² | 0.852 | Replicated |",
  "| PCOLCE | 1 | +3.7 | +1.6 to +5.9 | 4.6×10⁻² | 0.852 | Direction-consistent (CSF, SomaScan) [18] |"),
 # ---- 面板来源与“无血浆独立复制”（M2/MINOR 5）----
 ("Further panels were taken from the GWAS Catalog: ISLR2 (serum, SomaScan, 2,917 European-ancestry participants) and PCOLCE, ITIH1 and OAF (cerebrospinal fluid, SomaScan, 3,506 each). Comparison with UKB-PPP [5] therefore contrasts platforms, and for three proteins also biofluids (Supplementary Table S13).",
  "Four further panels came from the GWAS Catalog: a serum SomaScan panel assembled in a study of neurological disease [17] (2,917 European-ancestry participants) for ISLR2, and a cerebrospinal fluid SomaScan panel from a neurological cohort [18] (3,506 participants) for PCOLCE, ITIH1 and OAF. Comparison with UKB-PPP [5] therefore contrasts platforms, and for three proteins also biofluids (Supplementary Table S13). No candidate was replicated in plasma on an independent platform."),
 # ---- 证据分层（M1）----
 ("Five had no independent data (APOA5, SERPINF2, MCL1, FCGR2A, RSPO3).",
  "Five had no independent data (APOA5, SERPINF2, MCL1, FCGR2A, RSPO3). Cross-classified by instrument robustness (Supplementary Table S16), five of the eight colocalized proteins kept an unchanged direction after missense instruments were excluded, one lost significance, and two rested on a single missense variant and could not be re-estimated."),
 # ---- OAF 张力（M3）----
 ("MCL1 is the weakest link in the list: it passed the colocalization threshold, yet its signal may reflect pleiotropic variants rather than a variant acting through MCL1 itself, and we would not defend it as a candidate on present evidence.",
  "MCL1 is the weakest link in the list: it passed the colocalization threshold, yet its signal may reflect pleiotropic variants rather than a variant acting through MCL1 itself, and we would not defend it as a candidate on present evidence. The single protein that survived the multi-instrument analysis, OAF, is also the clearest case of distinct causal variants (PP.H3 0.998) and showed no independent effect; a dataset of this kind therefore supports neither direction nor mechanism for it."),
 # ---- SERPINA10 异质性（M5）----
 ("SERPINA10 is represented by two aptamer datasets; the estimate in Table 1 uses the single-instrument dataset, whereas the four-instrument dataset gave β = 0.005 (P = 0.28), so the multi-instrument estimate does not support the single-instrument result.",
  "SERPINA10 is represented by two aptamer datasets; the estimate in Table 1 uses the single-instrument dataset, whereas the multi-instrument dataset gave β = 0.005 (P = 0.28) with one instrument pointing the other way (per-instrument Wald ratios −0.015 to +0.013; IVW over four instruments β = −0.007, Cochran's Q = 14.2, P = 0.007), so the two datasets do not agree in direction."),
 # ---- 引文 [4]（M8）----
 ("MR-Egger, weighted median and MR-PRESSO [12,13] all require more than one variant, so none could be applied",
  "MR-Egger, weighted median and MR-PRESSO [12,13] all require more than one variant, so none could be applied; the larger deCODE panel [4] would have allowed them but was not used for the primary analysis"),
 # ---- 窗口口径（MINOR 4）----
 ("and posterior probabilities for five hypotheses were computed assuming a single causal variant [11] (priors 1×10⁻⁴ per trait, 1×10⁻⁵ for a shared variant).",
  "and posterior probabilities for five hypotheses were computed assuming a single causal variant [11] (priors 1×10⁻⁴ per trait, 1×10⁻⁵ for a shared variant). This 100 kb window is narrower than the 500 kb instrument window and need not cover the whole gene."),
 # ---- 样本重叠 / winner's curse（MINOR 9）----
 ("Mapping was name-based, with four problems in an audit of fifteen.",
  "Instruments and their effects were estimated in the same panel, so winner's curse is likely and the effect sizes are probably inflated; UACR and eGFR come from the same CKDGen programme, and sample overlap between them cannot be excluded. Mapping was name-based, with four problems in an audit of fifteen."),
 # ---- 语言（MINOR 10）----
 ("Observational studies are hard to read because protein concentrations themselves fall as filtration declines",
  "Observational studies are difficult to interpret because protein concentrations themselves fall as filtration declines"),
 # ---- 重复的 We therefore（MINOR 3）----
 ("We therefore report a cis-pQTL MR screen with albuminuria as the primary outcome and eGFR as a comparator, an approximate colocalization analysis, and an explicit test of one candidate in larger independent data, which failed.",
  "This paper reports a cis-pQTL MR screen with albuminuria as the primary outcome and eGFR as a comparator, an approximate colocalization analysis, and an explicit test of one candidate in larger independent data, which failed."),
 # ---- 摘要：eGFR 计数与 ANGPTL1、重叠检验（M7 / MINOR 1、2）----
 ("Thirty-one proteins were associated with eGFR; only ITIH1 reached significance for both, in opposite directions.",
  "Thirty proteins were associated with eGFR; only ITIH1 reached significance for both, in opposite directions."),
 ("ISLR2, ITIH1 and PCOLCE were direction-consistent in independent SomaScan panels, SERPINA10 inconsistently so, BAG3 reversed and OAF was null.",
  "ISLR2 and PCOLCE were direction-consistent in independent SomaScan panels, SERPINA10 inconsistently, ANGPTL1 was not evaluable, BAG3 reversed and OAF was null; the UACR and eGFR hit lists overlapped no more than expected by chance (P = 0.47)."),
 # ---- 参考文献补两条 ----
 ("16. Hemani G, Tilling K, Davey Smith G. Orienting the causal relationship between imprecisely measured traits using GWAS summary data. PLoS Genet. 2017;13(11):e1007081.",
  "16. Hemani G, Tilling K, Davey Smith G. Orienting the causal relationship between imprecisely measured traits using GWAS summary data. PLoS Genet. 2017;13(11):e1007081.\n17. Png G, Barysenka A, Repetto L, et al. Mapping the serum proteome to neurological diseases using whole genome sequencing. Nat Commun. 2021;12(1):7042.\n18. Western D, Timsina J, Wang L, et al. Proteogenomic analysis of human cerebrospinal fluid identifies neurologically relevant regulation and informs biomarkers. Nat Genet. 2024;56(12):2672-2684."),
]
fails = []
for a, b in R:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        fails.append(a[:60])
print("未匹配:", fails if fails else "无")
if fails:
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
start = md.index("**Purpose.**"); end = md.index("**Keywords:**")
print("摘要(含小标题):", len(re.findall(pat, md[start:end])),
      "| 不含:", len(re.findall(pat, re.sub(r"\*\*(Purpose|Methods|Results|Conclusion)\.\*\*", "", md[start:end]))))
