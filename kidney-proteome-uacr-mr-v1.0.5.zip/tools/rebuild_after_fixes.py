# -*- coding: utf-8 -*-
"""摘要压回 250 词内，重建稿件与说明信 docx，重打三个包并逐项核验。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

subs = [
 ("Of the 12 UACR-associated proteins, eight showed strong colocalization.",
  "Of the 12 UACR-associated proteins, eight colocalized strongly."),
 ("These candidates require experimental validation before causal inference. These",
  "These candidates require experimental validation. These"),
]
for a, b in subs:
    if a in md:
        md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")


def build_md_to_docx(text, path, footer_page=True):
    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
        setattr(sec, m, Cm(2.54))
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"; st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    st.paragraph_format.line_spacing = 2.0
    st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)

    def add_runs(p, s):
        for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
            if not seg:
                continue
            if seg.startswith("**") and seg.endswith("**"):
                r = p.add_run(seg[2:-2]); r.bold = True
            elif seg.startswith("^") and seg.endswith("^"):
                r = p.add_run(seg[1:-1]); r.font.superscript = True
            else:
                p.add_run(seg)

    lines = text.split("\n"); i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln or ln == "---":
            i += 1; continue
        if ln.startswith("### "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
            r = p.add_run(ln[4:]); r.bold = True; r.italic = True
        elif ln.startswith("## "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
            r = p.add_run(ln[3:]); r.bold = True
        elif ln.startswith("# "):
            p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
            r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            t = doc.add_table(rows=len(rows), cols=len(rows[0]))
            t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
            for ri, row in enumerate(rows):
                for ci, val in enumerate(row):
                    cp = t.cell(ri, ci).paragraphs[0]
                    cp.paragraph_format.line_spacing = 1.0
                    cp.paragraph_format.space_after = Pt(2)
                    r = cp.add_run(val); r.font.size = Pt(9)
                    if ri == 0:
                        r.bold = True
            continue
        else:
            add_runs(doc.add_paragraph(), ln)
        i += 1

    if footer_page:
        el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
        sec._sectPr.append(el)
        fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = fp.add_run()
        c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
        it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
        c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
        for x in (c1, it, c2):
            run._r.append(x)
    doc.save(path)


build_md_to_docx(md, EN / "manuscript_en.docx")

# 说明信重建（DOI 已换）
cl = (EN / "cover_letter.md").read_text(encoding="utf-8")
cld = Document()
s2 = cld.sections[0]
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(s2, m, Cm(2.54))
st2 = cld.styles["Normal"]; st2.font.name = "Times New Roman"; st2.font.size = Pt(12)
st2.paragraph_format.line_spacing = 1.5; st2.paragraph_format.space_after = Pt(6)
for ln in cl.split("\n"):
    if ln.startswith("# "):
        p = cld.add_paragraph(); r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
        p.paragraph_format.space_after = Pt(12)
    elif ln.strip():
        cld.add_paragraph().add_run(ln.strip())
cld.save(EN / "cover_letter.docx")

# 核验
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("引用标注:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)))
print("文献条数:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
print("含 Hemani 2017:", "Hemani G" in txt, "| 含 [16]:", "[16]" in txt)
print("Concept DOI:", "23851408" in txt, "| 旧 DOI 残留:", "23853798" in txt)
print("表:", len(d.tables), "行", len(d.tables[0].rows), "列", len(d.tables[0].columns))
print("em dash:", txt.count("—"), "| Funding:", [l for l in txt.splitlines() if l.startswith("Funding")][0])

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
