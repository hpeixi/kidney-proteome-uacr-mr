# -*- coding: utf-8 -*-
"""中文表符号统一 + 溯源清单 + 元数据版本 + 三包重建。"""
import hashlib
import importlib.metadata as md_ver
import json
import platform
import sys
import zipfile
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path("repo/tools").resolve()))
from docx_build import build  # noqa: E402

ROOT = Path(".")
EN = ROOT / "交付包/01_英文资料包"
ZH = ROOT / "交付包/02_中文资料包"
TR = ROOT / "交付包/03_可溯源资料包"
REPO = ROOT / "repo"

# ---------- 1. 中文表排版符号 ----------
for name in ("manuscript_zh.md", "manuscript_bilingual.md"):
    f = ZH / name
    s = f.read_text(encoding="utf-8")
    lines = s.split("\n")
    out = []
    for ln in lines:
        if ln.startswith("| ") and ln.count("|") == 10 and "×10" in ln:
            c = [x.strip() for x in ln.strip().strip("|").split("|")]
            c[2] = c[2].replace("-", "−")
            c[3] = c[3].replace("-", "−").replace(" to ", " 至 ")
            ln = "| " + " | ".join(c) + " |"
        out.append(ln)
    s = "\n".join(out)
    f.write_text(s, encoding="utf-8")
    build(s, ZH / name.replace(".md", ".docx"))
print("中文表符号已统一")

# ---------- 2. 环境版本 ----------
def ver(pkg):
    try:
        return md_ver.version(pkg)
    except Exception:
        return "n/a"

env = {
    "python": platform.python_version(),
    "platform": platform.platform(),
    "numpy": ver("numpy"), "pandas": ver("pandas"), "scipy": ver("scipy"),
    "matplotlib": ver("matplotlib"), "python-docx": ver("python-docx"),
}
print(env)

# ---------- 3. SHA256 清单 ----------
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()

targets = []
for sub in ("results", "scripts", "metadata", "references", "docs"):
    d = TR / sub
    if d.exists():
        targets += sorted(p for p in d.rglob("*") if p.is_file())
targets += sorted(p for p in (EN / "figures").glob("*") if p.is_file())
targets += sorted(p for p in (ZH / "figures").glob("*") if p.is_file())

lines = []
for p in targets:
    rel = p.relative_to(ROOT).as_posix()
    lines.append(f"{sha(p)}  {rel}")
sums = TR / "SHA256SUMS.txt"
sums.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("SHA256 条目:", len(lines))

# ---------- 4. PROVENANCE ----------
prov = f"""# 复现与溯源说明（PROVENANCE）

生成日期：{date.today().isoformat()}
稿件：Albuminuria-directed cis-pQTL Mendelian randomization: feasibility and a negative control for proteome-wide screens

## 1. 数据来源与版本

| 角色 | 数据集 | 来源 | 规模 |
|---|---|---|---|
| 暴露 | Sun 2018 SomaScan（prot-a） | OpenGWAS | 3,282 适配体，n = 3,301 |
| 主要结局 | CKDGen UACR，欧洲裔（Teumer 2019） | CKDGen / GWAS Catalog | 564,257 |
| 对照结局 | CKDGen eGFR，欧洲裔（Wuttke 2019） | CKDGen | 1,046,070 |
| 复制（血清） | GCST90059992（Png 2021） | GWAS Catalog | 2,917 |
| 复制（CSF） | GCST90427174 / GCST90421386 / GCST90426688（Western 2024） | GWAS Catalog | 3,506 |
| 复制（血浆 Olink） | GCST90468416（UKB-PPP，Sun 2023） | GWAS Catalog | 47,745 |
| 复制（SERPINA10） | ebi-a-GCST90019385 | GWAS Catalog | 10,708 |

坐标系统一为 GRCh37，顺式窗口为编码基因 TSS ±500 kb；共定位窗口 100 kb。
效应量为 expm1(β)×100，即对数尺度 UACR 的百分比变化；eGFR 保留对数单位。

## 2. 软件环境

- Python {env['python']}（{env['platform']}）
- numpy {env['numpy']}，pandas {env['pandas']}，scipy {env['scipy']}
- matplotlib {env['matplotlib']}（图件 300 dpi）
- python-docx {env['python-docx']}（稿件排版）

## 3. 复现步骤

1. `python scripts/inventory_pqtl.py`：盘点暴露面板并筛选全基因组显著 pQTL。
2. `python scripts/round5.py`：顺式限定、Wald/IVW 估计、BH 校正，输出 `results/cis_mr_results.csv`。
3. `python scripts/round6.py`：近似贝叶斯因子共定位，输出 `results/coloc_final.csv`。
4. `python scripts/steiger2.py`：方向性检验，输出 Steiger 结果表。
5. `python scripts/m1_exclude_missense.py`：错义变异注释与排除后复算。
6. `python scripts/fig2_dual_criteria.py`：Figure 2 三面板（共定位、效应量、双判据矩阵）。

全流程为确定性计算，不设随机种子；输入文件校验值见 `SHA256SUMS.txt`。

## 4. 已知限制（与正文一致）

- 共定位假定单一因果变异，窗口 100 kb，未使用 LD 矩阵，PP 为近似值。
- 74% 可评估蛋白仅有一个工具变量，无法使用 MR-Egger/加权中位数/MR-PRESSO。
- 复制面板以 SomaScan 为主，三套为 CSF，人群与体液与主分析不同。
- 重叠检验效能极低：至少需 3 个重叠蛋白方达 P < 0.05（P(X≥3) = 0.020）。
"""
(TR / "PROVENANCE.md").write_text(prov, encoding="utf-8")
(REPO / "PROVENANCE.md").write_text(prov, encoding="utf-8")
print("PROVENANCE 写入")

# ---------- 5. 元数据版本 ----------
TITLE = ("Albuminuria-directed cis-pQTL Mendelian randomization: feasibility and a negative control "
         "for proteome-wide screens")
cit = (REPO / "metadata/CITATION.cff")
if cit.exists():
    s = cit.read_text(encoding="utf-8")
    s = s.replace('version: 1.0.3', 'version: 1.0.4').replace('date-released: 2026-11-01', f'date-released: {date.today().isoformat()}')
    old_title = s.split("title: ")[1].split("\n")[0].strip().strip('"')
    s = s.replace(old_title, TITLE)
    cit.write_text(s, encoding="utf-8")
    print("CITATION 更新:", TITLE[:50])

zj = REPO / ".zenodo.json"
if zj.exists():
    d = json.loads(zj.read_text(encoding="utf-8"))
    d["title"] = TITLE + " (analysis code and derived tables)"
    d["version"] = "1.0.4"
    d["publication_date"] = date.today().isoformat()
    zj.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    print("zenodo.json 更新:", d["version"])

DOI_TXT = REPO / "metadata/DOI.txt"
DOI_TXT.write_text("""DOIS
概念 DOI（引用本文时使用，始终指向最新版本）：10.5281/zenodo.23851408
已发布版本 DOI（历史记录）：
  v1.0.0  10.5281/zenodo.23851409
  v1.0.1  10.5281/zenodo.23851583
  v1.0.2  10.5281/zenodo.23851813
  v1.0.3  10.5281/zenodo.23852899
  v1.0.4  本次上传后由 Zenodo 返回，请在上传成功后补记于此行
待办：v1.0.4 上传成功后，用返回的版本 DOI 替换本行占位说明。
""", encoding="utf-8")
print("DOI.txt 写入（v1.0.4 待上传后补记）")

# ---------- 6. 三包重建 ----------
def pack(folder, label, zpath):
    zp = Path(zpath)
    if zp.exists():
        zp.unlink()
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(label) / f.relative_to(folder))
    z = zipfile.ZipFile(zp)
    print(zpath, len(z.namelist()), "条目 | 完好:", z.testzip() is None)

pack(EN, "01_英文资料包", "交付包/01_英文资料包.zip")
pack(ZH, "02_中文资料包", "交付包/02_中文资料包.zip")
pack(TR, "03_可溯源资料包", "交付包/03_可溯源资料包.zip")
