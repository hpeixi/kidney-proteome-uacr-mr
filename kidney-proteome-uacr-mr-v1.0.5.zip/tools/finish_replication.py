# -*- coding: utf-8 -*-
"""补齐 S7 四行（含 status 列），由更新后的 md 重建 docx，核验并重打 zip。"""
import re
import zipfile
from pathlib import Path

import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
TR = Path("交付包/03_可溯源资料包")
md = (EN / "manuscript_en.md").read_text(encoding="utf-8")

# ---------- S7 ----------
s7 = TR / "results" / "S7_independent_replication.csv"
s = pd.read_csv(s7)
add = pd.DataFrame([
    {"gene": "ISLR2", "panel": "GCST90059992", "n_cis_snp": 1, "beta_replication": -0.081337,
     "se_replication": 0.019229, "p_replication": 2.34e-05, "beta_prota": -0.066180, "direction": "一致", "status": "已完成（方向一致）"},
    {"gene": "ITIH1", "panel": "GCST90427174", "n_cis_snp": 1, "beta_replication": -0.105950,
     "se_replication": 0.036015, "p_replication": 3.26e-03, "beta_prota": -0.014630, "direction": "一致", "status": "已完成（方向一致）"},
    {"gene": "OAF", "panel": "GCST90426688", "n_cis_snp": 1, "beta_replication": 0.002051,
     "se_replication": 0.005156, "p_replication": 6.91e-01, "beta_prota": -0.015760, "direction": "相反", "status": "已完成（无效应）"},
    {"gene": "PCOLCE", "panel": "GCST90421386", "n_cis_snp": 1, "beta_replication": 0.074604,
     "se_replication": 0.026053, "p_replication": 4.19e-03, "beta_prota": 0.036380, "direction": "一致", "status": "已完成（方向一致）"},
])
s = pd.concat([s, add[s.columns]], ignore_index=True)
s.to_csv(s7, index=False, encoding="utf-8-sig")
print("S7 行数:", len(s), "| 基因:", ", ".join(s.gene))

# ---------- docx ----------
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, text):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", text):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

# ---------- 核验 ----------
txt = "\n".join(p.text for p in Document(EN / "manuscript_en.docx").paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("文献:", len([p for p in Document(EN / "manuscript_en.docx").paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
print("表格:", len(Document(EN / "manuscript_en.docx").tables), "行", len(Document(EN / "manuscript_en.docx").tables[0].rows))
for k in ["−0.081", "−0.106", "0.075", "0.69", "2,917", "3,506", "23853798", "Replicated"]:
    print(f"  {k}: {k in txt}")

for folder, name in [(EN, "01_英文资料包"), (TR, "03_可溯源资料包")]:
    z = Path("交付包") / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
