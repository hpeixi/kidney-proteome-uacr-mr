# -*- coding: utf-8 -*-
"""落实 M1（错义变异敏感性）与 M7（unknown 措辞）：加工人表 S11/S12、改稿、重建 docx、重打包。"""
import re
import zipfile
from pathlib import Path

import openpyxl
import pandas as pd
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
RES = TR / "results"

s11 = pd.read_csv(RES / "S11_missense_check.csv")
s12 = pd.read_csv(RES / "S12_missense_excluded_mr.csv")
print("S11:", len(s11), "行 | S12:", len(s12), "行")

# ---------- 工作簿加 S11、S12 ----------
def rebuild_book(src, dst):
    wb = openpyxl.load_workbook(src)
    for name, df in [("S11_Missense_check", s11), ("S12_Missense_excluded", s12)]:
        if name in wb.sheetnames:
            del wb[name]
        ws = wb.create_sheet(name)
        ws.append(list(df.columns))
        for _, row in df.iterrows():
            ws.append([None if pd.isna(v) else v for v in row.values])
    wb.save(dst)
    wb.close()

en_old = EN / "supplementary" / "Table_S1_S10.xlsx"
en_new = EN / "supplementary" / "Table_S1_S12.xlsx"
rebuild_book(en_old, en_new)
zh_old = ZH / "supplementary" / "投稿材料_补充表_S1_S10.xlsx"
zh_new = ZH / "supplementary" / "投稿材料_补充表_S1_S12.xlsx"
rebuild_book(zh_old, zh_new)
en_old.unlink(); zh_old.unlink()
wb = openpyxl.load_workbook(en_new, read_only=True)
print("工作表:", wb.sheetnames)
wb.close()

# ---------- 改稿 ----------
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

subs = [
 # M7 措辞
 ("yet which proteins act on it is unknown.",
  "yet which proteins act on it remain incompletely characterized."),
 # Methods：错义变异敏感性
 ("A manual audit of fifteen randomly chosen mappings found three paralog assignments and one unmapped protein, none of them in the prioritized set.",
  "A manual audit of fifteen randomly chosen mappings found three paralog assignments and one unmapped protein, none of them in the prioritized set. Because SomaScan aptamers can bind differently when a coding variant alters the epitope, every instrument was annotated with Ensembl VEP (GRCh38); 7 of the 19 instruments used here were missense variants."),
 # Results：剔除错义后的重算
 ("With 57 pruned UACR instruments, reverse-direction MR associated higher UACR with lower BAG3 (β = −0.26, SE 0.054, P = 1.3×10⁻⁶).",
  "With 57 pruned UACR instruments, reverse-direction MR associated higher UACR with lower BAG3 (β = −0.26, SE 0.054, P = 1.3×10⁻⁶). Excluding the seven missense instruments (Supplementary Table S11) left 8 of the 12 proteins estimable (Supplementary Table S12): six kept P < 0.05 with an unchanged direction (ISLR2, APOA5, OAF, PCOLCE, RSPO3, ANGPTL1), FCGR2A moved to P = 0.44 and SERPINA10 to P = 0.15, and four (ITIH1, MCL1, SERPINF2, BAG3) rested on a single missense variant and could not be re-estimated."),
 # Limitations：单错义变异
 ("Three further constraints apply.",
  "Four of the twelve candidates rest on a single missense variant, so their estimates cannot be separated from an epitope effect on aptamer binding. Three further constraints apply."),
 # 补充材料清单
 ("S10 all 31 proteins associated with eGFR. All tables are provided in a single workbook.",
  "S10 all 31 proteins associated with eGFR; S11 variant consequences of the 19 instruments; S12 estimates after excluding missense instruments. All tables are provided in a single workbook."),
]
fails = []
for a, b in subs:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        fails.append(a[:60])
if fails:
    print("未匹配:", fails)
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

# README 文件名
for p in [EN / "README.md", ZH / "README.md"]:
    t = p.read_text(encoding="utf-8")
    t = t.replace("Table_S1_S10.xlsx", "Table_S1_S12.xlsx").replace("投稿材料_补充表_S1_S10.xlsx", "投稿材料_补充表_S1_S12.xlsx")
    t = t.replace("S1–S10", "S1–S12").replace("S1-S10", "S1-S12")
    p.write_text(t, encoding="utf-8")

# ---------- 重建 docx ----------
doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

# ---------- 核验 ----------
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("\n摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)), "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
for k in ["7 of the 19 instruments", "Supplementary Table S11", "Supplementary Table S12", "could not be re-estimated", "incompletely characterized"]:
    print(f"  {k}: {k in txt}")

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
