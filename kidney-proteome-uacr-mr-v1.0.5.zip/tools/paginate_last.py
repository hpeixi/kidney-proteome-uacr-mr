# -*- coding: utf-8 -*-
"""定向精简约 90 词，使正文回到 12 页；重建 docx 与 01 包。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

subs = [
 ("S1–S16 cover instruments, cis-MR estimates, colocalization, candidates, power, mapping, replication, panel coverage, data sources, eGFR hits, missense checks, exclusion estimates, panel details, overlap test, eGFR power and evidence tiers, and are provided in one workbook; the STROBE-MR checklist is supplied separately.",
  "S1–S16 (instruments through evidence tiers) are provided in one workbook; the STROBE-MR checklist is supplied separately."),
 ("The list is heterogeneous, and more than one route appears able to raise albuminuria.",
  "The list is heterogeneous."),
 ("The two traits are not interchangeable: eGFR measures filtration capacity, albuminuria measures the integrity of the barrier.",
  "The two are not interchangeable: eGFR measures filtration capacity, albuminuria barrier integrity."),
 ("Thirty-one aptamer datasets, representing 30 proteins (CST6 was measured twice), were associated with eGFR; estimates and conditional power are given in Supplementary Tables S10 and S15.",
  "Thirty-one aptamer datasets (30 proteins; CST6 measured twice) were associated with eGFR; estimates and power are in Supplementary Tables S10 and S15."),
 ("A manual audit of fifteen randomly chosen mappings found three paralog assignments and one unmapped protein, none of them in the prioritized set.",
  "An audit of fifteen mappings found three paralog assignments and one unmapped protein, none prioritized."),
 ("Colocalization is approximate: a single causal variant was assumed and a 100 kb window used. coloc.abf needs no LD matrix, so the limitation is the single-variant assumption and the window, not the absence of LD, and PP.H4 ≥ 0.8 indicates a shared signal under a simplified model rather than a shared causal variant.",
  "Colocalization is approximate: one causal variant was assumed and a 100 kb window used. coloc.abf needs no LD matrix, so the limitation is the single-variant assumption and the window; PP.H4 ≥ 0.8 indicates a shared signal under a simplified model, not a shared causal variant."),
 ("Excluding the seven missense instruments (Supplementary Table S11) left 8 of the 12 proteins estimable (Supplementary Table S12): six kept P < 0.05 with an unchanged direction (ISLR2, APOA5, OAF, PCOLCE, RSPO3, ANGPTL1), FCGR2A moved to P = 0.44 and SERPINA10 to P = 0.15, and four (ITIH1, MCL1, SERPINF2, BAG3) rested on a single missense variant and could not be re-estimated.",
  "Excluding the seven missense instruments (S11) left 8 of 12 estimable (S12): six kept P < 0.05 with unchanged direction (ISLR2, APOA5, OAF, PCOLCE, RSPO3, ANGPTL1); FCGR2A moved to P = 0.44 and SERPINA10 to P = 0.15; four (ITIH1, MCL1, SERPINF2, BAG3) rested on a single missense variant and could not be re-estimated."),
]
miss = []
for a, b in subs:
    if a in md:
        md = md.replace(a, b, 1)
    else:
        miss.append(a[:40])
print("未匹配:", miss if miss else "无")
if miss:
    raise SystemExit(1)
md_path.write_text(md, encoding="utf-8")

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val); r.font.size = Pt(7.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)))

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
