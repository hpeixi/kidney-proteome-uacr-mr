# -*- coding: utf-8 -*-
"""压回 12 页：上下边距 2.2 cm + 约 45 词去冗；重建 docx 与 01 包。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"

subs = [
 ("An additional dataset for SERPINA10 gave β = −0.0098 (SE 0.0028, P = 4.0×10⁻⁴) in the direction of the primary estimate, but its four-instrument dataset gave β = 0.005 (P = 0.28) with one instrument pointing the other way and significant heterogeneity (Cochran's Q = 14.2, P = 0.007); the two datasets therefore conflict.",
  "An additional SERPINA10 dataset gave β = −0.0098 (SE 0.0028, P = 4.0×10⁻⁴) in the same direction, but its four-instrument dataset gave β = 0.005 (P = 0.28) with one instrument reversed and significant heterogeneity (Q = 14.2, P = 0.007); the datasets conflict."),
 ("The replication panels are SomaScan-based, come from neurological cohorts rather than general populations, and three of the four are cerebrospinal fluid rather than plasma, so agreement cannot exclude aptamer, biofluid or population effects; only BAG3 was tested in plasma on another platform (Olink), and no candidate was replicated in plasma from a general population.",
  "The replication panels are SomaScan-based, come from neurological cohorts, and three of four are cerebrospinal fluid, so agreement cannot exclude aptamer, biofluid or population effects; only BAG3 was tested in plasma on another platform, and no candidate replicated in plasma from a general population."),
 ("Power was computed per protein from its own standard error; the median detectable change was 3.6% in UACR with Bonferroni alpha and 2.1% at FDR 0.05. These are medians, not a threshold, and each protein's value is tabulated in Supplementary Table S5.",
  "Power was computed per protein from its own standard error; median detectable change was 3.6% in UACR (Bonferroni alpha) and 2.1% (FDR 0.05), tabulated per protein in Supplementary Table S5."),
 ("Instruments and their effects were estimated in the same panel, so winner's curse is likely and the effect sizes are probably inflated; UACR and eGFR come from the same CKDGen programme, and sample overlap between them cannot be excluded.",
  "Instruments and effects came from the same panel, so winner's curse is likely and effect sizes are probably inflated; UACR and eGFR come from the same CKDGen programme, and sample overlap cannot be excluded."),
]
for a, b in subs:
    assert a in md, a[:40]
    md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])))

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
sec.top_margin = sec.bottom_margin = Cm(2.2)
sec.left_margin = sec.right_margin = Cm(2.54)
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val); r.font.size = Pt(6.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
print("docx 摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
