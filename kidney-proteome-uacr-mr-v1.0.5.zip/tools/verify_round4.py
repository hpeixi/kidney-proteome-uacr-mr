# -*- coding: utf-8 -*-
"""第四轮最终核验：页数、正文落点、表内状态、工作簿 S16、三个 zip。"""
import re
import zipfile
from pathlib import Path

import fitz
import openpyxl
from docx import Document

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")
TR = Path("交付包/03_可溯源资料包")
pdf = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace\document-preview-4124625769\preview.pdf")

if pdf.exists():
    d = fitz.open(pdf)
    print("页数:", d.page_count)
else:
    print("PDF 缺失")

doc = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in doc.paragraphs)
cells = [c.text for t in doc.tables for r in t.rows for c in r.cells]
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in doc.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(doc.tables[0].rows)}x{len(doc.tables[0].columns)}")

checks = ["five of which survived", "Supplementary Table S16", "No candidate was replicated in plasma",
          "PP.H3 0.998", "Cochran", "P = 0.47", "30 proteins", "S1–S16 cover",
          "difficult to interpret", "winner's curse", "100 kb window"]
print("正文落点:", {k: (k in txt) for k in checks})
print("表内状态:", sorted({c.strip() for c in cells if any(x in c for x in ["consistent", "conflict", "Null"])}))

for label, p in [("EN", EN / "supplementary" / "Table_S1_S16.xlsx"),
                 ("ZH", ZH / "supplementary" / "投稿材料_补充表_S1_S16.xlsx")]:
    wb = openpyxl.load_workbook(p, read_only=True)
    print(f"{label} 工作簿: {len(wb.sheetnames)} 表 | S16 行 {wb['S16_evidence_tiers'].max_row} | S15 行 {wb['S15_eGFR_power'].max_row}")
    wb.close()

for n in ["01_英文资料包", "02_中文资料包", "03_可溯源资料包"]:
    z = Path("交付包") / f"{n}.zip"
    with zipfile.ZipFile(z) as zf:
        names = zf.namelist()
        print(f"{n}.zip: {len(names)} 条目, 完整={zf.testzip() is None}, 含S16表={any('S16' in x for x in names)}")

t = Path("审稿意见应答表.md").read_text(encoding="utf-8")
print("应答表: 行数", len(t.splitlines()), "| 第九节:", "## 九、第四轮意见处理" in t)
