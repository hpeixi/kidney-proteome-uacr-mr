# -*- coding: utf-8 -*-
"""核算 M1 的效应量与 CI、M3 的效能边界，并检索观察性蛋白组学先例。"""
import json
import ssl
import urllib.parse
import urllib.request
from math import comb

import pandas as pd

RES = "交付包/03_可溯源资料包/results"
res = pd.read_csv(f"{RES}/cis_mr_results.csv")

print("== M1：12 个蛋白的效应量与 95% CI（源数据重算）")
for g in ["ISLR2", "BAG3", "PCOLCE", "SERPINA10"]:
    r = res[res.gene == g].sort_values("n_snp").iloc[0]
    b, se = r.UACR_beta, r.UACR_se
    print(f"  {g}: {b*100:+.2f}% ({(b-1.96*se)*100:+.2f} to {(b+1.96*se)*100:+.2f}) | P={r.UACR_p:.1e} | FDR={r.UACR_fdr:.1e}")

allp = res.sort_values("n_snp").drop_duplicates("gene")
lo = (allp.UACR_beta - 1.96 * allp.UACR_se) * 100
hi = (allp.UACR_beta + 1.96 * allp.UACR_se) * 100
print("  最小值(点估计):", f"{allp.UACR_beta.min()*100:+.2f}", "| 最大:", f"{allp.UACR_beta.max()*100:+.2f}")

print("\n== M3：重叠检验的效能边界")
N, K, n = 582, 30, 12


def hyper_p(k):
    return sum(comb(K, i) * comb(N - K, n - i) / comb(N, n) for i in range(k, min(K, n) + 1))


for k in range(0, 5):
    print(f"  观测重叠 {k} 时 P(X>={k}) = {hyper_p(k):.3f}")
crit = next(k for k in range(0, 6) if hyper_p(k) < 0.05)
print("  达到 P<0.05 所需的最小观测重叠:", crit)
# 80% 功效下的真实重叠数
def power(true_k):
    # 真实重叠 true_k 时的分布近似：在 K 中取 n，重叠服从非中心超几何
    from math import comb as C
    p = 0.0
    for x in range(0, min(K, n) + 1):
        # 近似：按独立二项
        pass
    return None

print("  期望重叠:", round(n * K / N, 2))

print("\n== 文献检索：白蛋白尿观察性蛋白组学")
ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
q = urllib.parse.quote("plasma proteomics albuminuria AASK LMAN2")
u = f"https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&term={q}"
ids = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}),
                                       timeout=40, context=ctx).read())["esearchresult"]["idlist"]
print("  PMID:", ids[:5])
if ids:
    u2 = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&retmode=json&id=" + ",".join(ids[:3])
    d = json.loads(urllib.request.urlopen(urllib.request.Request(u2, headers={"User-Agent": "Mozilla/5.0"}),
                                          timeout=40, context=ctx).read())["result"]
    for pid in ids[:3]:
        r = d[pid]
        print(f"  {pid} | {r.get('source')} {r.get('pubdate')};{r.get('volume')}({r.get('issue')}):{r.get('pages')} | {r.get('title','')[:110]}")
