# -*- coding: utf-8 -*-
"""把支持 --prune 与 -Only 的脚本同步进 04 工具包，重算校验值并核验。"""
import hashlib
import shutil
import zipfile
from pathlib import Path

PKG = Path("交付包")
KIT = PKG / "04_发布工具包"
REPO = Path("repo")
SUMS = KIT / "SHA256SUMS_KIT.txt"


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


for name in ("publish_github.py", "release_all.ps1", "publish_zenodo.py", "verify_doi.py"):
    src = REPO / "tools" / name
    if src.exists():
        shutil.copy2(src, KIT / "tools" / name)
        print("同步", name)

gh = (KIT / "tools/publish_github.py").read_text(encoding="utf-8")
ps1 = (KIT / "tools/release_all.ps1").read_text(encoding="utf-8-sig")
print("包内 GitHub 脚本含 --prune:", "--prune" in gh)
print("包内 PowerShell 含 -Only:", "$Only" in ps1)
print("PowerShell 仍为 BOM:", (KIT / "tools/release_all.ps1").read_bytes()[:3] == b"\xef\xbb\xbf")

files = [p for p in sorted(KIT.rglob("*")) if p.is_file() and p != SUMS]
SUMS.write_bytes(("\n".join(f"{sha(p)}  {p.relative_to(KIT).as_posix()}" for p in files) + "\n").encode())
bad = sum(1 for line in SUMS.read_text(encoding="utf-8").splitlines() if line.strip()
          and sha(KIT / line.split("  ", 1)[1]) != line.split("  ", 1)[0])
print(f"清单 {len(files)} 条 | 不符 {bad}")

out = PKG / "04_发布工具包.zip"
if out.exists():
    out.unlink()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in KIT.rglob("*"):
        if f.is_file():
            zf.write(f, Path("04_发布工具包") / f.relative_to(KIT))
z = zipfile.ZipFile(out)
print("zip:", len(z.namelist()), "条目 | 完好:", z.testzip() is None,
      "| %.2f MB" % (out.stat().st_size / 1e6))
