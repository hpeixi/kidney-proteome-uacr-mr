# -*- coding: utf-8 -*-
"""摘要压回 250 内，重建英文稿/说明信 docx，改中文稿 docx 标题，重打包并核验。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"

trims = [
 ("Whether albuminuria-directed screening finds proteins that eGFR-directed screening misses has not been tested directly.",
  "Whether albuminuria-directed screening finds proteins that eGFR-directed screening misses is untested."),
 ("eGFR is therefore not a substitute for albuminuria-directed screening; the five proteins that survived missense exclusion are candidates for validation.",
  "eGFR is not a substitute for such screening; the five proteins surviving missense exclusion are candidates for validation."),
]
for a, b in trims:
    if a in md:
        md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")
s, e = md.index("**Purpose.**"), md.index("**Keywords:**")
print("摘要:", len(re.findall(pat, md[s:e])))


def build(text, path, title_size=14):
    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
        setattr(sec, m, Cm(2.54))
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"; st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    st.paragraph_format.line_spacing = 2.0
    st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)

    def add_runs(p, s):
        for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
            if not seg:
                continue
            if seg.startswith("**") and seg.endswith("**"):
                r = p.add_run(seg[2:-2]); r.bold = True
            elif seg.startswith("^") and seg.endswith("^"):
                r = p.add_run(seg[1:-1]); r.font.superscript = True
            else:
                p.add_run(seg)

    lines = text.split("\n"); i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln or ln == "---":
            i += 1; continue
        if ln.startswith("### "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
            r = p.add_run(ln[4:]); r.bold = True; r.italic = True
        elif ln.startswith("## "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
            r = p.add_run(ln[3:]); r.bold = True
        elif ln.startswith("# "):
            p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
            r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(title_size)
        elif ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            t = doc.add_table(rows=len(rows), cols=len(rows[0]))
            t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
            for ri, row in enumerate(rows):
                for ci, val in enumerate(row):
                    cp = t.cell(ri, ci).paragraphs[0]
                    cp.paragraph_format.line_spacing = 1.0
                    cp.paragraph_format.space_after = Pt(0)
                    r = cp.add_run(val); r.font.size = Pt(7.5)
                    if ri == 0:
                        r.bold = True
            continue
        else:
            add_runs(doc.add_paragraph(), ln)
        i += 1

    el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
    sec._sectPr.append(el)
    fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run()
    c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
    c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
    for x in (c1, it, c2):
        run._r.append(x)
    doc.save(path)


build(md, EN / "manuscript_en.docx")

# 说明信 docx
cl = (EN / "cover_letter.md").read_text(encoding="utf-8")
cld = Document()
s2 = cld.sections[0]
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(s2, m, Cm(2.54))
st2 = cld.styles["Normal"]; st2.font.name = "Times New Roman"; st2.font.size = Pt(12)
st2.paragraph_format.line_spacing = 1.5; st2.paragraph_format.space_after = Pt(6)
for ln in cl.split("\n"):
    if ln.startswith("# "):
        p = cld.add_paragraph(); r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
        p.paragraph_format.space_after = Pt(12)
    elif ln.strip():
        cld.add_paragraph().add_run(ln.strip())
cld.save(EN / "cover_letter.docx")

# 中文稿 docx 标题
zh_doc = ZH / "manuscript_zh.docx"
d = Document(zh_doc)
hit = 0
for para in d.paragraphs:
    if "循环血浆蛋白与白蛋白尿" in para.text:
        full = para.text.replace("循环血浆蛋白与白蛋白尿：一项顺式 pQTL 孟德尔随机化与共定位研究",
                                 "白蛋白尿导向的顺式 pQTL 孟德尔随机化：可行性与阴性对照研究")
        if para.runs:
            para.runs[0].text = full
            for r in para.runs[1:]:
                r.text = ""
        hit += 1
d.save(zh_doc)
print("中文 docx 标题替换:", hit)

# 核验
doc = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in doc.paragraphs)
print("英文 docx 标题:", txt.splitlines()[0][:80])
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in doc.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
for k in ["feasibility and a negative control", "negative control is the main result",
          "not a substitute", "five proteins surviving missense exclusion"]:
    print(f"  {k}: {k in txt}")

zhtxt = "\n".join(p.text for p in Document(zh_doc).paragraphs)
print("中文 docx 含新标题:", "可行性与阴性对照研究" in zhtxt)

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
