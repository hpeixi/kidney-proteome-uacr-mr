# -*- coding: utf-8 -*-
"""核实复制面板的平台/祖先/样本量，并计算 UACR×eGFR 命中重叠的超几何检验。"""
import json
import ssl
import urllib.request
from math import comb

import pandas as pd

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
HDR = {"User-Agent": "Mozilla/5.0", "Accept": "application/json"}

GCST = {
    "ISLR2": "GCST90059992",
    "PCOLCE": "GCST90421386",
    "ITIH1": "GCST90427174",
    "OAF": "GCST90426688",
    "BAG3": "GCST90468416",
}
print("== 面板元数据")
rows = []
for gene, acc in GCST.items():
    try:
        url = f"https://www.ebi.ac.uk/gwas/rest/api/v2/studies/{acc}"
        d = json.loads(urllib.request.urlopen(urllib.request.Request(url, headers=HDR), timeout=40, context=ctx).read())
        info = {k: d.get(k) for k in ["initial_sample_size", "platforms", "full_summary_stats_available", "pubmed_id"]}
    except Exception as e:
        info = {"error": f"{type(e).__name__}"}
    print(f"  {gene} {acc}: {info}")
    rows.append({"gene": gene, "gcst": acc, **info})

pd.DataFrame(rows).to_csv("交付包/03_可溯源资料包/results/S13_replication_panels.csv", index=False, encoding="utf-8-sig")

# ---- 重叠富集检验 ----
res = pd.read_csv("交付包/03_可溯源资料包/results/cis_mr_results.csv")
uacr = set(res[res.UACR_fdr < 0.05].gene)
egfr = set(res[res.eGFR_fdr < 0.05].gene)
tested = len(res)  # 可评估蛋白数
inter = uacr & egfr
print(f"\n== 重叠检验")
print(f"  可评估蛋白 {tested} | UACR 命中 {len(uacr)} | eGFR 命中 {len(egfr)} | 交集 {sorted(inter)}")


def hyper_upper(N, K, n, k):
    """P(X >= k), X~Hypergeom(N=总体, K=成功数, n=抽样数)"""
    return sum(comb(K, i) * comb(N - K, n - i) / comb(N, n) for i in range(k, min(K, n) + 1))


k = len(inter)
p_ge = hyper_upper(tested, len(egfr), len(uacr), k)
exp = len(uacr) * len(egfr) / tested
print(f"  期望重叠 = {exp:.3f} | 观测 = {k} | P(X>={k}) = {p_ge:.3f}")
pd.DataFrame([{"universe": tested, "uacr_hits": len(uacr), "egfr_hits": len(egfr),
               "overlap": k, "expected": round(exp, 3), "p_upper": round(p_ge, 4)}]).to_csv(
    "交付包/03_可溯源资料包/results/S14_overlap_test.csv", index=False, encoding="utf-8-sig")
print("  已写 S13_replication_panels.csv、S14_overlap_test.csv")
