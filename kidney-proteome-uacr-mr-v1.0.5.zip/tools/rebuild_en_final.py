# -*- coding: utf-8 -*-
"""精简摘要 5 词，重建 docx，核验样式级行距。"""
import re
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

MD = "manuscript_en.md"
md = open(MD, encoding="utf-8").read()

subs = [
    ("Effects were estimated by the Wald ratio or inverse-variance weighting, and colocalization was assessed with an approximate Bayes factor.",
     "Effects were estimated by the Wald ratio or inverse-variance weighting; colocalization used an approximate Bayes factor."),
    ("a reverse-direction analysis supported BAG3 as a consequence rather than a cause",
     "reverse-direction analysis supported BAG3 as a consequence rather than a cause"),
    ("Of the two testable in independent panels", "Of two testable in independent panels"),
]
for a, b in subs:
    assert a in md, a[:40]
    md = md.replace(a, b)
open(MD, "w", encoding="utf-8").write(md)

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)

def add_runs(p, text):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", text):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)

body = md.split("\n"); i = 0
while i < len(body):
    ln = body[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(body) and body[i].startswith("|"):
            cells = [c.strip() for c in body[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

sectPr = sec._sectPr
el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save("manuscript_en.docx")

# ---- 核验 ----
d = Document("manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
n_ab = len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab))
print("摘要词数(含小标题):", n_ab, "| 不含小标题:", n_ab - 4)
print("样式行距:", d.styles["Normal"].paragraph_format.line_spacing)
print("直接行距值:", {p.paragraph_format.line_spacing for p in d.paragraphs if p.text.strip()})
print("通讯 ORCID:", "0009-0006-5762-8650" in txt, "| 一作 ORCID:", "0009-0004-5436-7788" in txt)
print("文献数:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
