# -*- coding: utf-8 -*-
"""登记 M1/M7 处理结果，并列出仍需新数据的条目；随后全量核验。"""
import re
import zipfile
from pathlib import Path

import openpyxl
import pandas as pd
from docx import Document

BASE = Path(".")
EN, ZH, TR = BASE / "交付包/01_英文资料包", BASE / "交付包/02_中文资料包", BASE / "交付包/03_可溯源资料包"

# ---------- 1) 应答表 ----------
p = BASE / "审稿意见应答表.md"
t = p.read_text(encoding="utf-8")

rows = """| M1 错义变异敏感性 | 用 Ensembl VEP 注释全部 19 个工具：7 个为错义变异。剔除后重算：8/12 可估计，6 个仍 P<0.05 且方向不变（ISLR2、APOA5、OAF、PCOLCE、RSPO3、ANGPTL1），FCGR2A 降至 P=0.44、SERPINA10 降至 P=0.15，ITIH1/MCL1/SERPINF2/BAG3 仅剩单错义工具无法重算。新增补充表 S11、S12 | 已改 |
| M7 引言 “unknown” 措辞 | 改为 “remain incompletely characterized” | 已改 |
"""

anchor = "| C4 31 个 eGFR 蛋白无表 | 新增补充表 S10（31 行 × 8 列：基因、蛋白、工具数、最小 F、beta、SE、P、FDR），写入英文与中文工作簿，Results 引用 Supplementary Table S10 | 已改 |\n"
if anchor in t and "M1 错义变异敏感性" not in t:
    t = t.replace(anchor, anchor + rows, 1)

need = """
## 七、仍需新数据或新工具的条目

| 条目 | 卡在哪里 | 具体需要 |
|---|---|---|
| C2 换主分析面板 | 本机无大面板数据 | UKB-PPP 全蛋白组（约 2,923 文件、数百 GB）或 deCODE（4,907 蛋白，需注册后下载） |
| M2 官方 SOMAmer–基因映射 | 缺官方注释表 | Sun 2018 补充材料的 SOMAmer–UniProt–Gene 注释文件 |
| M3 多信号共定位 | 缺 LD 面板与工具 | 1000G EUR LD（约 1–2 GB）+ R 的 coloc-SuSiE / susieR |
| M4 全部 12 蛋白反向 MR | 缺全基因组蛋白效应 | 各蛋白全基因组汇总统计（本机只有 cis 区间） |
| M8 与既往 eGFR 蛋白组 MR 比对 | 缺既往命中列表 | Lanktree 2023、Si 2024、Zhao 2024、Zhang 2024 的补充表命中基因清单 |
| M9 clumping 阈值稳健性 | 缺 LD 面板 | 同 M3 的 1000G EUR LD，用于不同 r² 阈值重新聚簇 |

结论：C2 之外的 5 项各自缺一份外部数据或工具，本机现有文件不足以完成；M1 与 M7 无需新数据，已完成。
"""
if "## 七、仍需新数据或新工具的条目" not in t:
    t = t.rstrip() + "\n" + need
p.write_text(t, encoding="utf-8")
print("应答表行数:", len(t.splitlines()), "| 含 M1:", "M1 错义变异敏感性" in t, "| 含数据需求节:", "## 七、仍需新数据" in t)

# ---------- 2) 核验 ----------
d = Document(EN / "manuscript_en.docx")
txt = "\n".join(x.text for x in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("\n== 稿件")
print("  段落:", len(d.paragraphs), "| 表:", len(d.tables), d.tables[0].rows and f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
print("  摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)))
print("  引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)), "| 文献:", len([x for x in d.paragraphs if re.match(r"^\d{1,2}\. ", x.text.strip())]))
for k in ["7 of the 19 instruments", "Supplementary Table S11", "Supplementary Table S12", "incompletely characterized"]:
    print(f"  {k}: {k in txt}")

wb = openpyxl.load_workbook(EN / "supplementary/Table_S1_S12.xlsx", read_only=True)
print("\n== 工作簿工作表:", wb.sheetnames)
print("  S11 行:", wb["S11_Missense_check"].max_row, "| S12 行:", wb["S12_Missense_excluded"].max_row,
      "| S10 行:", wb["S10_eGFR_hits"].max_row)
wb.close()

s11 = pd.read_csv(TR / "results/S11_missense_check.csv")
s12 = pd.read_csv(TR / "results/S12_missense_excluded_mr.csv")
print("  S11 错义数:", int(s11.is_missense.sum()), "/", len(s11), "| S12 可估计:", int(s12.p_noMissense.ne("not estimable").sum()), "/", len(s12))

for name in ["01_英文资料包", "02_中文资料包", "03_可溯源资料包"]:
    z = BASE / "交付包" / f"{name}.zip"
    with zipfile.ZipFile(z) as zf:
        names = zf.namelist()
        print(f"  {name}.zip: {len(names)} 条目, 完整={zf.testzip() is None}, "
              f"含S11={'any' if any('S11' in n for n in names) else 'none'}, 含S12工作簿={any('S12' in n for n in names)}")
