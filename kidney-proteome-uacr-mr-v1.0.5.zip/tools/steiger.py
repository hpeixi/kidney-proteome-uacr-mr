# -*- coding: utf-8 -*-
"""按假定 log-UACR SD=1 计算 12 个蛋白的近似 Steiger 方向性检验。

定义（写入 Methods）：
  r_e = (b_exp/se_exp)/sqrt(N_e),  N_e = 3,301
  r_o = (b_out/se_out)/sqrt(N_o),  N_o = CKDGen 该 SNP 的 n_total_sum
  Z = (r_e^2 - r_o^2) / sqrt((1-r_e^2)^2/N_e + (1-r_o^2)^2/N_o)
多工具蛋白对 r^2 取平均后再算 Z。
"""
import gzip
import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import norm

RES = Path("交付包/03_可溯源资料包/results")
GENES = ["ISLR2", "ITIH1", "OAF", "APOA5", "SERPINA10", "SERPINF2", "BAG3",
         "MCL1", "PCOLCE", "FCGR2A", "ANGPTL1", "RSPO3"]
N_EXP = 3301

cis = pd.read_csv(RES / "cis_snps.csv")
cis = cis[cis.gene.isin(GENES)].copy()
wanted = set(cis.rsid)

# 从 UACR 汇总统计取 n_total_sum
nsum = {}
with gzip.open("data/UACR_EA_Teumer2019.tbl.rsid.gz", "rt", errors="ignore") as fh:
    header = fh.readline().split()
    idx_n = header.index("n_total_sum")
    idx_rs = header.index("RSID")
    for line in fh:
        parts = line.rstrip("\n").split()
        if parts[idx_rs] in wanted:
            nsum[parts[idx_rs]] = int(float(parts[idx_n]))
            if len(nsum) == len(wanted):
                break
print("取到样本量:", len(nsum), "/", len(wanted))

rows = []
for _, r in cis.iterrows():
    n_o = nsum.get(r.rsid)
    if not n_o:
        continue
    r_e = (r.b_exp / r.se_exp) / np.sqrt(N_EXP)
    r_o = (r.UACR_b / r.UACR_se) / np.sqrt(n_o)
    rows.append({"gene": r.gene, "rsid": r.rsid, "n_outcome": n_o,
                 "r_exp": r_e, "r_out": r_o, "r2_exp": r_e ** 2, "r2_out": r_o ** 2})

d = pd.DataFrame(rows)
out = []
for g, sub in d.groupby("gene"):
    r2e, r2o = sub.r2_exp.mean(), sub.r2_out.mean()
    ne, no = N_EXP, sub.n_outcome.mean()
    se = np.sqrt((1 - r2e) ** 2 / ne + (1 - r2o) ** 2 / no)
    z = (r2e - r2o) / se
    p = 2 * norm.sf(abs(z))
    out.append({"Gene": g, "Instruments": len(sub), "r2_exposure": round(r2e, 4),
                "r2_outcome": round(r2o, 4), "Steiger Z": round(z, 2),
                "P": f"{p:.2e}", "Direction": "protein→UACR" if z > 0 else "UACR→protein"})
res = pd.DataFrame(out)
print(res.to_string(index=False))
res.to_csv(RES / "S17_steiger.csv", index=False, encoding="utf-8-sig")
print("\n方向一致（protein→UACR）:", int((res.Direction == "protein→UACR").sum()), "/", len(res))
