# -*- coding: utf-8 -*-
"""精简约 100 词，把版面压回 12 页；重建 docx 并重打 01 包。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

EN = Path("交付包/01_英文资料包")
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

subs = [
 ("A shared signal at a locus, even a strongly colocalized one, says nothing about which trait is upstream, and the BAG3 case shows how easily that ambiguity is missed when only one panel is examined.",
  "A shared signal says nothing about which trait is upstream, and BAG3 shows how easily that is missed with a single panel."),
 ("FCGR2A fell just below the threshold (0.678), and given its role in immune-complex handling that intermediate value may be worth revisiting with better LD information rather than dismissed.",
  "FCGR2A fell just below the threshold (0.678) and, given its immune-complex role, may be worth revisiting rather than dismissed."),
 ("Three further constraints apply. Protein-to-gene mapping was name-based, and an audit of fifteen mappings found four problems. Analyses were confined to European ancestry, so transferability is unknown. No experimental validation was performed, and no protein in this list has been shown to alter albuminuria in a model system.",
  "Mapping was name-based, with four problems in an audit of fifteen. Analyses were confined to European ancestry, and no protein here has been tested experimentally."),
 ("This was a two-sample summary-data MR study. The analysis plan was fixed before the main analysis, and reporting follows STROBE-MR.",
  "This was a two-sample summary-data MR study; the analysis plan was fixed beforehand and reporting follows STROBE-MR."),
 ("Power was computed for each protein from its own standard error; the median detectable change was 3.6% in UACR at 80% power with Bonferroni alpha and 2.1% at FDR 0.05. These are medians across proteins, not a common threshold: each protein has its own detectable effect, tabulated in Supplementary Table S5, and observed effects are compared against those per-protein values.",
  "Power was computed per protein from its own standard error; the median detectable change was 3.6% in UACR with Bonferroni alpha and 2.1% at FDR 0.05. These are medians, not a threshold, and each protein's value is tabulated in Supplementary Table S5."),
 ("Thirty-one aptamer datasets, representing 30 proteins (CST6 was measured twice), were associated with eGFR; estimates for all 31 are given in Supplementary Table S10, with conditional power in Supplementary Table S15.",
  "Thirty-one aptamer datasets, representing 30 proteins (CST6 was measured twice), were associated with eGFR; estimates and conditional power are given in Supplementary Tables S10 and S15."),
 ("The list is biologically heterogeneous and does not converge on a single pathway, which is itself informative: more than one route appears able to raise albuminuria.",
  "The list is heterogeneous and does not converge on one pathway: more than one route appears able to raise albuminuria."),
 ("Direction was tested for BAG3 only. The other candidates were not examined for reverse causation, and the order of analyses (replication first, reverse MR afterwards) means the BAG3 result should be read as an illustration of the problem rather than as a prespecified test.",
  "Direction was tested for BAG3 only; the other candidates were not examined for reverse causation, and the order of analyses makes the BAG3 result an illustration rather than a prespecified test."),
]
for a, b in subs:
    assert a in md, a[:50]
    md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(3)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("摘要:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*", ab)),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
for k in ["Supplementary Tables S10 and S15", "PP.H3", "0.8 threshold", "P = 0.47"]:
    print(f"  {k}: {k in txt}")

z = Path("交付包/01_英文资料包.zip")
if z.exists():
    z.unlink()
with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in EN.rglob("*"):
        if f.is_file():
            zf.write(f, Path("01_英文资料包") / f.relative_to(EN))
print("01 zip:", len(zipfile.ZipFile(z).namelist()), "条目")
