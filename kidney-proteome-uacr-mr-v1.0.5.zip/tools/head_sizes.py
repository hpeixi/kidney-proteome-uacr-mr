# -*- coding: utf-8 -*-
"""HEAD 各候选文件，获取大小，决定下载顺序。"""
import ssl
import urllib.request

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
BASE = "https://ftp.ebi.ac.uk/pub/databases/gwas/summary_statistics/"

cands = [
    ("PCOLCE", "GCST90421386", "GCST90421386.tsv.gz"),
    ("ITIH1", "GCST90427174", "GCST90427174.tsv.gz"),
    ("OAF", "GCST90426688", "GCST90426688.tsv.gz"),
    ("SERPINF2", "GCST90425578", "GCST90425578.tsv.gz"),
    ("ISLR2", "GCST90059992", "GCST90059992_buildGRCh38.tsv.gz"),
    ("ANGPTL1", "GCST90179225", "GCST90179225_buildGRCh38.tsv.gz"),
    ("MCL1", "GCST90161250", "GCST90161250_buildGRCh37.tsv.gz"),
]

def rng(gcst):
    n = int(gcst[4:])
    lo = ((n - 1) // 1000) * 1000 + 1
    return f"GCST{lo:06d}-GCST{lo+999:06d}"

for gene, gcst, fname in cands:
    url = f"{BASE}{rng(gcst)}/{gcst}/{fname}"
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "Mozilla/5.0"})
        r = urllib.request.urlopen(req, timeout=60, context=ctx)
        size = int(r.headers.get("Content-Length", 0))
        print(f"{gene:9s} {gcst}  {size/1024/1024:7.1f} MB  {url}")
    except Exception as e:
        print(f"{gene:9s} {gcst}  失败 {type(e).__name__} {str(e)[:60]}")
