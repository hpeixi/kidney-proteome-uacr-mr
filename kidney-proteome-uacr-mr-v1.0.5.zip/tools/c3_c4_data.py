# -*- coding: utf-8 -*-
"""C3 核验：逐蛋白可检测阈值与观测效应；C4：生成 31 个 eGFR 蛋白完整表。"""
import pandas as pd

RES = "交付包/03_可溯源资料包/results"
r = pd.read_csv(f"{RES}/cis_mr_results.csv")
p = pd.read_csv(f"{RES}/S5_power.csv")

# ---- C3：12 个 UACR 蛋白 ----
u = r[r.UACR_fdr < 0.05][["gene", "UACR_beta", "UACR_fdr", "n_snp"]].copy()
u["pct"] = u.UACR_beta * 100
pw = p.drop_duplicates("gene")[["gene", "min_pct_fdr", "min_pct_bonferroni"]]
m = u.merge(pw, on="gene", how="left")
m["abs_pct"] = m.pct.abs()
m["powered_fdr"] = m.abs_pct >= m.min_pct_fdr
m["margin"] = (m.abs_pct - m.min_pct_fdr).round(2)
m = m.sort_values("pct")
print("== 12 个 UACR 蛋白：观测效应 vs 自身 80% 功效阈值（FDR alpha）")
print(m[["gene", "pct", "min_pct_fdr", "margin", "powered_fdr"]].to_string(index=False))
print("达到自身阈值的蛋白数:", int(m.powered_fdr.sum()), "/", len(m))
print("最接近阈值的:", m.sort_values("margin").iloc[0][["gene", "pct", "min_pct_fdr", "margin"]].to_dict())
print("中位阈值:", round(m.min_pct_fdr.median(), 2), "% | 全体 572 蛋白中位阈值:", round(p.min_pct_fdr.median(), 2), "%")

# ---- C4：31 个 eGFR 蛋白 ----
e = r[r.eGFR_fdr < 0.05][["gene", "protein", "n_snp", "F_min", "eGFR_beta", "eGFR_se",
                          "eGFR_p", "eGFR_fdr"]].copy()
e = e.sort_values("eGFR_fdr")
e["eGFR_beta"] = e.eGFR_beta.round(6)
e["eGFR_se"] = e.eGFR_se.round(6)
e["eGFR_p"] = e.eGFR_p.map(lambda x: f"{x:.2e}")
e["eGFR_fdr"] = e.eGFR_fdr.map(lambda x: f"{x:.2e}")
e["F_min"] = e.F_min.round(1)
e.columns = ["Gene", "Protein", "Instruments", "Min F", "beta", "SE", "P", "FDR"]
e.to_csv(f"{RES}/S10_eGFR_hits.csv", index=False, encoding="utf-8-sig")
print(f"\n== eGFR 蛋白表：{len(e)} 行，已写 S10_eGFR_hits.csv")
print(e.head(8).to_string(index=False))
print("eGFR 最小 FDR:", e.FDR.iloc[0], "| 最大:", e.FDR.iloc[-1])
print("单工具蛋白数:", int((e.Instruments == 1).sum()))
