# -*- coding: utf-8 -*-
"""摘要压回 250 词内，重建 docx，重打三个包并逐项核验第三轮意见的落点。"""
import re
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

OUT = Path("交付包")
EN, ZH, TR = OUT / "01_英文资料包", OUT / "02_中文资料包", OUT / "03_可溯源资料包"
md_path = EN / "manuscript_en.md"
md = md_path.read_text(encoding="utf-8")

subs = [
 ("ISLR2, ITIH1 and PCOLCE gave direction-consistent estimates in independent SomaScan panels, SERPINA10 did so only inconsistently, BAG3 reversed and OAF was null.",
  "ISLR2, ITIH1 and PCOLCE were direction-consistent in independent SomaScan panels, SERPINA10 inconsistently so, BAG3 reversed and OAF was null."),
 ("per SD of genetically predicted protein", "per SD of predicted protein"),
]
for a, b in subs:
    if a in md:
        md = md.replace(a, b, 1)
md_path.write_text(md, encoding="utf-8")

start = md.index("**Purpose.**"); end = md.index("**Keywords:**")
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要词数(含小标题):", len(re.findall(pat, md[start:end])),
      "| 不含:", len(re.findall(pat, re.sub(r"\*\*(Purpose|Methods|Results|Conclusion)\.\*\*", "", md[start:end]))))

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.54))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"; st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0); st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


lines = md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(12)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(12)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(2)
                r = cp.add_run(val); r.font.size = Pt(9)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en.docx")

d = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in d.paragraphs)
cells = [c.text for t in d.tables for r in t.rows for c in r.cells]
ab = txt[txt.index("Purpose."):txt.index("Keywords:")]
print("docx 摘要:", len(re.findall(pat, ab)), "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013-]\s*\d+)*\]", txt)),
      "| 文献:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
checks = ["cerebrospinal fluid", "SomaScan-based", "weakest evidence in the list",
          "expected overlap is 0.62", "P = 0.47", "single-causal-variant assumption",
          "close to tautological", "(CKDGen). Instruments", "weakest instrument F = 29.8",
          "Supplementary Table S13", "Supplementary Table S14"]
for k in checks:
    print(f"  {k}: {k in txt}")
print("  表内 Inconsistently replicated:", sum(1 for c in cells if c == "Inconsistently replicated"))

for folder, name in [(EN, "01_英文资料包"), (ZH, "02_中文资料包"), (TR, "03_可溯源资料包")]:
    z = OUT / f"{name}.zip"
    if z.exists():
        z.unlink()
    with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(name) / f.relative_to(folder))
    with zipfile.ZipFile(z) as zf:
        print(f"{name}.zip: {len(zf.namelist())} 条目, 完整={zf.testzip() is None}")
