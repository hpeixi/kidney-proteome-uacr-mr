# -*- coding: utf-8 -*-
"""第六轮终检：页数、STROBE 随附、关键数字一致性；登记第十四节。"""
import re
import zipfile
from pathlib import Path

import fitz
import pandas as pd
from docx import Document

EN = Path("交付包/01_英文资料包")
pdf = Path(r"C:\Users\HUAWEI\.codar\sessions\session_1793444651654_i7bgbd\workspace\document-preview-2896169825\preview.pdf")
print("页数:", fitz.open(pdf).page_count if pdf.exists() else "PDF 缺失")

doc = Document(EN / "manuscript_en.docx")
txt = "\n".join(p.text for p in doc.paragraphs)
cells = [c.text for t in doc.tables for r in t.rows for c in r.cells]
pat = r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013\u2070-\u209f]*"
print("摘要:", len(re.findall(pat, txt[txt.index("Purpose."):txt.index("Keywords:")])),
      "| 文献:", len([p for p in doc.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]),
      "| 引用:", len(re.findall(r"\[\d+(?:[,\u2013–-]\s*\d+)*\]", txt)),
      "| 表:", f"{len(doc.tables[0].rows)}x{len(doc.tables[0].columns)}")

# M1 三点一致
print("M1 摘要 −6.6→+5.1:", "−6.6% to +5.1%" in txt)
print("M1 正文 ISLR2:", "−6.6% (95% CI −9.3 to −3.9)" in txt, "| BAG3:", "+5.1% (+2.1 to +8.2)" in txt)
print("M1 表内:", any(c.strip() == "-6.6" for c in cells), any(c.strip() in ("5.1", "+5.1") for c in cells))
print("M2 六项达标表述:", "only six reached strong or moderate support" in txt, "| Z 上限归属:", "Z = 36.11 for FCGR2A" in txt)
print("M3 效能边界:", "P(X ≥ 3) = 0.020" in txt, "| 降级:", "in this dataset, eGFR-anchored screening was no substitute" in txt)
print("M4 双口径:", "2,893 participants in the original report" in txt, "| 队列:", "cognitively normal and neurodegenerative" in txt)
print("M5 OAF:", "Drosophila nephrocytes [1]" in txt)
print("M6 [19]:", "[19" in txt, "| 参考文献末条:", [p.text for p in doc.paragraphs if p.text.startswith("19. ")][0][:80])

# STROBE 是否随包
with zipfile.ZipFile(EN.with_suffix(".zip")) as zf:
    names = zf.namelist()
    print("STROBE 在包内:", [n for n in names if "STROBE" in n])
    print("包条目:", len(names), "| 完整:", zf.testzip() is None)

# Table 1 分级统计
rows = [[c.text for c in r.cells] for r in doc.tables[0].rows]
tiers = pd.Series([r[-1] for r in rows[1:]]).value_counts().to_dict()
print("Steiger 分档:", tiers)

p = Path("审稿意见应答表.md")
t = p.read_text(encoding="utf-8")
add = """
## 十四、第六轮意见处理

| 条目 | 处理 | 状态 |
|---|---|---|
| M1 效应量与 CI 不一致 | 以源数据（cis_mr_results）为准重算：ISLR2 −6.62%（−9.32 至 −3.92）、BAG3 +5.14%（+2.12 至 +8.17）；摘要改为“−6.6% to +5.1%”，正文改为“−6.6%（95% CI −9.3 to −3.9）… +5.1%（+2.1 to +8.2）”，与 Table 1 三处一致 | 已改 |
| M2 Steiger“全部方向一致” | 改为“point estimate was in the expected direction for all twelve, but only six reached strong or moderate support”，并点名 Z = 36.11（FCGR2A）与 0.58（MCL1） | 已改 |
| M3 重叠检验效能不足 | 结论降级为“in this dataset, eGFR-anchored screening was no substitute”；讨论补效能边界（需 ≥3 个重叠才 P<0.05，P(X≥3)=0.020；期望 0.62），并说明该检验无法证明“无重叠”；Limitations 增“exploratory… power is minimal” | 已改 |
| M4 [17] 人群与样本量 | 改为“two isolated population-based cohorts”，样本量双口径写明（原文 2,893；GWAS Catalog 2,917）；[18] 补“cognitively normal and neurodegenerative”“3,506 samples; 6,361 proteins”；Table 1 改“isolated cohorts” | 已改 |
| M5 OAF 功能证据 | 补引 [1] 的 trans-omics 与果蝇 nephrocyte 敲低证据，表述改为“其案例并未关闭”，并称 OAF 为最值得实验跟进的候选 | 已改 |
| M6 观察性蛋白组学先例 | 新增 [19] Kiernan 2023 J Am Soc Nephrol 34(6):1078-1089，并在引言区分“观察性关联已知”与“缺少以白蛋白尿为结局的 cis-pQTL MR” | 已改 |
| MINOR 1/3/4/6/9 | “five of the eight”；写明预设与修订期新增的分析；摘要加“in this dataset”；表注注明 strong Steiger 仅反映方向；语言改为“were direction-consistent”“we do not regard it as a candidate” | 已改 |
| M7 共定位窗口扩展 / coloc-SuSiE | 未做：需 1000G LD 面板与 R 环境；现有 PP.H4 在 100 kb 窗口下可能低估 | 未完成 |
| MINOR 2/5/7 | 未做：三蛋白反向 MR（需 LD 剪枝的 UACR 工具）、BH rank 补充列、图 2/4 的平台与窗口标注 | 未完成 |
"""
if "## 十四、第六轮意见处理" not in t:
    t = t.rstrip() + "\n" + add
p.write_text(t, encoding="utf-8")
print("应答表行数:", len(t.splitlines()))
