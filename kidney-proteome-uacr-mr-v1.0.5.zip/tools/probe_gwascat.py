# -*- coding: utf-8 -*-
"""探测 GWAS Catalog 检索接口，按性状名找 GCST（含 Pietzner 2021 与 UKB-PPP）。"""
import json
import ssl
import urllib.parse
import urllib.request

ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE


def get(url, timeout=40):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"})
    r = urllib.request.urlopen(req, timeout=timeout, context=ctx)
    return r.status, r.read().decode("utf-8", "ignore")


q = urllib.parse.quote("BAG3 protein levels")
tests = {
    "v2 studies": f"https://www.ebi.ac.uk/gwas/rest/api/v2/studies?diseaseTrait={q}&size=5",
    "findByDiseaseTrait": f"https://www.ebi.ac.uk/gwas/rest/api/studies/search/findByDiseaseTrait?diseaseTrait={q}&size=5",
    "search api": f"https://www.ebi.ac.uk/gwas/api/search?q={q}&max=5",
    "v2 studies query": f"https://www.ebi.ac.uk/gwas/rest/api/v2/studies?q={q}&size=5",
}
for name, url in tests.items():
    try:
        s, b = get(url)
        print(f"[{name}] HTTP {s} len={len(b)}")
        print("   ", b[:300].replace("\n", " "))
    except Exception as e:
        print(f"[{name}] 失败 {type(e).__name__} {str(e)[:80]}")
