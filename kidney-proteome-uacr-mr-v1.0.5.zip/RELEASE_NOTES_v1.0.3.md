# v1.0.3 发布说明（Zenodo 元数据更新）

本版本**不修改任何分析文件**，只更正记录页的元数据。

## 相对 v1.0.2 的变化

1. 作者单位补全为两位通讯作者所在单位的分号并列写法：
   - Huang, Peixi：`1. Fujian University of Traditional Chinese Medicine, Fuzhou 350122, China; 2. Department of Nephrology, The Second Affiliated Hospital of Guizhou Medical University, Kaili 556000, China`
   - Hong, Dingzhuo / Gao, Zhiyuan：`2. Department of Nephrology, ...`
   - Zhang, Xikui：`1. Fujian University of Traditional Chinese Medicine, Fuzhou 350122, China`
2. 新增 ORCID：
   - Huang, Peixi：`0009-0004-5436-7788`
   - Zhang, Xikui：`0009-0006-5762-8650`
3. 版本号 `1.0.2` → `1.0.3`；`CITATION.cff` 同步。

文件清单与 v1.0.2 完全一致（`LICENSE`、`.zenodo.json`、`README.md`、`analysis/cis_mr.py`、
`results/cis_mr_results.csv`、`figures/Fig1_study_design.png`、`metadata/CITATION.cff`），
无需重新上传。

## 在 Zenodo 上的操作顺序

1. 打开记录页 `https://zenodo.org/records/23851813`，点右侧 **New version**。
2. 在编辑页确认 **Creators** 四项与上面一致，逐个展开填写 **Affiliation** 与 **ORCID**。
3. **Version** 填 `1.0.3`，**Publication date** 保持或改为发布当天。
4. **License** 确认仍为 `MIT License`；**Resource type** 仍为 `Software`。
5. **Description** 末尾追加一段版本说明（可直接拷贝）：

   > v1.0.3 (metadata only): affiliations given as a numbered list for authors with two
   > institutions, ORCID iDs added for the first and corresponding authors. No analysis
   > files changed; the file set is identical to v1.0.2.

6. 点 **Publish**，记录页会给出新的 version DOI。
7. 把新 DOI 发给我，我运行 `repo/update_zenodo_doi.py`，一次性替换稿件、说明信、
   三个交付包与仓库里的旧 DOI，并重新打 zip。
