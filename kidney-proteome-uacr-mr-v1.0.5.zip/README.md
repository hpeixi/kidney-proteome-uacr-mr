# Circulating plasma proteins and albuminuria (cis-pQTL MR)

Code and derived tables for a two-sample Mendelian randomization study of plasma proteins and albuminuria (UACR), with eGFR as a comparator outcome.

- **Exposure**: SomaScan plasma pQTL, 3,282 proteins, n = 3,301 (OpenGWAS `prot-a`)
- **Outcomes**: CKDGen UACR and eGFR, European ancestry
- **Methods**: cis instruments (±500 kb, P < 5e-8, F > 10), Wald ratio or IVW, approximate-Bayes-factor colocalization, independent replication
- **Results**: 582 proteins with cis instruments; 12 associated with UACR (FDR < 0.05); 8 colocalized (PP.H4 ≥ 0.8); no candidate replicated in general-population plasma; overlap with the eGFR-directed list was no greater than chance (P = 0.47)

**Contents**

```
analysis/   8 Python scripts (instruments, MR, colocalization, replication, figures)
tools/      release, provenance and figure scripts (publish_zenodo.py, publish_github.py, fig2_dual_criteria.py)
results/    11 derived tables
figures/    4 figures (PNG 300 dpi + PDF); Figure 2 is the three-panel dual-criteria figure
manuscripts/ final English and Chinese manuscripts (.md and .docx)
metadata/   CITATION.cff, data dictionary
```

All input summary statistics are public (CKDGen, OpenGWAS, GWAS Catalog) and not redistributed here.

Citation and DOI: see `metadata/CITATION.cff`; concept DOI 10.5281/zenodo.23851408 (always resolves to the latest version). Release steps: `UPLOAD.md`.
License: MIT for code, CC BY 4.0 for derived tables and figures.
Contact: hpeixi@foxmail.com
