# 上传说明（GitHub / Zenodo）

## 0. 先看当前真实状态（经 Zenodo API 核对）

| 项目 | 值 |
|---|---|
| 概念 DOI | 10.5281/zenodo.23851408 |
| 最新版本 | v1.0.4，版本 DOI 10.5281/zenodo.23853798 |
| 该版本文件 | 仅 1 个：`hpeixi/kidney-proteome-uacr-mr-v1.0.3.zip` |
| 标题 | 仍为旧标题 |

因此本次发布的是 **1.0.5**：补入最终中英文稿件、双判据 Figure 2、溯源文件与全部脚本。Zenodo 的已发布版本不可覆盖，只能新建版本。

## 1. 准备 token

| 用途 | 权限 | 地址 |
|---|---|---|
| Zenodo | `deposit:write`、`deposit:actions` | https://zenodo.org/account/settings/applications/tokens/new/ |
| GitHub | classic: `repo`；fine-grained: Contents 读写 | https://github.com/settings/tokens |

```powershell
$env:ZENODO_TOKEN = "你的 Zenodo token"
$env:GITHUB_TOKEN = "ghp_你的 GitHub token"
```

## 2. 一条命令发布两处

在仓库根目录（`repo` 的上一级）执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File repo\tools\release_all.ps1 -DryRun
powershell -NoProfile -ExecutionPolicy Bypass -File repo\tools\release_all.ps1
```

参数：

- `-DryRun`：只清点文件、校验凭据，不写任何内容；
- `-Mode Kit`：上传 `交付包\04_发布工具包` 内的三个 zip，而不是整仓（默认 `Repo`）。

## 3. 分步执行（等价）

```powershell
python repo\tools\publish_zenodo.py --dry-run
python repo\tools\publish_zenodo.py
python repo\tools\publish_github.py -m "manuscript 1.0.5"
```

Zenodo 脚本内部依次执行：读概念记录 → `actions/newversion` 建草稿 → 清空草稿继承文件 → 写元数据 → 上传 → `actions/publish`，并把新版本 DOI 写入 `repo\metadata\DOI_LAST_PUBLISHED.txt`。

## 4. 上传后核对

```powershell
python repo\tools\verify_doi.py
python repo\check_zenodo_record.py 23851408
```

判据：

1. `verify_doi.py` 显示的版本号应为 1.0.5，文件数应为整仓文件数（而非 1）；
2. `check_zenodo_record.py` 的 LICENSE 与 `.zenodo.json` 两项应为 PASS；
3. 概念 DOI 仍为 10.5281/zenodo.23851408，指向最新版本；
4. GitHub `main` 最新提交包含 `manuscripts/`、`figures/Fig2_dual_criteria.png`、`PROVENANCE.md`。

## 5. 常见错误

| 现象 | 原因 | 处理 |
|---|---|---|
| `HTTP 401` | token 未设置或已过期 | 重设环境变量，`gh auth`/`curl` 验证 token |
| `HTTP 403` | token 缺 `deposit:*` 权限，或接口被网络策略拦截 | 补权限；改用浏览器手工上传 |
| `HTTP 422` | 元数据字段不合法（如 license/creators） | 检查 `.zenodo.json` 与 Zenodo 元数据规范 |
| 上传后文件数为 1 | 只传了单个归档，未清空草稿 | 本脚本已内置清空逻辑；如仍异常，在网页端删除旧文件后重传 |
| PowerShell 中文乱码 | 5.1 默认按 ANSI 读脚本 | 本脚本已保存为 UTF-8 BOM |
