# -*- coding: utf-8 -*-
"""核对 Zenodo 记录页是否与本地 .zenodo.json 一致：4 位作者、MIT、文件含 LICENSE 与 .zenodo.json。

用法（在 repo 目录下）:
    python check_zenodo_record.py
也可指定记录号:
    python check_zenodo_record.py 23851813

只读公开 API，不写入任何内容；若网络被拦截会给出明确提示。
"""
import json
import ssl
import sys
import urllib.request
from pathlib import Path

RECORD = sys.argv[1] if len(sys.argv) > 1 else "23852899"
API = f"https://zenodo.org/api/records/{RECORD}"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

print(f"GET {API}")
try:
    resp = urllib.request.urlopen(
        urllib.request.Request(API, headers={"User-Agent": "kidney-proteome-uacr-mr-check/1.0", "Accept": "application/json"}),
        timeout=45, context=ctx)
    rec = json.loads(resp.read().decode("utf-8"))
except Exception as e:  # 403 / 超时 / DNS
    print(f"取回失败: {type(e).__name__}: {e}")
    print("若为 403/超时，请在浏览器能打开 zenodo.org 的网络环境下重试，或按页面检查清单人工核对。")
    sys.exit(2)

meta = rec.get("metadata", {})
creators = [c.get("name", "") for c in meta.get("creators", [])]
license_id = (meta.get("license") or {}).get("id", meta.get("license"))
files = [f.get("key", "") for f in rec.get("files", [])]
version = meta.get("version", "?")

print(f"\n记录号: {RECORD}")
print(f"标题: {meta.get('title', '')[:80]}")
print(f"版本: {version}")
print(f"许可: {license_id}")
print(f"作者 ({len(creators)}): {creators}")
print(f"文件 ({len(files)}):")
for f in files:
    print("  -", f)

# 与本地 .zenodo.json 比对
local = Path(".zenodo.json")
expect_names = []
if local.exists():
    zj = json.loads(local.read_text(encoding="utf-8"))
    expect_names = [c.get("name", "") for c in zj.get("creators", [])]

ok = True
def check(label, cond, detail=""):
    global ok
    ok &= bool(cond)
    print(f"[{'PASS' if cond else 'FAIL'}] {label}{(' — ' + detail) if detail else ''}")

print("\n== 核对结果")
check("作者 4 位", len(creators) == 4, f"实际 {len(creators)}")
if expect_names:
    check("作者姓名与 .zenodo.json 一致", creators == expect_names,
          f"记录 {creators} vs 本地 {expect_names}")
check("许可为 MIT", str(license_id).lower() in {"mit", "mit-license", "other-open"} and "mit" in str(license_id).lower(),
      str(license_id))
check("文件含 LICENSE", "LICENSE" in files)
check("文件含 .zenodo.json", ".zenodo.json" in files)

print("\n结论:", "全部通过" if ok else "存在不一致，见上方 FAIL 项")
sys.exit(0 if ok else 1)
