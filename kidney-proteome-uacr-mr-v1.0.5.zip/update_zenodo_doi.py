# -*- coding: utf-8 -*-
"""发布 v1.0.3 后，把旧 DOI 与版本号一次性替换到所有交付物中。

用法：
    python update_zenodo_doi.py 10.5281/zenodo.23852xxx            # 实际替换
    python update_zenodo_doi.py 10.5281/zenodo.23852xxx --dry-run  # 只统计，不写盘

会更新：英文稿 md/docx、cover letter md/docx、中文稿 md/docx、中英对照 md/docx、
两个语言包的 README、可溯源包的 CITATION.cff 与 DOI.txt、repo 的 CITATION.cff，
随后重打三个 zip。
"""
import argparse
import re
import zipfile
from pathlib import Path

from docx import Document

OLD_DOI = "10.5281/zenodo.23852899"
OLD_VER = "v1.0.3"
NEW_VER = "v1.0.4"

BASE = Path(__file__).resolve().parent.parent
PKG = BASE / "交付包"
EN, ZH, TR = PKG / "01_英文资料包", PKG / "02_中文资料包", PKG / "03_可溯源资料包"

TEXT_TARGETS = [
    EN / "manuscript_en.md", EN / "cover_letter.md", EN / "README.md",
    ZH / "manuscript_zh.md", ZH / "manuscript_bilingual.md", ZH / "README.md",
    TR / "metadata" / "CITATION.cff", TR / "README.md",
    BASE / "repo" / "metadata" / "CITATION.cff",
]
DOCX_TARGETS = [
    EN / "manuscript_en.docx", EN / "cover_letter.docx",
    ZH / "manuscript_zh.docx", ZH / "manuscript_bilingual.docx",
]
ZIPS = [PKG / "01_英文资料包.zip", PKG / "02_中文资料包.zip", PKG / "03_可溯源资料包.zip"]


def replace_text(p: Path, new_doi: str, dry: bool) -> int:
    if not p.exists():
        return 0
    t = p.read_text(encoding="utf-8")
    n = t.count(OLD_DOI)
    nv = t.count(OLD_VER)
    if (n or nv) and not dry:
        t = t.replace(OLD_DOI, new_doi).replace(OLD_VER, NEW_VER)
        p.write_text(t, encoding="utf-8")
    return n + nv


def replace_docx(p: Path, new_doi: str, dry: bool) -> int:
    if not p.exists():
        return 0
    d = Document(p)
    n = 0
    for para in d.paragraphs:
        hits = para.text.count(OLD_DOI)
        if not hits:
            continue
        n += hits
        if dry:
            continue
        done = False
        for r in para.runs:
            if OLD_DOI in r.text:
                r.text = r.text.replace(OLD_DOI, new_doi)
                done = True
        if not done:  # DOI 被拆在多个 run 里，退化为整段重写
            full = para.text.replace(OLD_DOI, new_doi)
            if para.runs:
                para.runs[0].text = full
                for r in para.runs[1:]:
                    r.text = ""
    if n and not dry:
        d.save(p)
    return n


MARKER = "DOI: pending (minted when the new version is published)"


def fill_pending_doi(p: Path, new_doi: str, dry: bool) -> int:
    """只填 v1.0.3 的待定行，保留 DOI.txt 中 v1.0.2 的历史 DOI。"""
    if not p.exists():
        return 0
    t = p.read_text(encoding="utf-8")
    if MARKER not in t:
        return 0
    if not dry:
        t = t.replace(MARKER, f"DOI: {new_doi}", 1)
        p.write_text(t, encoding="utf-8")
    return 1


def rezip(dry: bool):
    for z in ZIPS:
        folder = PKG / z.stem
        if dry:
            print(f"  [dry] 将重打 {z.name}")
            continue
        if z.exists():
            z.unlink()
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in folder.rglob("*"):
                if f.is_file():
                    zf.write(f, Path(z.stem) / f.relative_to(folder))
        with zipfile.ZipFile(z) as zf:
            assert zf.testzip() is None
        print(f"  重打 {z.name}: {len(zipfile.ZipFile(z).namelist())} 条目")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("new_doi", help="新版本 DOI，例如 10.5281/zenodo.23852000")
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    assert a.new_doi.startswith("10.5281/zenodo."), "DOI 格式应为 10.5281/zenodo.<数字>"
    assert a.new_doi != OLD_DOI, "与旧 DOI 相同，无需替换"

    print(f"旧 DOI: {OLD_DOI}\n新 DOI: {a.new_doi}\n模式: {'只统计' if a.dry_run else '写入'}\n")
    total = 0
    for p in TEXT_TARGETS:
        n = replace_text(p, a.new_doi, a.dry_run)
        total += n
        print(f"  {p.relative_to(BASE)}: {n} 处")
    for p in DOCX_TARGETS:
        n = replace_docx(p, a.new_doi, a.dry_run)
        total += n
        print(f"  {p.relative_to(BASE)}: {n} 处")
    n = fill_pending_doi(TR / "metadata" / "DOI.txt", a.new_doi, a.dry_run)
    total += n
    print(f"  DOI.txt 待定行: {n} 处（保留 v1.0.2 历史 DOI）")
    print(f"合计 {total} 处")

    if not a.dry_run:
        print("\n重打压缩包:")
        rezip(False)
        print("\n完成。请再运行 repo/check_zenodo_record.py 复核记录页与新 DOI。")


if __name__ == "__main__":
    main()
