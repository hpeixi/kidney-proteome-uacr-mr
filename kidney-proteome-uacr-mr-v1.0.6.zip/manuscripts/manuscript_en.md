# Albuminuria-directed cis-pQTL Mendelian randomization: feasibility and a negative control for proteome-wide screens

**Authors:** Peixi Huang^1,2^ (ORCID 0009-0004-5436-7788), Dingzhuo Hong^2^, Zhiyuan Gao^2^, Xikui Zhang^1^ (ORCID 0009-0006-5762-8650)

**Affiliations:** 1. Fujian University of Traditional Chinese Medicine, Fuzhou 350122, Fujian, China; 2. Department of Nephrology, The Second Affiliated Hospital of Guizhou Medical University, Kaili 556000, Guizhou, China

**Corresponding author:** Xikui Zhang, Chief Physician, Professor, Doctoral Supervisor, Fujian University of Traditional Chinese Medicine, Fuzhou 350122, Fujian, China. E-mail: 623067910@qq.com; ORCID: 0009-0006-5762-8650

**First author:** Peixi Huang (born 1988), attending physician, PhD candidate. E-mail: hpeixi@foxmail.com; ORCID: 0009-0004-5436-7788

**Funding:** None.

---

## Abstract

**Purpose.** Albuminuria indicates injury to the filtration barrier and precedes kidney function loss, yet which proteins act on it is incompletely characterized. Proteome-wide Mendelian randomization (MR) has used estimated glomerular filtration rate (eGFR) or diagnostic labels as outcomes. Whether albuminuria-directed screening finds proteins missed by eGFR-directed screening is untested.

**Methods.** Two-sample MR used cis pQTLs for 3,282 plasma proteins (3,301 European-ancestry participants) against summary statistics for the urinary albumin-to-creatinine ratio (UACR) and eGFR (CKDGen). Instruments lay within 500 kb of the gene with F > 10 (weakest 29.8). Effects used the Wald ratio or inverse-variance weighting; colocalization used an approximate Bayes factor.

**Results.** Of 3,282 proteins, 2,162 carried a significant pQTL; cis restriction left 582 evaluable, 429 with one instrument. Twelve proteins were associated with UACR at false discovery rate < 0.05 (changes −6.4% to +5.3% per SD), and eight colocalized (PP.H4 ≥ 0.8), five of them surviving missense exclusion. Thirty proteins were associated with eGFR; only ITIH1 reached significance for both, in opposite directions, on the weakest evidence of the twelve. ISLR2, ITIH1 and PCOLCE were direction-consistent in independent panels (one serum, two CSF), SERPINA10 inconsistently, ANGPTL1 not evaluable, BAG3 reversed, OAF null; overlap with the eGFR list was no greater than chance (P = 0.47).

**Conclusion.** An albuminuria-directed cis-pQTL screen is feasible, but no protein replicated independently in plasma and the two lists overlapped no more than chance. In this dataset, eGFR-anchored screening was no substitute; five proteins survived missense exclusion and are candidates for validation.

**Keywords:** Albuminuria; Mendelian randomization; Plasma proteome; Colocalization; Chronic kidney disease

---

## Introduction

Albuminuria reflects damage to the glomerular filtration barrier and is among the strongest predictors of kidney failure and cardiovascular death [1]. Observational plasma proteomics and genetic studies have associated several proteins with albuminuria and kidney function decline [19, 6], but no cis-pQTL screen has taken albuminuria as its primary outcome. Observational studies are difficult to interpret because protein concentrations fall as filtration declines, so reverse causation and confounding by severity are built in.

Mendelian randomization (MR) sidesteps that difficulty by using genetic variants that shift a protein's concentration as instruments [14]. Proteome-wide MR has nominated proteins for eGFR, CKD diagnosis, diabetic kidney disease and IgA nephropathy [6–9], nearly always with eGFR or a diagnostic label as the outcome. The two are not interchangeable: eGFR measures filtration capacity, and albuminuria measures barrier integrity.

The question we could answer was narrower than "which proteins affect the kidney": which circulating proteins are prioritized by cis genetic instruments when the outcome is albuminuria rather than eGFR, and whether the two lists converge. The obstacles are concrete: panels are modest, most proteins carry a single instrument, and colocalization under a single-causal-variant assumption can only approximate the posterior probability of a shared variant. We therefore treat the output as prioritization rather than as a list of causal proteins. What follows is a cis-pQTL MR screen with albuminuria as the primary outcome and eGFR as a comparator, an approximate colocalization analysis, and a test of the prioritised proteins in larger independent data, which largely failed.

## Methods

### Design and data sources

This was a two-sample summary-data MR study. The primary screen, colocalization and power analyses were prespecified; replication, the missense sensitivity analysis and the Steiger analysis were added during revision, and reporting follows STROBE-MR. Plasma pQTL summary statistics came from the SomaScan study of Sun and colleagues (3,301 European-ancestry participants; 3,282 aptamer datasets, retrieved through OpenGWAS) [3]. UACR and eGFR summary statistics came from CKDGen (European-ancestry subsets including 564,257 and 1,046,070 participants) [1,2]. All data were summary-level; sources are listed in Supplementary Table S9.

### Instruments and protein-to-gene mapping

Variants lay within 500 kb of the transcription start site, reached P < 5×10⁻⁸ and carried F > 10. F was computed as (β/SE)². Instruments were aligned to the outcome datasets by rsID, and the GRCh37 coordinates carried by those datasets were used for window definition, because the exposure resource reports mixed builds. Protein names were mapped to genes through UniProt, reviewed human entries first; ambiguous mappings were dropped. For the twelve prioritized proteins, each lead variant was checked against the 500 kb window. An audit of fifteen mappings found three paralog assignments and one unmapped protein, none prioritized. Every instrument was annotated with Ensembl VEP (GRCh38), because aptamer binding can change when a coding variant alters the epitope; 7 of 19 were missense.

### Estimation and inference

Proteins with one instrument were analysed by the Wald ratio (β outcome / β protein), with delta-method standard errors; those with two or more instruments by inverse-variance weighting [14]. Direction was examined with an approximate Steiger test [16]. Variance explained was computed as r² = 2f(1−f)β² for each trait, with allele frequency f taken from the CKDGen file because the exposure resource does not report it, and with log-UACR assumed to have unit standard deviation; Z was formed as (r²e − r²o)/√[(1−r²e)²/Ne + (1−r²o)²/No], with Ne = 3,301 and No from CKDGen. One instrument lacked a sample size and was excluded from its protein's test (Supplementary Table S17). Multiple testing used Benjamini–Hochberg FDR across evaluable proteins (Bonferroni threshold 8.6×10⁻⁵). Power was computed per protein from its own standard error; median detectable change was 3.6% in UACR (Bonferroni alpha) and 2.1% (FDR 0.05), tabulated per protein in Supplementary Table S5.

### Colocalization

For proteins reaching FDR < 0.05, UACR variants within 100 kb of the lead pQTL were matched to pQTL effects, and posterior probabilities for five hypotheses were computed assuming a single causal variant [11] (priors 1×10⁻⁴ per trait, 1×10⁻⁵ for a shared variant). This 100 kb window is narrower than the 500 kb instrument window and need not cover the whole gene. PP.H4 ≥ 0.8 was prespecified as strong evidence. This implementation assumes a single causal variant and uses a 100 kb window; the posterior probabilities are therefore approximations (see Limitations).

### Replication, sensitivity and reverse direction

Independent pQTL datasets were sought for the prioritized proteins. A sensitivity analysis was restricted to proteins with two or more cis instruments. Four further datasets came from the GWAS Catalog, spanning two biofluids: a serum SomaScan panel from two isolated population-based cohorts assaying 184 neuro-related proteins [17] (2,893 participants; 2,917 in the GWAS Catalog entry) for ISLR2, and three cerebrospinal fluid datasets from cognitively normal and neurodegenerative disease participants [18] (3,506 samples each) for ITIH1, PCOLCE and OAF. Comparison with UKB-PPP [5] therefore contrasts platforms, and for three proteins also biofluids (Supplementary Table S13). No candidate was replicated in plasma on an independent platform. Reverse-direction MR used pruned UACR instruments to estimate effects on BAG3. Analyses ran in Python 3.12 (NumPy, SciPy, pandas) with data retrieved through the OpenGWAS API. All steps are deterministic and require no random seed.

## Results

### Instruments

Of 3,282 proteins, 2,162 had a genome-wide significant pQTL (3,854 records; 2,271 variants). Cis restriction left 769 variant–protein pairs covering 582 proteins; 429 (73.7%) rested on a single instrument, median minimum F 68.0 (29.8–2,758).

### Proteins associated with UACR and eGFR

Twelve proteins were associated with UACR at FDR < 0.05 (Table 1, Figure 2), with effects ranging from −6.4% (95% CI −8.9 to −3.8) for ISLR2 to +5.3% (+2.1 to +8.5) for BAG3 per 1-SD higher protein; nine were inverse and three (BAG3, PCOLCE, FCGR2A) positive. Only three of the twelve (ISLR2, ITIH1, OAF) also passed the Bonferroni threshold of 8.6×10⁻⁵; the remaining nine lay between that threshold and FDR 0.05. Power and significance derive from the same standard error, so this comparison is near-tautological; FCGR2A (+0.5%), SERPINA10 (−1.2%) and ITIH1 (−1.5%) sit nearest their limits and are the least secure. Thirty-one aptamer datasets (30 proteins; CST6 measured twice) were associated with eGFR; estimates and power are in Supplementary Tables S10 and S15. ITIH1 alone reached significance for both, in opposite directions: 1.46% lower UACR (95% CI −2.07 to −0.83; P = 5.73×10⁻⁶) and 0.0025 lower log eGFR (−0.0036 to −0.0014; P = 5.68×10⁻⁶) per SD, from a single variant (rs1042779) in the ITIH1–ITIH3–ITIH4 cluster (Figure 3). ITIH1 carries the weakest evidence in the list: a single missense instrument, colocalization below the prespecified threshold (PP.H4 0.614), and a locus with several independent signals. Both outcomes are analysed on the natural-log scale distributed by CKDGen, so the eGFR estimate is expressed in log eGFR units per SD of protein.

### Colocalization

Eight of the twelve proteins showed strong evidence of a shared causal variant: APOA5 (0.996), MCL1 (0.984), BAG3 (0.966), ISLR2 (0.887), SERPINA10 (0.882), ANGPTL1 (0.873), PCOLCE (0.852) and RSPO3 (0.817). FCGR2A (0.678) and ITIH1 (0.614) fell in between; OAF (PP.H3 0.998) and SERPINF2 (0.952) resolved to distinct causal variants (Figure 4).

### Replication, sensitivity and reverse direction

An additional SERPINA10 dataset gave β = −0.0098 (SE 0.0028, P = 4.0×10⁻⁴) in the same direction, but its four-instrument dataset gave β = 0.005 (P = 0.28) with one instrument reversed and significant heterogeneity (Q = 14.2, P = 0.007); the datasets conflict. BAG3 did not: in UKB-PPP [5] the estimate reversed (405 cis variants; β = −0.032, SE 0.0025, P = 7.2×10⁻³⁶, against +0.051 in the primary panel). Four further datasets were retrieved from public repositories: ISLR2 (n = 2,917; β = −0.081, SE 0.019, P = 2.3×10⁻⁵), ITIH1 (β = −0.106, SE 0.036, P = 3.3×10⁻³) and PCOLCE (β = 0.075, SE 0.026, P = 4.2×10⁻³) were direction-consistent with the primary estimate, whereas OAF did not replicate (β = 0.002, SE 0.005, P = 0.69); these replication estimates are per-SD protein changes in log UACR and are therefore not on the percentage scale used in Table 1. ANGPTL1 had no genome-wide significant cis variant in its panel, and five proteins (APOA5, SERPINF2, MCL1, FCGR2A, RSPO3) had no independent data. Among 145 proteins with two or more instruments, only OAF kept FDR < 0.05 (β = −0.016, P = 6.9×10⁻⁵). Both SERPINA10 datasets are listed in Supplementary Table S7. With 57 pruned UACR instruments, reverse-direction MR associated higher UACR with lower BAG3 (β = −0.26, SE 0.054, P = 1.3×10⁻⁶). The Steiger point estimate lay in the expected direction for all twelve, but only six reached strong or moderate support (Table 1; Z = 36.11 for FCGR2A, 0.58 for MCL1; Supplementary Table S17); the instruments explain more variance in protein than in UACR, as expected for a proximal trait. Excluding the seven missense instruments (S11) left 8 of 12 estimable (S12): six kept P < 0.05 with unchanged direction (ISLR2, APOA5, OAF, PCOLCE, RSPO3, ANGPTL1); FCGR2A moved to P = 0.44 and SERPINA10 to P = 0.15; four (ITIH1, MCL1, SERPINF2, BAG3) rested on a single missense variant and could not be re-estimated.

## Discussion

An albuminuria-directed cis-pQTL screen proved feasible: 582 proteins were evaluable and twelve were associated with UACR. The list matters less than what the screen shows. Of the eight colocalized proteins, five kept their direction after missense instruments were excluded, one lost significance and two could not be re-estimated (Supplementary Table S16). No candidate was replicated in plasma on an independent platform. An eGFR-directed screen would not have recovered this set either.

PCOLCE matures procollagen, so a positive association fits a pro-fibrotic direction. BAG3, a podocyte chaperone, moved with albuminuria in the primary panel but reversed in UKB-PPP, where reverse MR put albuminuria upstream; a shared signal says nothing about direction, and BAG3 shows how easily one panel can mislead on that point. APOA5 governs triglyceride-rich lipoproteins and was inversely associated, consistent with a lipid–kidney axis; RSPO3 and ANGPTL1 are vascular; SERPINA10 restrains protein Z-dependent protease activity. ISLR2 stays uncharacterized here, although kidney eQTL data place several of these genes in glomerular and tubular compartments [15]. MCL1 passed the colocalization threshold but its signal may reflect pleiotropic variants, and we do not regard it as a candidate. The one protein surviving the multi-instrument analysis, OAF, is also the clearest case of distinct causal variants (PP.H3 0.998) with no independent effect in the panel tested; its case is not closed, because the UACR GWAS coupled albuminuria to plasma OAF and knockdown of the OAF orthologue reduced albumin uptake in Drosophila nephrocytes [1], making OAF the candidate most ready for experimental follow-up. FCGR2A fell just below threshold (0.678) and, given its immune-complex role, is worth revisiting.

That negative control is the main result, and it generalizes beyond this screen. Among 582 evaluable proteins, 12 UACR hits and 30 eGFR hits give an expected overlap of 0.62, and the single shared protein is compatible with chance (P = 0.47, Supplementary Table S14). An eGFR-derived list should not be assumed to stand in for one built on the barrier phenotype. The test is weak, though: at least three overlapping proteins would have been needed for P < 0.05 (P(X ≥ 3) = 0.020), so it can detect substantial overlap but not its absence. We therefore do not claim different protein architectures; we show that a screen built on eGFR does not recover an albuminuria-directed list.

## Limitations

The instrument set is the most consequential limitation: the primary panel (3,301 participants, SomaScan v3) is modest, cross-reactivity is a known problem for this generation of assays, and 74% of evaluable proteins had one instrument. Single-instrument estimates cannot be protected against pleiotropy: MR-Egger, weighted median and MR-PRESSO [12,13] need more than one variant, so none was applied, and the larger deCODE panel [4] was not used. The estimates are associations prioritized by genetic instruments, not causal effects.

Colocalization is approximate: one causal variant was assumed and a 100 kb window used. coloc.abf needs no LD matrix, so the limitation is the single-variant assumption and the window; PP.H4 ≥ 0.8 indicates a shared signal under a simplified model, not a shared causal variant.

Direction was tested formally only by the approximate Steiger analysis, which assumes unit standard deviation for log-UACR and uses CKDGen allele frequencies for an exposure panel that does not report them; it can support direction but cannot exclude reverse causation for an individual protein. Reverse MR was run for BAG3 alone, and the order of analyses makes that result an illustration rather than a prespecified test.

Four of the twelve candidates rest on a single missense variant, so their estimates cannot be separated from an epitope effect on aptamer binding. The replication panels are SomaScan-based, come from neurological cohorts, and three of four are cerebrospinal fluid, so agreement cannot exclude aptamer, biofluid or population effects; only BAG3 was tested in plasma on another platform, and no candidate replicated in plasma from a general population. Instruments and effects came from the same panel, so winner's curse is likely and effect sizes are probably inflated; UACR and eGFR come from the same CKDGen programme, and sample overlap cannot be excluded. The overlap test is exploratory: with these hit counts its power is minimal, and it cannot distinguish absent overlap from moderate overlap. Mapping was name-based, with four problems in an audit of fifteen. Analyses were confined to European ancestry, and no protein here has been tested experimentally.

## Conclusions

An albuminuria-directed cis-pQTL screen is feasible on public data, but it produces candidates rather than causal proteins: five survived missense exclusion, none replicated in plasma on an independent platform, and the eGFR list was not a substitute. The negative control, rather than the candidate list, is the transferable result.

## Declarations

**Ethics approval and consent to participate.** Not applicable; only publicly available summary statistics were used.

**Consent for publication.** Not applicable.

**Availability of data and materials.** All summary statistics are publicly available from CKDGen and OpenGWAS. Derived tables and analysis code are deposited at https://github.com/hpeixi/kidney-proteome-uacr-mr (DOI: 10.5281/zenodo.23851408). The repository is public and contains the scripts, derived result tables and supplementary workbook needed to reproduce the numbers in this article; analyses are deterministic and no random seed is required.

**Competing interests.** The authors declare that they have no competing interests.

**Funding.** The authors received no specific funding for this work.

**Authors' contributions.** Peixi Huang designed the study, performed the analyses and drafted the manuscript. Dingzhuo Hong and Zhiyuan Gao contributed to data interpretation and critical revision. Xikui Zhang supervised the study and revised the manuscript. All authors read and approved the final manuscript.

## References
1. Teumer A, Li Y, Ghasemi S, et al. Genome-wide association meta-analyses and fine-mapping elucidate pathways influencing albuminuria. Nat Commun. 2019;10(1):4130.
2. Wuttke M, Li Y, Li M, et al. A catalog of genetic loci associated with kidney function from analyses of a million individuals. Nat Genet. 2019;51(6):957-972.
3. Sun BB, Maranville JC, Peters JE, et al. Genomic atlas of the human plasma proteome. Nature. 2018;558(7708):73-79.
4. Ferkingstad E, Sulem P, Atlason BA, et al. Large-scale integration of the plasma proteome with genetics and disease. Nat Genet. 2021;53(12):1712-1721.
5. Sun BB, Chiou J, Traylor M, et al. Plasma proteomic associations with genetics and health in the UK Biobank. Nature. 2023;622(7982):329-338.
6. Lanktree MB, Perrot N, Smyth A, et al. A novel multi-ancestry proteome-wide Mendelian randomization study implicates extracellular proteins, tubular cells, and fibroblasts in estimated glomerular filtration rate regulation. Kidney Int. 2023;104(6):1170-1184.
7. Si S, Liu H, Xu L, et al. Identification of novel therapeutic targets for chronic kidney disease and kidney function by integrating multi-omics proteome with transcriptome. Genome Med. 2024;16(1):84.
8. Zhao P, Li Z, Xue S, et al. Proteome-wide mendelian randomization identifies novel therapeutic targets for chronic kidney disease. Sci Rep. 2024;14(1):22114.
9. Zhang W, Ma L, Zhou Q, et al. Therapeutic Targets for Diabetic Kidney Disease: Proteome-Wide Mendelian Randomization and Colocalization Analyses. Diabetes. 2024;73(4):618-627.
10. Deo R, Dubin RF, Ren Y, et al. Proteomic cardiovascular risk assessment in chronic kidney disease. Eur Heart J. 2023;44(23):2095-2110.
11. Giambartolomei C, Vukcevic D, Schadt EE, et al. Bayesian test for colocalisation between pairs of genetic association studies using summary statistics. PLoS Genet. 2014;10(5):e1004383.
12. Verbanck M, Chen CY, Neale B, et al. Detection of widespread horizontal pleiotropy in causal relationships inferred from Mendelian randomization between complex traits and diseases. Nat Genet. 2018;50(5):693-698.
13. Bowden J, Davey Smith G, Haycock PC, et al. Consistent Estimation in Mendelian Randomization with Some Invalid Instruments Using a Weighted Median Estimator. Genet Epidemiol. 2016;40(4):304-14.
14. Burgess S, Butterworth A, Thompson SG. Mendelian randomization analysis with multiple genetic variants using summarized data. Genet Epidemiol. 2013;37(7):658-65.
15. Gillies CE, Putler R, Menon R, et al. An eQTL Landscape of Kidney Tissue in Human Nephrotic Syndrome. Am J Hum Genet. 2018;103(2):232-244.
16. Hemani G, Tilling K, Davey Smith G. Orienting the causal relationship between imprecisely measured traits using GWAS summary data. PLoS Genet. 2017;13(11):e1007081.
17. Png G, Barysenka A, Repetto L, et al. Mapping the serum proteome to neurological diseases using whole genome sequencing. Nat Commun. 2021;12(1):7042.
18. Western D, Timsina J, Wang L, et al. Proteogenomic analysis of human cerebrospinal fluid identifies neurologically relevant regulation and informs biomarkers. Nat Genet. 2024;56(12):2672-2684.
19. Kiernan E, Surapaneni A, Zhou L, et al. Alterations in the Circulating Proteome Associated with Albuminuria. J Am Soc Nephrol. 2023 Jun 1;34(6):1078-1089.

## Table

**Table 1.** Proteins associated with UACR at FDR < 0.05, with replication status.

| Gene | Instruments | Change per SD (%) | 95% CI | P | FDR | PP.H4 | Replication | Steiger |
|---|---|---|---|---|---|---|---|---|
| ISLR2 | 1 | -6.4 | -8.9 to -3.8 | 1.5×10⁻⁶ | 8.8×10⁻⁴ | 0.887 | Direction-consistent (serum; isolated cohorts) [17] | inconclusive |
| ITIH1 | 1 | -1.5 | -2.1 to -0.8 | 5.7×10⁻⁶ | 1.6×10⁻³ | 0.614 | Direction-consistent (CSF; lowest confidence) [18] | strong |
| OAF | 2 | -1.6 | -2.3 to -0.8 | 6.9×10⁻⁵ | 1.3×10⁻² | 0.002 | Null (CSF) [18] | moderate |
| APOA5 | 1 | -5.0 | -7.4 to -2.5 | 9.8×10⁻⁵ | 1.4×10⁻² | 0.996 | No data | inconclusive |
| SERPINA10 | 1 | -1.2 | -1.9 to -0.6 | 1.5×10⁻⁴ | 1.7×10⁻² | 0.882 | Conflict (CSF) [18]† | moderate |
| SERPINF2 | 1 | -4.5 | -6.9 to -2.0 | 4.2×10⁻⁴ | 4.0×10⁻² | 0.048 | No data | inconclusive |
| BAG3 | 1 | +5.3 | 2.1 to 8.5 | 8.7×10⁻⁴ | 4.6×10⁻² | 0.966 | Opposite (plasma; Olink) [5] | inconclusive |
| MCL1 | 1 | -6.0 | -9.3 to -2.6 | 6.2×10⁻⁴ | 4.6×10⁻² | 0.984 | No data | inconclusive |
| PCOLCE | 1 | +3.7 | 1.6 to 5.9 | 6.4×10⁻⁴ | 4.6×10⁻² | 0.852 | Direction-consistent (CSF) [18] | inconclusive |
| FCGR2A | 2 | +0.5 | 0.2 to 0.9 | 8.8×10⁻⁴ | 4.6×10⁻² | 0.678 | No data | strong |
| ANGPTL1 | 2 | -1.6 | -2.6 to -0.7 | 7.8×10⁻⁴ | 4.6×10⁻² | 0.873 | Not evaluable | strong |
| RSPO3 | 1 | -2.5 | -4.0 to -1.0 | 9.9×10⁻⁴ | 4.7×10⁻² | 0.817 | No data | moderate |

†SERPINA10 has two aptamer datasets in the exposure resource: the single-instrument estimate shown here, and a four-instrument dataset (β = 0.005, P = 0.28; Cochran's Q = 14.2, P = 0.007) that does not agree with it in direction. Steiger tiers: strong (Z ≥ 5), moderate (2 ≤ Z < 5), inconclusive (Z < 2); the lowest is MCL1 (Z = 0.58), and strong Steiger support reflects direction only, not overall evidence strength.

## Supplementary material

S1–S17 (instruments through Steiger direction tests) are provided in one workbook; the STROBE-MR checklist is supplied separately.

## Figure legends

**Figure 1.** Study design and evidence flow.

**Figure 2.** Colocalization and replication displayed together for the 12 UACR-associated proteins, ordered by PP.H4. (A) PP.H4; dashed line at 0.8. (B) Change in UACR per 1-SD higher protein (95% CI); inner symbol is the Steiger tier (square strong, triangle moderate, circle inconclusive). (C) Whether each criterion was met. Colour encodes replication status.

**Figure 3.** Concordance between effects on UACR and on eGFR.

**Figure 4.** Posterior probability of a shared causal variant (PP.H4) and of distinct causal variants (PP.H3) at each of the 12 regions; the dashed line marks the prespecified 0.8 threshold.
