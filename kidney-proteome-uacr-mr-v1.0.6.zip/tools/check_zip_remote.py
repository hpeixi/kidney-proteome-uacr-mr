# -*- coding: utf-8 -*-
"""确认远端 zip 体积与 figures 目录现状。"""
import re
import ssl
import urllib.request

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
RAW = "https://raw.githubusercontent.com/hpeixi/kidney-proteome-uacr-mr/main"

req = urllib.request.Request(f"{RAW}/kidney-proteome-uacr-mr-v1.0.5.zip",
                             headers={"User-Agent": UA})
with urllib.request.urlopen(req, timeout=60, context=CTX) as r:
    cl = r.headers.get("Content-Length")
    print("远端 zip 大小:", cl, "字节 | 本地: 1575469 字节 | 一致:", cl == "1575469")
    data = r.read(4)
    print("文件头:", data, "(PK 开头即正常 zip)")

req2 = urllib.request.Request("https://github.com/hpeixi/kidney-proteome-uacr-mr/tree/main/figures",
                              headers={"User-Agent": UA})
with urllib.request.urlopen(req2, timeout=60, context=CTX) as r:
    html = r.read().decode("utf-8", "replace")
print("figures 目录含 Fig2_forest:", "Fig2_forest" in html)
print("figures 目录含 Fig2_dual_criteria:", "Fig2_dual_criteria" in html)
print("目录内 png/pdf 文件名:", sorted(set(re.findall(r"Fig[\w.]+\.(?:png|pdf)", html))))
