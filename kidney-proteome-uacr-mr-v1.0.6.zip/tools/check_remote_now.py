# -*- coding: utf-8 -*-
"""核对 GitHub 远端：最新提交、文件数、上传包与旧图是否清理。"""
import json
import ssl
import urllib.request

OWNER_REPO = "hpeixi/kidney-proteome-uacr-mr"
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE


def get(url):
    req = urllib.request.Request(url, headers={
        "User-Agent": "kidney-proteome-check/1.0",
        "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=45, context=CTX) as r:
        return json.loads(r.read())


repo = get(f"https://api.github.com/repos/{OWNER_REPO}")
ref = get(f"https://api.github.com/repos/{OWNER_REPO}/git/ref/heads/main")
commit = get(f"https://api.github.com/repos/{OWNER_REPO}/git/commits/{ref['object']['sha']}")
tree = get(f"https://api.github.com/repos/{OWNER_REPO}/git/trees/{commit['tree']['sha']}?recursive=1")
paths = [t["path"] for t in tree["tree"] if t["type"] == "blob"]

print("pushed_at:", repo["pushed_at"])
print("main head:", ref["object"]["sha"][:12], "|", commit["message"][:60], "|", commit["author"]["date"])
print("远端文件数:", len(paths))
for p in paths:
    print("  ", p)
print("\n旧森林图仍在:", [p for p in paths if "Fig2_forest" in p] or "已清理")
