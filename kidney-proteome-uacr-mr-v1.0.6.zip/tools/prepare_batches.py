# -*- coding: utf-8 -*-
"""复核远端旧图状态，并把仓库文件切成两批（每批 ≤100）供网页拖拽上传。"""
import shutil
import ssl
import urllib.error
import urllib.request
from pathlib import Path

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
RAW = "https://raw.githubusercontent.com/hpeixi/kidney-proteome-uacr-mr/main"


def head(path):
    req = urllib.request.Request(f"{RAW}/{path}", method="HEAD", headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=30, context=CTX) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code


print("== 远端现状 ==")
for p in ("figures/Fig2_forest_UACR.png", "figures/Fig2_forest_UACR.pdf",
          "figures/Fig2_dual_criteria.png", "PROVENANCE.md",
          "kidney-proteome-uacr-mr-v1.0.5.zip"):
    print(f"  {p}: HTTP {head(p)}")

# 分批
REPO = Path("repo")
SKIP = {".git", "__pycache__", ".ipynb_checkpoints"}
files = sorted(p for p in REPO.rglob("*") if p.is_file() and not any(x in p.parts for x in SKIP))
group_a, group_b = [], []
for p in files:
    rel = p.relative_to(REPO)
    top = rel.parts[0]
    (group_b if top in {"tools", "analysis"} else group_a).append(p)
if len(group_a) > 100:
    print(f"批次1 超过 100（{len(group_a)}），按目录再分")
    extra = [p for p in group_a if p.relative_to(REPO).parts[0] == "results"]
    group_b += extra
    group_a = [p for p in group_a if p not in extra]

BASE = Path("GitHub上传")
for name, group in (("批次1_稿件与图件", group_a), ("批次2_脚本与结果", group_b)):
    d = BASE / name
    if d.exists():
        shutil.rmtree(d)
    d.mkdir(parents=True)
    for p in group:
        dst = d / p.relative_to(REPO)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dst)
    total = sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
    print(f"{name}: {len(group)} 个文件, {total/1e6:.2f} MB")

big = [p for p in files if p.stat().st_size > 25 * 1024 * 1024]
print("超过网页单文件 25MB 限制:", [p.name for p in big] or "无")
print("两批合计:", len(group_a) + len(group_b), "（仓库总数", len(files), "）")
