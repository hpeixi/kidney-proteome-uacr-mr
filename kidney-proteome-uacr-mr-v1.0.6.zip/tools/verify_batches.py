# -*- coding: utf-8 -*-
"""最终核对：远端旧图状态、批次文件夹内容是否含关键文件。"""
import ssl
import urllib.error
import urllib.request
from pathlib import Path

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
RAW = "https://raw.githubusercontent.com/hpeixi/kidney-proteome-uacr-mr/main"


def head(path):
    req = urllib.request.Request(f"{RAW}/{path}", method="HEAD", headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=30, context=CTX) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code


print("== 远端 ==")
for p in ("figures/Fig2_forest_UACR.png", "figures/Fig2_forest_UACR.pdf",
          "kidney-proteome-uacr-mr-v1.0.5.zip", "figures/Fig2_dual_criteria.png",
          "PROVENANCE.md", "manuscripts/manuscript_en.docx"):
    print(f"  {p}: HTTP {head(p)}")

print("\n== 批次文件夹 ==")
BASE = Path("GitHub上传")
key = {"manuscripts/manuscript_en.docx", "manuscripts/manuscript_zh.docx",
       "figures/Fig2_dual_criteria.png", "PROVENANCE.md", ".zenodo.json", "LICENSE"}
found = set()
for d in sorted(p for p in BASE.iterdir() if p.is_dir() and p.name.startswith("批次")):
    files = [f for f in d.rglob("*") if f.is_file()]
    rels = {f.relative_to(d).as_posix() for f in files}
    found |= (rels & key)
    print(f"{d.name}: {len(files)} 个文件, {sum(f.stat().st_size for f in files)/1e6:.2f} MB, "
          f"{'≤100 OK' if len(files) <= 100 else '超限'}")
print("关键文件覆盖:", "齐全" if key <= found else f"缺 {sorted(key - found)}")
