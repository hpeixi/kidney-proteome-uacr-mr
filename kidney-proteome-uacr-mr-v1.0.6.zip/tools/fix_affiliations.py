# -*- coding: utf-8 -*-
"""修正作者单位：张喜奎 -> 福建中医药大学；黄培喜 1,2；重建全部稿件与包。"""
import re
import shutil
import sys
import zipfile
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt

sys.path.insert(0, str(Path("repo/tools").resolve()))
from docx_build import build  # noqa: E402

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")
REPO = Path("repo")

# ---------- 1. 文本修正 ----------
FIX = {
 EN / "manuscript_en.md": [
  ("Department of Nephrology, The Second Affiliated Hospital of Guizhou Medical University, Kaili 556000, Guizhou, China. E-mail: 623067910@qq.com",
   "Fujian University of Traditional Chinese Medicine, Fuzhou 350122, Fujian, China. E-mail: 623067910@qq.com"),
 ],
 ZH / "manuscript_zh.md": [
  ("**通信作者：** 张喜奎，主任医师、教授、博士生导师，贵州医科大学第二附属医院肾内科，凯里 556000。",
   "**通信作者：** 张喜奎，主任医师、教授、博士生导师，福建中医药大学，福建 福州 350122。"),
 ],
 ZH / "manuscript_bilingual.md": [
  ("# Circulating plasma proteins and albuminuria: a cis-pQTL Mendelian randomization and colocalization study",
   "# Albuminuria-directed cis-pQTL Mendelian randomization: feasibility and a negative control for proteome-wide screens"),
  ("# 循环血浆蛋白与白蛋白尿：一项顺式 pQTL 孟德尔随机化与共定位研究",
   "# 白蛋白尿导向的顺式 pQTL 孟德尔随机化：可行性与阴性对照研究"),
  ("**Corresponding author / 通信作者：** 张喜奎，主任医师、教授、博士生导师，贵州医科大学第二附属医院肾内科，凯里 556000。",
   "**Corresponding author / 通信作者：** 张喜奎（Xikui Zhang），主任医师、教授、博士生导师，福建中医药大学，福建 福州 350122（Fujian University of Traditional Chinese Medicine, Fuzhou 350122, Fujian, China）。"),
 ],
}

for path, subs in FIX.items():
    s = path.read_text(encoding="utf-8")
    for old, new in subs:
        if old in s:
            s = s.replace(old, new, 1)
        else:
            print("  未匹配:", path.name, old[:40])
    path.write_text(s, encoding="utf-8")
    print("已修正:", path.name)

# ---------- 2. 重建 docx ----------
en_md = (EN / "manuscript_en.md").read_text(encoding="utf-8")
build(en_md, EN / "manuscript_en.docx")
build(en_md, EN / "manuscript_en_nolines.docx", line_numbers=False)

for name in ("manuscript_zh", "manuscript_bilingual"):
    p = ZH / f"{name}.md"
    build(p.read_text(encoding="utf-8"), ZH / f"{name}.docx")

# ---------- 3. 单文件投稿稿（含图） ----------
FIGURES = [("Figure 1", "figures/Fig1_study_design.png"),
           ("Figure 2", "figures/Fig2_dual_criteria.png"),
           ("Figure 3", "figures/Fig3_concordance.png"),
           ("Figure 4", "figures/Fig4_coloc.png")]

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.2))
st = doc.styles["Normal"]
st.font.name = "Times New Roman"
st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0)
st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2]); r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1]); r.font.superscript = True
        else:
            p.add_run(seg)


def add_figure(label, rel, page_break=False):
    if page_break:
        doc.add_page_break()
    cap = doc.add_paragraph()
    cap.paragraph_format.space_before = Pt(6)
    cap.paragraph_format.line_spacing = 1.0
    cap.paragraph_format.keep_with_next = True
    cap.paragraph_format.keep_together = True
    r = cap.add_run(label); r.bold = True; r.font.size = Pt(11)
    pic = doc.add_paragraph()
    pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pic.paragraph_format.line_spacing = 1.0
    pic.paragraph_format.space_after = Pt(6)
    pic.paragraph_format.keep_together = True
    pic.add_run().add_picture(str(EN / rel), width=Cm(16.0))


lines = en_md.split("\n"); i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1; continue
    if ln.startswith("### "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val); r.font.size = Pt(6.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

for idx, (label, rel) in enumerate(FIGURES):
    add_figure(label, rel, page_break=(idx > 0))

el = OxmlElement("w:lnNumType"); el.set(qn("w:countBy"), "1"); el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)
fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)
doc.save(EN / "manuscript_en_submission.docx")

# ---------- 4. 同步 repo 与打包 ----------
mdir = REPO / "manuscripts"
mdir.mkdir(exist_ok=True)
for src in (EN / "manuscript_en.md", EN / "manuscript_en.docx",
            ZH / "manuscript_zh.md", ZH / "manuscript_zh.docx"):
    shutil.copy2(src, mdir / src.name)

def pack(folder, label, zpath):
    zp = Path(zpath)
    if zp.exists():
        zp.unlink()
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in folder.rglob("*"):
            if f.is_file():
                zf.write(f, Path(label) / f.relative_to(folder))
    z = zipfile.ZipFile(zp)
    print(zpath, len(z.namelist()), "条目 | 完好:", z.testzip() is None)

pack(EN, "01_英文资料包", "交付包/01_英文资料包.zip")
pack(ZH, "02_中文资料包", "交付包/02_中文资料包.zip")

# ---------- 5. 核验 ----------
print("\n== 核验作者信息 ==")
for p in (EN / "manuscript_en.docx", EN / "manuscript_en_submission.docx", ZH / "manuscript_zh.docx"):
    d = Document(p)
    t = "\n".join(x.text for x in d.paragraphs)
    au = [l for l in t.split("\n") if l.startswith(("Authors", "作者", "Corresponding", "通信作者"))]
    print(f"\n[{p.name}]")
    for l in au:
        print("  ", l[:150])
    print("   含 Fujian in corresponding:", "Fujian University" in " ".join(au) or "福建中医药大学" in " ".join(au))
    print("   单位 2 仍为贵州:", "Guizhou Medical University" in " ".join(au) or "贵州医科大学" in " ".join(au))
