# -*- coding: utf-8 -*-
"""核验：远端 zip 内容哈希与本地一致；Zenodo 当前最新版本。"""
import hashlib
import io
import json
import ssl
import urllib.request
import zipfile
from pathlib import Path

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
LOCAL = Path("GitHub上传/kidney-proteome-uacr-mr-v1.0.5.zip")
RAW = "https://raw.githubusercontent.com/hpeixi/kidney-proteome-uacr-mr/main/kidney-proteome-uacr-mr-v1.0.5.zip"

req = urllib.request.Request(RAW, headers={"User-Agent": UA})
with urllib.request.urlopen(req, timeout=120, context=CTX) as r:
    data = r.read()

remote_sha = hashlib.sha256(data).hexdigest()
local_sha = hashlib.sha256(LOCAL.read_bytes()).hexdigest()
print("远端字节:", len(data), "| 本地字节:", LOCAL.stat().st_size)
print("远端 SHA256:", remote_sha)
print("本地 SHA256:", local_sha)
print("完全一致:", remote_sha == local_sha)

z = zipfile.ZipFile(io.BytesIO(data))
names = z.namelist()
print("远端包内文件数:", len(names), "| 完整性:", z.testzip() is None)
for k in ("manuscripts/manuscript_en.docx", "manuscripts/manuscript_zh.docx",
          "figures/Fig2_dual_criteria.png", "PROVENANCE.md", ".zenodo.json"):
    print(("  有 " if k in names else "  缺 ") + k)

print("\n== Zenodo ==")
try:
    rq = urllib.request.Request("https://zenodo.org/api/records/23851408",
                                headers={"User-Agent": "kidney-check/1.0"})
    with urllib.request.urlopen(rq, timeout=45, context=CTX) as r:
        rec = json.loads(r.read())
    print("最新版本:", rec["metadata"].get("version"))
    print("版本 DOI:", rec.get("doi"))
    print("文件数:", len(rec.get("files", [])),
          [f.get("key") for f in rec.get("files", [])][:5])
except Exception as e:
    print("Zenodo 读取失败:", type(e).__name__, e)
