# -*- coding: utf-8 -*-
"""不依赖 GitHub API 的远端核对：抓仓库 HTML 与 raw 文件。"""
import re
import ssl
import urllib.error
import urllib.request

BASE = "https://github.com/hpeixi/kidney-proteome-uacr-mr"
RAW = "https://raw.githubusercontent.com/hpeixi/kidney-proteome-uacr-mr/main"
CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"


def get(url, head=False):
    req = urllib.request.Request(url, method="HEAD" if head else "GET",
                                 headers={"User-Agent": UA, "Accept": "text/html"})
    with urllib.request.urlopen(req, timeout=45, context=CTX) as r:
        return r.status, ("" if head else r.read().decode("utf-8", "replace"))


try:
    code, html = get(BASE)
    print("仓库页:", code, "| 长度:", len(html))
except Exception as e:
    print("仓库页读取失败:", e)
    html = ""

if html:
    hits = re.findall(r"kidney-proteome-uacr-mr-v[\d.]+\.zip", html)
    print("页面出现的上传包名:", sorted(set(hits)) or "无")
    print("含 Fig2_dual_criteria:", "Fig2_dual_criteria" in html)
    print("含 Fig2_forest:", "Fig2_forest" in html)
    m = re.search(r"commit[^<]{0,80}", html)
    files = re.findall(r'title="([^"]+\.(?:zip|md|py|json|docx))"', html)
    print("页面列出的文件（前 20）:", files[:20])

for path in ("PROVENANCE.md", "manuscripts/manuscript_en.docx", "figures/Fig2_dual_criteria.png",
             "kidney-proteome-uacr-mr-v1.0.5.zip", "figures/Fig2_forest_UACR.png"):
    try:
        code, _ = get(f"{RAW}/{path}", head=True)
        print(f"raw {path}: {code}")
    except urllib.error.HTTPError as e:
        print(f"raw {path}: HTTP {e.code}")
    except Exception as e:
        print(f"raw {path}: {type(e).__name__}")
