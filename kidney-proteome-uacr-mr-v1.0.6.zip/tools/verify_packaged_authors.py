# -*- coding: utf-8 -*-
"""核验包内与仓库副本是否都是修正后的作者信息。"""
import io
import zipfile
from pathlib import Path

from docx import Document

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")
REPO = Path("repo/manuscripts")


def author_lines(docx_bytes):
    d = Document(io.BytesIO(docx_bytes))
    t = "\n".join(p.text for p in d.paragraphs)
    keys = ("Corresponding author", "通信作者", "Authors:", "作者：")
    return [l for l in t.split("\n") if l.startswith(keys)]


for zp, member in (("交付包/01_英文资料包.zip", "01_英文资料包/manuscript_en.docx"),
                   ("交付包/02_中文资料包.zip", "02_中文资料包/manuscript_zh.docx")):
    z = zipfile.ZipFile(zp)
    hit = [n for n in z.namelist() if n.endswith(member.split("/")[-1])]
    print(f"\n{zp} -> {hit}")
    for n in hit:
        for l in author_lines(z.read(n)):
            print("  ", l[:130])

print("\n[repo/manuscripts 副本]")
for p in sorted(REPO.glob("*.docx")):
    for l in author_lines(p.read_bytes()):
        print(f"  {p.name}: {l[:110]}")
