# -*- coding: utf-8 -*-
"""生成单文件投稿稿：正文 + 表 1 + 四张图全部内嵌在一个 .docx。"""
import re
import sys
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

EN = Path("交付包/01_英文资料包")
md = (EN / "manuscript_en.md").read_text(encoding="utf-8")

FIGURES = [
    ("Figure 1", "figures/Fig1_study_design.png"),
    ("Figure 2", "figures/Fig2_dual_criteria.png"),
    ("Figure 3", "figures/Fig3_concordance.png"),
    ("Figure 4", "figures/Fig4_coloc.png"),
]

doc = Document()
sec = doc.sections[0]
sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
for m in ("top_margin", "bottom_margin", "left_margin", "right_margin"):
    setattr(sec, m, Cm(2.2))

st = doc.styles["Normal"]
st.font.name = "Times New Roman"
st.font.size = Pt(12)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")
st.paragraph_format.line_spacing = 2.0
st.paragraph_format.space_before = Pt(0)
st.paragraph_format.space_after = Pt(0)


def add_runs(p, s):
    for seg in re.split(r"(\*\*.+?\*\*|\^.+?\^)", s):
        if not seg:
            continue
        if seg.startswith("**") and seg.endswith("**"):
            r = p.add_run(seg[2:-2])
            r.bold = True
        elif seg.startswith("^") and seg.endswith("^"):
            r = p.add_run(seg[1:-1])
            r.font.superscript = True
        else:
            p.add_run(seg)


def add_figure(label, rel, page_break=False):
    if page_break:
        doc.add_page_break()
    cap = doc.add_paragraph()
    cap.paragraph_format.space_before = Pt(6)
    cap.paragraph_format.line_spacing = 1.0
    cap.paragraph_format.keep_with_next = True
    cap.paragraph_format.keep_together = True
    r = cap.add_run(label)
    r.bold = True
    r.font.size = Pt(11)

    pic = doc.add_paragraph()
    pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pic.paragraph_format.line_spacing = 1.0
    pic.paragraph_format.space_after = Pt(6)
    pic.paragraph_format.keep_together = True
    pic.add_run().add_picture(str(EN / rel), width=Cm(16.0))


lines = md.split("\n")
i = 0
while i < len(lines):
    ln = lines[i].rstrip()
    if not ln or ln == "---":
        i += 1
        continue
    if ln.startswith("### "):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(2)
        r = p.add_run(ln[4:]); r.bold = True; r.italic = True
    elif ln.startswith("## "):
        p = doc.add_paragraph()
        p.paragraph_format.space_before = Pt(4)
        r = p.add_run(ln[3:]); r.bold = True
    elif ln.startswith("# "):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        r = p.add_run(ln[2:]); r.bold = True; r.font.size = Pt(14)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                cp = t.cell(ri, ci).paragraphs[0]
                cp.paragraph_format.line_spacing = 1.0
                cp.paragraph_format.space_after = Pt(0)
                r = cp.add_run(val)
                r.font.size = Pt(6.5)
                if ri == 0:
                    r.bold = True
        continue
    else:
        add_runs(doc.add_paragraph(), ln)
    i += 1

# 图注之后追加四张图（内嵌，可编辑）
for idx, (label, rel) in enumerate(FIGURES):
    add_figure(label, rel, page_break=(idx > 0))

el = OxmlElement("w:lnNumType")
el.set(qn("w:countBy"), "1")
el.set(qn("w:restart"), "continuous")
sec._sectPr.append(el)

fp = sec.footer.paragraphs[0]
fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = fp.add_run()
c1 = OxmlElement("w:fldChar"); c1.set(qn("w:fldCharType"), "begin")
it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = "PAGE"
c2 = OxmlElement("w:fldChar"); c2.set(qn("w:fldCharType"), "end")
for x in (c1, it, c2):
    run._r.append(x)

out = EN / "manuscript_en_submission.docx"
doc.save(out)

d = Document(out)
t = "\n".join(p.text for p in d.paragraphs)
seg = t[t.index("Purpose."):t.index("Keywords:")]
print("输出:", out.as_posix(), round(out.stat().st_size / 1024), "KB")
print("内嵌图片:", len(d.inline_shapes), "| 表:", f"{len(d.tables[0].rows)}x{len(d.tables[0].columns)}")
print("摘要词数:", len(re.findall(r"[A-Za-z0-9][A-Za-z0-9%.\-\u2013]*", seg)))
print("文献条数:", len([p for p in d.paragraphs if re.match(r"^\d{1,2}\. ", p.text.strip())]))
print("四个图标签:", [p.text for p in d.paragraphs if p.text.strip() in ("Figure 1", "Figure 2", "Figure 3", "Figure 4")])
