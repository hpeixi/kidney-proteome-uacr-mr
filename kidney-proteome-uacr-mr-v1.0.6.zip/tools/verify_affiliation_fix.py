# -*- coding: utf-8 -*-
"""核验：上标、对照版、单文件稿图表、包内文件。"""
import zipfile
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn

EN = Path("交付包/01_英文资料包")
ZH = Path("交付包/02_中文资料包")


def sup_runs(path):
    d = Document(path)
    out = []
    for p in d.paragraphs:
        for r in p.runs:
            rpr = r._element.find(qn("w:rPr"))
            if rpr is not None:
                va = rpr.find(qn("w:vertAlign"))
                if va is not None and va.get(qn("w:val")) == "superscript":
                    out.append(r.text)
    return out


for p in (EN / "manuscript_en.docx", EN / "manuscript_en_submission.docx"):
    print(p.name, "上标内容:", sup_runs(p))

d = Document(ZH / "manuscript_bilingual.docx")
t = "\n".join(x.text for x in d.paragraphs)
print("\n[对照版] 标题行:")
for l in t.split("\n")[:6]:
    if l.strip():
        print("  ", l[:110])
print("  通信作者行:", [l for l in t.split("\n") if "通信作者" in l][:1])

s = Document(EN / "manuscript_en_submission.docx")
print("\n单文件稿: 图片", len(s.inline_shapes), "| 表",
      f"{len(s.tables[0].rows)}x{len(s.tables[0].columns)}",
      "| 摘要词数:", len("\n".join(x.text for x in s.paragraphs).split()[0:0]) or "见前")

for zp in ("交付包/01_英文资料包.zip", "交付包/02_中文资料包.zip"):
    z = zipfile.ZipFile(zp)
    names = [n.split("/")[-1] for n in z.namelist()]
    print(f"\n{zp}: {len(names)} 条目 | 完好 {z.testzip() is None}")
    print("  含单文件稿:", "manuscript_en_submission.docx" in names)
    print("  含无行号版:", "manuscript_en_nolines.docx" in names)
