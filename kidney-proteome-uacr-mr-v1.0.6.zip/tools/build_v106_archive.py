# -*- coding: utf-8 -*-
"""作者单位修正后：生成 v1.0.6 归档包、更新元数据与 DOI 记录。"""
import hashlib
import json
import zipfile
from datetime import date
from pathlib import Path

ROOT = Path(".")
REPO = ROOT / "repo"
OUT = ROOT / "GitHub上传"
OUT.mkdir(exist_ok=True)
TITLE = ("Albuminuria-directed cis-pQTL Mendelian randomization: feasibility and a negative control "
         "for proteome-wide screens")
VERSION = "1.0.6"
SKIP = {".git", "__pycache__", ".ipynb_checkpoints"}

# 1) 元数据版本
zj = REPO / ".zenodo.json"
d = json.loads(zj.read_text(encoding="utf-8"))
d["title"] = TITLE + " (analysis code and derived tables)"
d["version"] = VERSION
d["publication_date"] = date.today().isoformat()
d["notes"] = ("v1.0.6 corrects the corresponding author's affiliation to Fujian University of Traditional "
              "Chinese Medicine in both language versions of the manuscript.")
zj.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")

cit = REPO / "metadata/CITATION.cff"
cs = cit.read_text(encoding="utf-8").replace("version: 1.0.5", f"version: {VERSION}")
cit.write_text(cs, encoding="utf-8")

doi = REPO / "metadata/DOI.txt"
s = doi.read_text(encoding="utf-8")
if "v1.0.6" not in s:
    s = s.replace("说明：Zenodo 已发布版本不可覆盖",
                  "  v1.0.6  待发布（修正通信作者单位：福建中医药大学）\n说明：Zenodo 已发布版本不可覆盖")
    doi.write_text(s, encoding="utf-8")

# 2) 归档
files = sorted(p for p in REPO.rglob("*") if p.is_file() and not any(x in p.parts for x in SKIP))
out = OUT / f"kidney-proteome-uacr-mr-v{VERSION}.zip"
if out.exists():
    out.unlink()
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
    for p in files:
        zf.write(p, p.relative_to(REPO).as_posix())

z = zipfile.ZipFile(out)
names = z.namelist()
h = hashlib.sha256(out.read_bytes()).hexdigest()
print("归档:", out.as_posix())
print("文件数:", len(names), "| 完整:", z.testzip() is None, "| %.2f MB" % (out.stat().st_size / 1e6))
print("SHA256:", h)
for k in ("manuscripts/manuscript_en.docx", "manuscripts/manuscript_zh.docx",
          "figures/Fig2_dual_criteria.png", "PROVENANCE.md"):
    print(("  有 " if k in names else "  缺 ") + k)

# 3) 核验包内稿件作者行
import io

from docx import Document

for member in ("manuscripts/manuscript_en.docx", "manuscripts/manuscript_zh.docx"):
    dd = Document(io.BytesIO(z.read(member)))
    lines = [p.text for p in dd.paragraphs if p.text.startswith(("Corresponding author", "通信作者"))]
    print(f"  {member} -> {lines[0][:105] if lines else '未找到'}")
