# -*- coding: utf-8 -*-
"""把仓库文件切成每批 ≤100 的若干目录，供网页逐批拖拽上传。"""
import shutil
from pathlib import Path

REPO = Path("repo")
BASE = Path("GitHub上传")
SKIP = {".git", "__pycache__", ".ipynb_checkpoints"}
CAP = 100

files = sorted(p for p in REPO.rglob("*") if p.is_file() and not any(x in p.parts for x in SKIP))

# 先按“根级目录”分组，保持结构清晰；超过 CAP 的再按文件名切分
order = ["manuscripts", "figures", "metadata", "references", "docs", "tools", "analysis", "results"]
buckets, leftovers = [], []
for top in order:
    group = [p for p in files if p.relative_to(REPO).parts[0] == top]
    leftovers += [p for p in files if p.relative_to(REPO).parts[0] != top and top == "manuscripts"]
    if len(group) > CAP:
        for i in range(0, len(group), CAP):
            buckets.append((f"{top}_{i // CAP + 1}", group[i:i + CAP]))
    elif group:
        buckets.append((top, group))
roots = [p for p in files if p.relative_to(REPO).parts[0] not in order]
if roots:
    buckets.insert(0, ("root", roots))

# 合并小批次，减少拖拽次数
merged = []
for name, group in buckets:
    if merged and len(merged[-1][1]) + len(group) <= CAP:
        merged[-1] = (merged[-1][0] + "+" + name, merged[-1][1] + group)
    else:
        merged.append((name, group))

for i, (name, group) in enumerate(merged, 1):
    d = BASE / f"批次{i}_{name}"
    if d.exists():
        shutil.rmtree(d)
    for p in group:
        dst = d / p.relative_to(REPO)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, dst)

# 清理旧的两批
for old in ("批次1_稿件与图件", "批次2_脚本与结果"):
    d = BASE / old
    if d.exists():
        shutil.rmtree(d)

total = 0
for i, (name, group) in enumerate(merged, 1):
    d = BASE / f"批次{i}_{name}"
    n = sum(1 for f in d.rglob("*") if f.is_file())
    mb = sum(f.stat().st_size for f in d.rglob("*") if f.is_file()) / 1e6
    total += n
    print(f"批次{i}_{name}: {n} 个文件, {mb:.2f} MB {'OK' if n <= CAP else '超限'}")
print("合计:", total, "| 仓库总数:", len(files), "| 一致:", total == len(files))
