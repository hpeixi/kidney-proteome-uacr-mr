# -*- coding: utf-8 -*-
"""核验 Zenodo v1.0.5：版本、DOI、文件哈希；并更新本地 DOI 记录。"""
import hashlib
import json
import ssl
import urllib.request
from pathlib import Path

CTX = ssl.create_default_context()
CTX.check_hostname = False
CTX.verify_mode = ssl.CERT_NONE
UA = "kidney-check/1.0"


def get(url, binary=False):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=120, context=CTX) as r:
        return r.read() if binary else json.loads(r.read())


rec = get("https://zenodo.org/api/records/23851408")
print("概念记录:", rec.get("conceptrecid"))
print("最新版本:", rec["metadata"].get("version"))
print("版本 DOI:", rec.get("doi"))
print("标题:", rec["metadata"].get("title"))
print("发布时间:", rec["metadata"].get("publication_date"))
files = rec.get("files", [])
print("文件数:", len(files))
for f in files:
    key = f.get("key")
    size = f.get("size")
    link = f["links"]["self"]
    print(f"  - {key}  {size} 字节")
    data = get(link, binary=True)
    remote = hashlib.sha256(data).hexdigest()
    local_path = Path("GitHub上传") / key
    local = hashlib.sha256(local_path.read_bytes()).hexdigest() if local_path.exists() else "（本地无同名文件）"
    print("    远端 SHA256:", remote)
    print("    本地 SHA256:", local)
    print("    一致:", remote == local)

# 更新 DOI.txt
p = Path("repo/metadata/DOI.txt")
s = p.read_text(encoding="utf-8")
s = s.replace("  v1.0.5  待发布，发布后由脚本写入 DOI_LAST_PUBLISHED.txt，请补记于此行",
              "  v1.0.5  10.5281/zenodo.23859101   （含 kidney-proteome-uacr-mr-v1.0.5.zip，172 个文件）")
p.write_text(s, encoding="utf-8")
Path("repo/metadata/DOI_LAST_PUBLISHED.txt").write_text("10.5281/zenodo.23859101\n", encoding="utf-8")
print("\nDOI.txt 已记录 v1.0.5:", "23859101" in p.read_text(encoding="utf-8"))
